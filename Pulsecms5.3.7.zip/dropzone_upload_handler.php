<?php

require_once (__DIR__ . '/symlink_safe.php');

require_once (PULSE_BASE_DIR . '/config.php');
require_once (PULSE_BASE_DIR . '/inc/plugins/parsedown.php');

require_once (PULSE_BASE_DIR . '/pulsecore/page/end_point.php');

# start the session
\pulsecore\session\start();

# set up the globals
$parsedown = new \Parsedown();

# set up the globals - language
require_once (PULSE_BASE_DIR . "/{$admin}/inc/lang/english.php");
if (!empty($language) and \file_exists(PULSE_BASE_DIR . "/{$admin}/inc/lang/{$language}.php")) {
	require_once (PULSE_BASE_DIR . "/{$admin}/inc/lang/{$language}.php");
}

/**
 * dropzone uploads
 */
function page_dropzone_upload_handler() {
	
	$page_handler = new \pulsecore\page\DropzoneUploadHandler();
	echo $page_handler->process(
		$_GET,
		$_POST,
		$_COOKIE,
		(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'get')
	);
}

# call
echo page_dropzone_upload_handler();
 