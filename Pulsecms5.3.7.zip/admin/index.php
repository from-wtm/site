<?php

require_once (__DIR__ . '/../symlink_safe.php');

if (version_compare(phpversion(), '7.0.0', '<')) {
    // php version isn't high enough
	echo "Please update to PHP 7.0 or higher to complete the install!";
	
	echo "<script>window.location = 'install.php'</script>";
}

require_once (PULSE_BASE_DIR . '/config.php');
require_once (PULSE_ADMIN_DIR . '/inc/lang/english.php');
if (!empty($language) and \file_exists(PULSE_ADMIN_DIR . "/inc/lang/{$language}.php")) {
	require_once (PULSE_ADMIN_DIR . "/inc/lang/{$language}.php");
}

# ===========================================================================>
/**
 * wedge includes
 */
require_once (PULSE_BASE_DIR . '/pulsecore/acl_role.php');
require_once (PULSE_BASE_DIR . '/pulsecore/filter.php');
require_once (PULSE_BASE_DIR . '/pulsecore/sitemap.php');
require_once (PULSE_BASE_DIR . '/pulsecore/validate.php');

# ===========================================================================>

#==> begin wedge <==
#add or update the sitemap.xml file
\pulsecore\sitemap\generate( $GLOBALS['path'], \pulsecore\get_configs()->http_scheme );
#==> end wedge   <==

require_once (PULSE_ADMIN_DIR . '/inc/login.php');
require_once (PULSE_ADMIN_DIR . '/inc/magic.php');

$page = (isset($_GET['p']) && !empty($_GET['p'])) ? $_GET['p'] : 'home';
$page = \htmlspecialchars($page, ENT_QUOTES, 'UTF-8');
$page = \preg_replace('/[^-a-zA-Z0-9_]/', '', $page);

# access control for user groups and logged in members
(\pulsecore\acl_role\is_user() and \pulsecore\acl_role\user_group_is_user_allowed("admin/{$page}" . (isset($_GET['f']) ? "?f={$_GET['f']}" : ''), 'r', $_SESSION['user_group_list']));

if (!\file_exists(PULSE_ADMIN_DIR . "/inc/{$page}.php")) {
    $page = '404';
}

ob_start(); 

//load the dashboard rather than the default home page
$pass = max( (isset($_GET['f']) ? $_GET['f'] : ''), (isset($_GET['p']) ? $_GET['p'] : '') );
$location = (isset($pass) && !empty($pass)) ? $pass : 'home';

if ($location === "home"){
	require_once (PULSE_ADMIN_DIR . '/inc/dashboard/dashboard.php');
} else {
	require_once (PULSE_ADMIN_DIR . "/inc/{$page}.php");
}

$content = ob_get_contents();

ob_end_clean();

#==============================================================================>
# css/js files to load

# load css - font awesome
\pulsecore\get_context()->theme->css->add( PULSE_BASE_URL . '/pulsecore/asset/vendor/fontawesome/css/all.min.css', array(), 'fontawesome' );

# load js/css -  masonry
\pulsecore\get_context()->theme->js->add( PULSE_BASE_URL . '/pulsecore/asset/vendor/node_modules/masonry-layout/dist/masonry.pkgd.min.js', array(), 'masonry' );

# needs to be set after the session is loaded so the sweetalerts messages are available
# needs to be after page/tags run so sweet alert messages show up
\pulsecore\get_context()->theme->js_body->add(
	PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/moment/min/moment-with-locales.min.js"
);
\pulsecore\get_context()->theme->js_body->add(
	PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/pikaday-time/pikaday.js",
	array(
		PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/moment/min/moment-with-locales.min.js"
	)
);
\pulsecore\get_context()->theme->js_body->add(
	PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/pikaday-time/plugins/pikaday.jquery.js",
	array(
		PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/moment/min/moment-with-locales.min.js",
		PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/pikaday-time/pikaday.js"
	)
);
# sweet alert
\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/sweetalert/dist/sweetalert.min.js", array() );

\pulsecore\get_context()->theme->js_body->add_inline( 'status_messages_json', \pulsecore\session\status_to_js() );
\pulsecore\get_context()->theme->js_body->add_inline( 'translations',         \pulsecore\get_context()->theme->translations->render() );

\pulsecore\get_context()->theme->js_body->add(
	PULSE_BASE_URL . "/pulsecore/asset/js/app_translate.js",
	array(
		PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/sweetalert/dist/sweetalert.min.js",
		'status_messages_json',
		'translations'
	)
);

\pulsecore\get_context()->theme->js_body->add(
	PULSE_BASE_URL . "/pulsecore/asset/js/widget/status_message/status_message.js",
	array(
		PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/sweetalert/dist/sweetalert.min.js",
		PULSE_BASE_URL . "/pulsecore/asset/js/app_translate.js",
		'status_messages_json',
		'translations'
	),
	"status_message"
);

# redactor
\pulsecore\get_context()->theme->css->add( PULSE_ADMIN_URL . "/redactor/redactor.min.css",            array(), 'redactor' );
\pulsecore\get_context()->theme->css->add( PULSE_ADMIN_URL . "/redactor/plugins/clips.min.css",       array('redactor') );
\pulsecore\get_context()->theme->css->add( PULSE_ADMIN_URL . "/redactor/plugins/filemanager.min.css", array('redactor') );
\pulsecore\get_context()->theme->css->add( PULSE_ADMIN_URL . "/redactor/plugins/inlinestyle.min.css", array('redactor') );

\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/redactor.min.js", array( 'status_message' ), 'redactor' );

# Redactor Plugins - source.js is the old HTML viewer - replaced in favour to codemirror
# \pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/source.js", array( PULSE_ADMIN_URL . "/redactor/redactor.min.js" ) );

#\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/codemirror/codemirror.min.js", array( 'redactor' ) );
#\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/codemirror/xml/xml.js",        array( 'redactor' ) );

\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/alignment.min.js",     array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/clips.min.js",         array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/filemanager.min.js",   array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/fontcolor.min.js",     array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/fontfamily.min.js",    array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/fontsize.min.js",      array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/fullscreen.min.js",    array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/inlinestyle.min.js",   array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/properties.min.js",    array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/table.min.js",         array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/textdirection.min.js", array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/video.min.js",         array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/widget.min.js",        array( 'redactor' ) );

# \pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/imagemanager.min.js",  array( 'redactor' ) );
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/js/pulse_redactor_imagemanager.js",  array( 'redactor' ) );

# \pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/codemirror.js",    array( 'redactor' ) );
# \pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/plugins/snippets.js",      array( 'redactor' ) );

\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/mail.js",      array( 'redactor' ) );

$lang_code = \pulsecore\language_to_iso( $language );

\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/lang/{$lang_code}.js", array( 'redactor' ) );

\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/lang.pulse.js", array( 'redactor' ) );

$sweetalert_active  = \pulsecore\wedge\config\get_json_configs()->json->sweetalert->active;
$sweetalert_timeout = \pulsecore\wedge\config\get_json_configs()->json->sweetalert->timeout;

$sweetalert_active  = \intval( $sweetalert_active );
$sweetalert_timeout = \intval( $sweetalert_timeout );

$js_redactor_inline_lang =<<<EOD
	var pulsecore = pulsecore || {};
	pulsecore.alert = {
		active:  {$sweetalert_active},
		timeout: {$sweetalert_timeout}
	};
	pulsecore.lang       = "{$language}";
	pulsecore.lang_short = "{$lang_code}";
EOD;

\pulsecore\get_context()->theme->js_body->add_inline( 'redactor-inline-lang', $js_redactor_inline_lang );

# Redactor Initialisation on #wysiwyg
\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/redactor_init.js", array( 'redactor' ) );

#==============================================================================>

?><!DOCTYPE html>
<html lang="<?php echo \pulsecore\language_to_iso(\pulsecore\wedge\config\get_json_configs()->json->language); ?>">
<head>
	<title><?php echo $lang_title; ?></title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width" />
	<link rel="stylesheet" href="<?php echo PULSE_ADMIN_URL; ?>/css/admin.css" />
	<link rel="stylesheet" href="<?php echo PULSE_ADMIN_URL; ?>/css/animate.css" />
	<link rel="stylesheet" href="<?php echo PULSE_BASE_URL; ?>/pulsecore/asset/css/pulsecore.css" />
	<script src="<?php echo PULSE_ADMIN_URL; ?>/js/jquery.js"></script>
	<script src="<?php echo PULSE_ADMIN_URL; ?>/js/jquery-ui.min.js"></script>
	<script src="<?php echo PULSE_ADMIN_URL; ?>/js/scripts.js"></script>
	<script src="<?php echo PULSE_ADMIN_URL; ?>/js/main.js"></script><!-- Dropdown menu -->
	<!-- Redactor -->
	<!-- <script src="<?php echo PULSE_ADMIN_URL; ?>/redactor/plugins/source.js"></script>-->
	<!--<link rel="stylesheet" href="<?php echo PULSE_ADMIN_URL; ?>/codemirror/codemirror.css" />-->
	
	<link rel="icon" type="image/png" href="<?php echo PULSE_BASE_URL; ?>/content/media/branding/favicon.png" />
	<link rel="apple-touch-icon" href="<?php echo PULSE_BASE_URL; ?>/content/media/branding/apple-touch-icon.png" />
	
	<!-- -->
	<link rel="stylesheet" href="<?php echo PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/pikaday/css/pikaday.css"; ?>" />
	
	<?php echo \pulsecore\get_context()->theme->css->render(); ?>
	
	<?php echo \pulsecore\get_context()->theme->js->render(); ?>
	
</head>
<body>
	<header class="cd-main-header">
		<a href="<?php echo PULSE_ADMIN_URL; ?>">
			<img src="<?php echo PULSE_BASE_URL; ?>/content/media/branding/logo.svg" class="cd-logo" title="Logo" alt="<?php echo $lang_title;?>" />
		</a>
		
		<a href="#0" class="cd-nav-trigger">Menu<span></span></a>
		
		<nav class="cd-nav">
			<ul class="cd-top-nav">
				<li class="has-children account">
					<a href="#0">
						<img src="<?php echo (new \pulsecore\view\helper\LastModified())->render( array(PULSE_BASE_URL . "/content/media/branding/avatar.jpg") ); ?>" alt="avatar">
						<?php echo $lang_account ?>
					</a>
				
					<ul>
						<li><?php if (\pulsecore\acl_role\is_administrator()) {?>
							<a href="index.php?p=settings"><i class="fa fa-cog"></i><?php echo $lang_settings ?></a>
							<?php } ?></li>
						<li>
							<?php if ((\pulsecore\wedge\config\get_json_configs()->json->integrate_rapidweaver === true) and (\stripos('pulse', PULSE_ADMIN_URL) !== false)) { ?>
								<a href="<?php echo '../../'; ?>" target="_blank">
									<i class="fa fa-eye"></i><?php echo $GLOBALS['lang_home_preview']; ?>
								</a>
							<?php } else { ?>
								<a href="<?php echo PULSE_BASE_URL; ?>/" target="_blank">
									<i class="fa fa-eye"></i><?php echo $GLOBALS['lang_home_preview']; ?>
								</a>
							<?php } ?>
						</li>
						<li><a href="<?php echo $lang_help_url;?>" target="_blank"><i class="fa fa-info-circle"></i><?php echo $lang_help;?></a></li>
						<?php if (\pulsecore\acl_role\is_administrator()) {?><li><a href="index.php?p=update"><i class="fa fa-cloud-upload-alt"></i><?php echo $lang_settings_title_update;?></a></li><?php } ?>	
						<?php if (\pulsecore\acl_role\is_administrator()) {?><li><a href="index.php?p=debug_info"><i class="fa fa-bug"></i><?php echo $lang_settings_title_debug_info;?></a></li><?php } ?>	
						<li><a href="index.php?p=logout"><i class="fa fa-sign-out-alt"></i><?php echo $lang_nav_logout ?></a></li>
					</ul>
				</li>
			</ul>
		</nav>
	</header>
	
	<main class="cd-main-content">
		<aside>
			<nav class="cd-side-nav">
				<?php
					$dashboard_active_tab = '';
					
					$dashboard_active_tab = (isset($_GET['f']) and (\stripos($_GET['f'], 'blocks') === 0)) ? 'blocks' : $dashboard_active_tab;
					$dashboard_active_tab = (isset($_GET['f']) and (\stripos($_GET['f'], 'blog'  ) === 0)) ? 'blog'   : $dashboard_active_tab;
					$dashboard_active_tab = (isset($_GET['f']) and (\stripos($_GET['f'], 'pages' ) === 0)) ? 'pages'  : $dashboard_active_tab;
					$dashboard_active_tab = (isset($_GET['f']) and (\stripos($_GET['f'], 'media' ) === 0)) ? 'media'  : $dashboard_active_tab;
					$dashboard_active_tab = (isset($_GET['p']) and (\stripos($_GET['p'], 'unishop' ) === 0)) ? 'store'  : $dashboard_active_tab;
					$dashboard_active_tab = (isset($_GET['p']) and (\stripos($_GET['p'], 'manage_user_list' ) === 0)) ? 'users'  : $dashboard_active_tab;
					$dashboard_active_tab = (isset($_GET['p']) and (\stripos($_GET['p'], 'manage_navigation' ) === 0)) ? 'navigation'  : $dashboard_active_tab;
					$dashboard_active_tab = (isset($_GET['f']) and (\stripos($_GET['f'], 'stats' ) === 0)) ? 'stats'  : $dashboard_active_tab;
					
					$dashboard_active_tab = (isset($_GET['gallery']) and (\stripos($_GET['gallery'], 'media' ) === 0)) ? 'media'  : $dashboard_active_tab;
					
					if (isset($_SESSION['dashboard_active_tab_hint'])) {
						$dashboard_active_tab = $_SESSION['dashboard_active_tab_hint'];
					}
					
					unset($_SESSION['dashboard_active_tab_hint']);
				?>
				<ul>
					<!--<li class="cd-label"><?php echo $lang_nav_title; ?></li>-->
					<li class="<?php echo ((!isset($_GET['f']) and empty($dashboard_active_tab)) ? 'active' : ''); ?>">
						<a href="index.php"><i class="fa fa-tachometer-alt"></i><?php echo $lang_nav_home; ?></a>
					</li>
					<li class="<?php echo (($dashboard_active_tab == 'blocks') ? 'active' : ''); ?>">
						<a href="index.php?f=blocks"><i class="fa fa-th-large"></i><?php echo $lang_nav_blocks; ?></a>
					</li>
					<li class="<?php echo (($dashboard_active_tab == 'blog'  ) ? 'active' : ''); ?>">
						<a href="index.php?f=blog"><i class="fa fa-rss"></i><?php echo $lang_nav_blog; ?></a>
					</li>
					<?php if (\pulsecore\acl_role\is_administrator() or \pulsecore\acl_role\is_editor_allowed_resource('page')) { ?>
						<li class="<?php echo (($dashboard_active_tab == 'pages' ) ? 'active' : ''); ?>">
							<a href="index.php?f=pages"><i class="fa fa-file-alt"></i><?php echo $lang_nav_pages; ?></a>
						</li>
					<?php } ?>
					<li class="<?php echo (($dashboard_active_tab == 'media' ) ? 'active' : ''); ?>">
						<a href="index.php?f=media"><i class="fa fa-file-image"></i><?php echo $lang_nav_img; ?></a>
					</li>
					<?php if (\pulsecore\acl_role\is_administrator()) { ?><li class="<?php echo (($dashboard_active_tab == 'users' ) ? 'active' : ''); ?>">
						<a href="index.php?p=manage_user_list"><i class="fa fa-user"></i><?php echo $lang_nav_users; ?></a>
					</li>
					<?php } ?>
					<li class="<?php echo (($dashboard_active_tab == 'stats' ) ? 'active' : ''); ?>">
						<a href="index.php?f=stats"><i class="fa fa-chart-bar"></i><?php echo $lang_nav_stats; ?></a>
					</li>
					<?php if (\pulsecore\acl_role\is_administrator()) { ?><li class="<?php echo (($dashboard_active_tab == 'navigation' ) ? 'active' : ''); ?>">
						<a href="index.php?p=manage_navigation"><i class="fa fa-compass"></i><?php echo $lang_nav_title; ?></a>
					</li>
					<?php } ?>
					<?php if (\pulsecore\wedge\config\get_json_configs()->json->integrate_ecommerce === true) { ?><li class="<?php echo (($dashboard_active_tab == 'store' ) ? 'active' : ''); ?>">
						<a href="index.php?p=unishop"><i class="fa fa-shopping-cart"></i><?php echo $lang_nav_store; ?></a>
					</li>
					<?php } ?>
				</ul>
			</nav>
		</aside>
		<section class="content-wrapper">
				<?php 
				echo $content;
				if (($autobackup == true) and (\extension_loaded('zip') == true)) {
					require_once (PULSE_ADMIN_DIR . '/inc/auto_backup.php');
				}
				?>
		</section>
	</main>
	
	<?php echo \pulsecore\get_context()->theme->js_body->render(); ?>
</body>
</html>
