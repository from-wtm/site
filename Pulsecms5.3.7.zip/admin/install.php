<?php

require_once (__DIR__ . '/../symlink_safe.php');

# error reporting
\error_reporting(\E_STRICT|\E_ALL);

# set the timezone so PHP does not complain
\date_default_timezone_set( 'Asia/Tokyo' );

# error management
# \ini_set('display_errors',         '1');
# \ini_set('display_startup_errors', '1');
\ini_set('log_errors',             '1');

\ini_set('error_log', (PULSE_BASE_DIR . '/pulsecore/storage/log/error_log_installer_' . \date('Y_m_d') . '.log') );

# session
\session_start();

/**
 * first fix the config file and set autodetected properties
 */
require_once (PULSE_BASE_DIR . "/pulsecore/dbc.php");
require_once (PULSE_BASE_DIR . "/pulsecore/misc.php");
require_once (PULSE_BASE_DIR . "/pulsecore/wedge/config.php");
require_once (PULSE_BASE_DIR . "/pulsecore/install/config.php");

$autodetected_path = '';

# update/create the config files and insert the auto-detected path
if (isset($_GET['test']) and ($_GET["test"] == '1') and isset($_GET['autodetected_path'])) {
	
	$autodetected_path = $_GET['autodetected_path'];
	$autodetected_path = \trim( $autodetected_path );
	
	# patch the config.php file
	\pulsecore\install\config_update(
		(PULSE_BASE_DIR . "/config.php"),
		array(
			'autodetected_path' => $autodetected_path
		)
	);
	
	# corner case - missing JSON config. Attempt to rebuild
	if (!\file_exists(PULSE_BASE_DIR . '/pulsecore/storage/config.json')) {
		
		# create a JSON config file from the defaults
		$status = \file_put_contents( (PULSE_BASE_DIR . '/pulsecore/storage/config.json'), \json_encode(\pulsecore\wedge\config\get_json_configs()->json) );
		
		\pulsecore\invariant( $status !== false, 'Unable to create a default JSON configuration file');
		
		# merge in the config.php values
		require_once (PULSE_BASE_DIR . "/config.php");
		
		# not necessary - just in case
		\pulsecore\wedge\config\save_config( \pulsecore\wedge\config\get_json_configs()->json );
		
		# update the path
		\pulsecore\wedge\config\get_json_configs()->json->path = $autodetected_path;
		
		# save the updated version
		\pulsecore\wedge\config\save_config( \pulsecore\wedge\config\get_json_configs()->json );
	}
	
	# patch the JSON config file
	\pulsecore\install\config_update_json(
		(PULSE_BASE_DIR . '/pulsecore/storage/config.json'),
		array(
			'autodetected_path' => $autodetected_path
		)
	);
	
	# patch the .htaccess file
	\pulsecore\install\config_update_htaccess(
		(PULSE_BASE_DIR . "/.htaccess"),
		array(
			'autodetected_path' => $autodetected_path
		)
	);
} else {
	# no form
	$autodetected_path = \pulsecore\autodetect_root_path( $_SERVER['REQUEST_URI'], '/admin/install.php' );
}

/**
 * some magic - define a constant to prevent config.php from loading the
 * config.json data and over-writing the changes
 */
\define( 'NO_JSON_CONFIG_LOAD', true );
require_once (PULSE_BASE_DIR . "/config.php");

?>
<!DOCTYPE html>
<html>
<head>
	<title>PulseCMS Installer</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<style>
body {
	font-family: sans-serif;
	line-height:1.4;
	padding: 20px;
	color: #333;
}

.label {
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	padding: 9px;
	clear: left;
	float: left;
	width: 125px;
	background-color: #ddd;
}

.label-top {
	color: white;
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	padding: 9px;
	clear: left;
	float: left;
	width: 125px;
	background-color: #999999;
}

.value {
	float: left;
	color: white;
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	padding: 9px;
	background-color: #6699cc;
	width: 125px;
}

.value-top {
	float: left;
	color: white;
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	padding: 9px;
	background-color: #496e92;
	width: 125px;
}

.req {
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	background-color: #ddd;
	padding: 9px;
	float: left;
	width: 300px;
}

.req-top {
	color: white;
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	background-color: #999999;
	padding: 9px;
	float: left;
	width: 300px;
}
.server-req, .server-diag {
	margin-bottom: 40px;
	display: inline-block;
}
.header {
		background: black;
}
.logo {
		padding: 10px;
}
.message {
		color: white;
		padding-left: 10px;
		padding-bottom: 10px;
}
.message a {
		color: #D76F1F;
}

h2 {
	float: right;
	padding-right: 10px;
	color: #ffffff;
}

.message span {
	font-weight: bold;
	color: #D54359;
}

form {
	outline: 1px solid #dddddd;
	padding: 10px;
}
form #counter {
	border: 5px solid #444444;
	border-radius: 5px;
	background-color: #444444;
	color: #ffffff;
	padding: 5px;
	text-align: center;
}
</style>

</head>

<body>

<div class="header">
	<h2>Congratulations, installed!</h2><img src="../content/media/branding/logo.svg" class="logo">
	<p class="message">Now go and <a href="index.php">log in to the Admin panel</a> (bookmark this link) with username "<span>administrator</span>" and password "<span>demo</span>" and edit your Pulse site! Your site is <a href="../">here</a>.</p>
</div>

<div class="server-req">
	<h1>Please check the Pulse Server Requirements</h1>
	
	<p class="label-top">Spec</p> 
	<p class="value-top">Your Server</p> <p class="req-top">Requirement</p><br />
	
	<p class="label">Server Type:</p> 
	<p class="value"><?php print $_SERVER['SERVER_SOFTWARE']; ?> </p>   <p class="req">Apache</p>  <br />    
	         
	<p class="label">PHP Version:</p> 
	<p class="value"><?php print phpversion()?></p><p class="req">PHP 7.0 or higher</p> <br />
	                         
	<p class="label">File Uploads:</p> 
	<p class="value"><?php print my_ini_get('file_uploads'); ?></p> <p class="req">Uploads required</p><br />
	                               
	<p class="label">Safe Mode:</p> 
	<p class="value"><?php print my_ini_get('safe_mode'); ?></p>  <p class="req">Safe mode must be off</p><br />
	
	<p class="label">Magic Quotes:</p> 
	<p class="value"><?php if(get_magic_quotes_gpc()) echo "On"; else echo "Off"; ?></p>  <p class="req">Magic quotes must be off</p><br />
	
	<p class="label">GD Support:</p>
	
	<?php 
		if (!function_exists("gd_info")) {
			print "<p class=\"value\">GD NOT Enabled</p>"; 
		} else if (function_exists("gd_info")) {
			print "<p class=\"value\">GD Enabled</p>";
		}
	?>
	
	<p class="req">GD is required for the gallery to function.</p><br />
</div>

<hr>

<div class="server-diag">
	<h1>Pulse CMS Diagnostic Tool</h1>
	
	<hr>
	
	<h2>System Requirements</h2>
	
	<p>Basic system requirements are an apache server with at least PHP 7.0 or higher installed.</p>
	
	<?php
	
	function my_ini_get($name) {
		$setting = (ini_get($name));        
		$setting = ($setting==1 || $setting=='On') ? 'On' : 'Off';
		return $setting;
	}
	
	?>
	<p><b>Server Type:</b> <?php print $_SERVER['SERVER_SOFTWARE']; ?><br /> 
	<b>PHP Version:</b>    <?php print phpversion()?><br />
	<b>File Uploads:</b>   <?php print my_ini_get('file_uploads'); ?><br />
	<b>Safe Mode:</b>      <?php print my_ini_get('safe_mode'); ?><br />
	<b>Magic Quotes:</b>   <?php if(get_magic_quotes_gpc()) echo "On"; else echo "Off"; ?><br />
	<b>GD Support:</b>     <?php 
	
		if (!function_exists("gd_info")) {
			print "Off";
		} else if(function_exists("gd_info")) {
			print "On";
		}
	?>
	<br />
	<b>Zip Extension:</b> <?php if (extension_loaded('zip')) { echo "On"; } else{ echo "Off"; } ?></p> 
	
	<hr>
	
	<h2>Permissions Check</h2>
	
	<p>Folders should have at least 755 and files 644 permissions,
		if the group is the same as the Apache web server. For example, if apache
		is running as the group www-data, then these files should be readable and
		writable by the www-group. For directories it should be readable, writable
		and executable by the www-group.
	</p>
	
	<p>Folders should have at least 777 and files 666 permissions, if the web server group cant be determined</p>
	
	<p>Other files and folders should be readable by the web server otherwise.</p>
	
	<?php clearstatcache(); ?>
	
	root directory - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR)), -4); ?><br />
	
	content         - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/content')),         -4); ?><br />
	content/backups - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/content/backups')), -4); ?><br />
	content/blocks  - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/content/blocks')),  -4); ?><br />
	content/blog    - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/content/blog')),    -4); ?><br />
	content/media   - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/content/media')),   -4); ?><br />
	content/pages   - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/content/pages')),   -4); ?><br />
	content/stats   - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/content/stats')),   -4); ?><br />
	
	pulsecore/storage       - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/pulsecore/storage')),       -4); ?><br />
	pulsecore/storage/cache - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/pulsecore/storage/cache')), -4); ?><br />
	pulsecore/storage/log   - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/pulsecore/storage/log')),   -4); ?><br />
	
	pulsecore/storage/config.json - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/pulsecore/storage/config.json')),   -4); ?><br />
	
	config.php - <?php echo substr(sprintf('%o', fileperms(PULSE_BASE_DIR . '/config.php')),     -4); ?><br /><br />
	
	<hr>
	
	<h2>Path Setting</h2>
	
	<p>This is where Pulse is installed. If you installed Pulse in the root, it should should a blank space. If you are using Pulse inside a sub-folder, it should be set as "/sub".</p>
	
	<p><b>Path Name:</b> " <?php echo $path; ?>"</p>
	
	<hr>
	
	<h2>.Htaccess Check</h2>
	
	<p>The .htaccess file is required for Pulse to work properly. If the file is missing, use the sample.htaccess file. Just remove the sample part and place it in the app root along with the index.php and config.php files.</p>
	
	<p><?php
	$filename = PULSE_BASE_DIR . '/.htaccess';
	
	if (\file_exists($filename)) {
	    echo "<b>The .htaccess file exists.</b>";
	} else {
	    echo "<b>The .htaccess file does not exist.</b>";
	}
	?></p>
	
	<p>
		.htaccess file permissions <?php echo \substr(\sprintf('%o', \fileperms($filename)),     -4); ?>
	</p>
	
	<hr />
	
	<h2>Session Handling</h2>
	
	<p>If sessions are not working properly, it can cause problems with logging in and viewing blocks, etc.</p>
	
	<?php
	if (isset($_GET['test']) and ($_GET["test"] == '1')) {
		
		if (isset($_SESSION['atest']) and ($_SESSION['atest'] == 'yes')) {
		
			echo('<b>Your hosting supports sessions</b>');
			
			} else echo('<b>Your hosting does not support sessions</b>');
			
		} else {
				
				$base_url = $_SERVER['REQUEST_URI'];
				$base_url = \substr( $base_url, 0, (\stripos($base_url, 'install.php') + \strlen('install.php')) );
				$base_url = \pulsecore\autodetect_root_path( $base_url, '/admin/install.php' );
				
				$_SESSION['atest'] = 'yes';
				
				$qqq =<<<EOD
<br />
<br />
Please wait...
<br />
<br />
<form method='get'>
	<span id='counter'></span>
	<label for='url'>Auto-detected base URL:</label>
	<input type='text' name='autodetected_path' placeholder='Base URL' value='{$base_url}' required />
	
	<input type='hidden' name='test' value='1' />
	
	<input type='submit' value='Change' />
</form>
<br />
<br />
EOD;
				
				$qqq = \str_replace( "\n", '', $qqq );
				
				echo '
					<script>
						<!--
						let counter = 10;
						let paused  = false;
						function delayer () {
							
							if (counter == 0) {
								document.querySelector("form").submit();
								//window.location = "', $base_url, '/admin/install.php?test=1";
								return;
							} else {
								if (paused == false) {
									document.getElementById("counter").innerHTML = ("" + counter);
									counter--;
								}
								window.setTimeout( delayer, 800 );
							}
						}
						// ping
						window.setTimeout( delayer, 500 );
						
						let element = document.querySelector( "body" );
						element.innerHTML = "', $qqq, '";
						
						// event handler mouse over
						document.querySelector("form").addEventListener(
							"mouseover",
							function (evnt) {
								document.getElementById("counter").innerHTML = "Paused";
								paused = true;
							}
						);
						// event handler mouse over
						document.querySelector("form").addEventListener(
							"mouseout",
							function (evnt) {
							document.getElementById("counter").innerHTML = ("" + counter);
								paused = false;
							}
						);
						//-->
					</script>
					';
			}
	?>
</div>
<br /><br /><br /><br />
</body>
</html>