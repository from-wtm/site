jQuery(document).ready(
	function() {
		$R(
			'#wysiwyg',
			{
				lang: (pulsecore.lang_short || "en"),
				
				pastePlainText: true,
				paragraphize: true,
				replaceDivs: false,
				autoresize: true,
				minHeight: '380px',
				//buttonSource: true,
				imageFigure: true,
				imageUpload: 'inc/editor_images.php',
				imageManagerJson: 'inc/data_json.php',
				fileUpload: 'inc/editor_files.php',
				fileManagerJson: 'inc/data_json.php',
				imageResizable: true,
				imagePosition: true,
				plugins: [
						'alignment',
						'clips',
						'filemanager',
						'fontcolor',
						'fontsize',
						'fontfamily',
						//'fullscreen',
						
						//'imagemanager',
						'pulse_redactor_imagemanager',
						
						'inlinestyle',
						'properties',
						'table',
						'textdirection',
						'video', 
						
						//'codemirror',
						//'snippets',
						
						'widget',
						'mail'
						],
				/*
				codemirror: {
						lineNumbers: true,
						mode: 'xml',
						indentUnit: 4
				},
				*/
				clips: [
					['More', '##more##']
				],
				
				styles: true,
				
				toolbarFixed: true,
				//toolbarFixedTarget: '#textfile',
				toolbarFixedTopOffset: 50,
				toolbarOverflow: true,
				focus: true,
				
				buttonsAddBefore: {
					before: 'format',
					buttons: ['undo', 'redo']
				},
				buttonsAddAfter: {
					after: 'deleted',
					buttons: ['underline']
				}
			}
		);
	}
);
