<?php

require_once (__DIR__ . '/../../symlink_safe.php');

include_once (PULSE_BASE_DIR . '/config.php');

#path may be set wrong leading to logout
if (\stripos($path, 'editor_files.php') !== false) {
	$path = \dirname($path);
	$path = \dirname($path);
}

require_once("login.php");

$filename    = $_FILES['file']['name'];
$filename    = \is_array($filename) ? reset($filename) : $filename;
$filename    = \pulsecore\filter\file_name( $filename );

$source = $_FILES['file']['tmp_name'];
$source = \is_array($source) ? reset($source) : $source;

$destination = \pulsecore\get_configs()->dir_content . '/media/' . $filename;

\move_uploaded_file( $source, $destination );

$array = array(
	#'filelink' => ($path.'/content/media/' . $filename),
	#'filename' => $filename,
	
	"file-0" => array(
		"url"  => ($path . '/content/media/' . $filename),
		"name" => $filename,
		"id"   => \time()
	)
);

echo stripslashes(json_encode($array));
