<?php

# ===========================================================================>
/**
 * wedge in the updated logic from pulsecore
 */
require_once (PULSE_BASE_DIR . '/pulsecore/acl_role.php');
require_once (PULSE_BASE_DIR . '/pulsecore/filter.php');

# ===========================================================================>
/**
 * work out where to redirect to after login
 * \param $url string
 * \return string
 */
function login__redirect_url( $url ) {
	
	$result = $url;
	
	$on = \pulsecore\wedge\config\get_json_configs()->json->admin_front_page_display;
	
	switch ($on) {
		
		case 'block list':
			$result = 'index.php?f=blocks';
			break;
		
		case 'blog':
			$result = 'index.php?f=blog';
			break;
		
		case 'dashboard':
			$result = 'index.php';
			break;
		
		case 'media':
			$result = 'index.php?f=media';
			break;
		
		case 'page list':
			$result = 'index.php?f=pages';
			break;
		
		case 'stats':
			$result = 'index.php?f=stats';
			break;
			
		default:
			$result = $url;
	}
	
	return $result;
}
# ===========================================================================>
/**
 * by-pass for forgot password
 */
if (isset($_GET) and isset($_GET['p']) and ($_GET['p'] == 'login_forgot_password')) {
	
	require_once (PULSE_ADMIN_DIR . '/inc/login_forgot_password.php');
	exit;
}
# ===========================================================================>

$cmp_pass         = $password;
$max_attempts     = 15;
$timestamp_old    = time() - (60*60);
$token_check      = false;
$max_attempts++;
$domain = $_SERVER['SERVER_NAME'];

/*
 * start the session
 */
#if ('' == \session_id()) {
#	\session_set_cookie_params(0, \pulsecore\wedge\config\get_json_configs()->json->path, $domain, false, true);
#	\session_start();
#}
# start the session
\pulsecore\session\start();

if (isset($_COOKIE["mpass_pass-$path"])) {
	$_SESSION["mpass_pass-{$path}"] = $_COOKIE["mpass_pass-{$path}"];
}

//check token
if(isset($_POST["log_token"])){
	
  if(isset($_SESSION["log_token"]) 
  	&& isset($_SESSION["log_token_time"]) 
  	&& $_SESSION["log_token"] == $_POST["log_token"]) {

    if($_SESSION["log_token_time"] >= $timestamp_old) {
		$token_check = true;
	}
   }			
   unset($_SESSION["log_token"]);	
   $_SESSION["log_token_time"]='';
}

if(!isset($_POST["log_token"]) || ($_SESSION["log_token_time"] <= $timestamp_old)) {		
	$_SESSION["log_token"] = md5(uniqid(rand(), TRUE));	
	$_SESSION["log_token_time"] = time();
}

if (!empty($_POST["mpass_pass"])) {
	
	$param_username = $_POST['username'];
	$param_username = \trim($param_username);
	
	# verify password - admin
	if ($param_username == 'administrator') {
		if (\password_verify($_POST["mpass_pass"], $cmp_pass) and ($token_check == true)) {
			
			#check OTP password if its theres
			$otp_password_verified = true;
			
			if (\pulsecore\wedge\config\get_json_configs()->json->otp_activate === true) {
				$otp_password_verified = \pulsecore\otp_verify_password( $_POST['mpass_pass_otp'], \pulsecore\get_configs()->acl_role->admin );
			}
			
			if ($otp_password_verified === true) {
				$_SESSION["mpass_attempts"]        = 0;
				$_SESSION["mpass_session_expires"] = (time() + \pulsecore\get_configs()->session->max_session_time);
				
				$_SESSION["acl_role"] = \pulsecore\get_configs()->acl_role->admin;
				
				$encrypted_password_storage     = \crypt(\pulsecore\wedge\config\get_json_configs()->json->password, \pulsecore\wedge\config\get_json_configs()->json->password);
				$_SESSION["mpass_pass-{$path}"] = $encrypted_password_storage;
				
				$_SESSION["login_username"] = $param_username;
				
				$_SESSION["user_group_list"] = array();
				
				\session_write_close();
				
				\setcookie ("mpass_pass-$path", $encrypted_password_storage, (time() + \pulsecore\get_configs()->session->login->mpass_pass_cookie_lifetime),$path, $domain,false, true);
				\header("Location: " . login__redirect_url("index.php") );
				die();
			}
		}
	}
	
	# verify password - editor
	if ($param_username == 'editor') {
		
		if (    (\pulsecore\wedge\config\get_json_configs()->json->editor_user_enable === true)
				and \password_verify($_POST["mpass_pass"], \pulsecore\wedge\config\get_json_configs()->json->editor_user_password)
				and ($token_check == true)
				) {
		
			# check OTP password if its there
			$otp_password_verified = true;
			
			if (\pulsecore\wedge\config\get_json_configs()->json->editor_user_otp_activate === true) {
				$otp_password_verified = \pulsecore\otp_verify_password( $_POST['mpass_pass_otp'], \pulsecore\get_configs()->acl_role->editor );
			}
			
			if ($otp_password_verified === true) {
				$_SESSION["mpass_attempts"]        = 0;
				$_SESSION["mpass_session_expires"] = (time() + \pulsecore\get_configs()->session->max_session_time);
				
				$_SESSION["acl_role"] = \pulsecore\get_configs()->acl_role->editor;
				
				$encrypted_password_storage     = \crypt(\pulsecore\wedge\config\get_json_configs()->json->editor_user_password, \pulsecore\wedge\config\get_json_configs()->json->editor_user_password);
				$_SESSION["mpass_pass-{$path}"] = $encrypted_password_storage;
				
				$_SESSION["login_username"] = $param_username;
				
				$_SESSION["user_group_list"] = array();
				
				\session_write_close();
				
				\setcookie ("mpass_pass-$path", $encrypted_password_storage, (time() + \pulsecore\get_configs()->session->login->mpass_pass_cookie_lifetime),$path, $domain,false, true);
				\header("Location: " . login__redirect_url("index.php") );
				die();
			}
		}
	}
	
	# username neither administrator nor editor
	if (isset(\pulsecore\wedge\config\get_json_configs()->json->user_list->{$param_username})) {
		
		$datum_user = \pulsecore\wedge\config\get_json_configs()->json->user_list->{$param_username};
		
		if (    \password_verify($_POST["mpass_pass"], $datum_user->password)
				and ($token_check == true) ) {
			
			# check OTP password if its there
			$otp_password_verified = true;
			
			if ($datum_user->otp_activate === true) {
				$otp_password_verified = \pulsecore\otp_verify_password( $_POST['mpass_pass_otp'], $datum_user->acl_role );
			}
			
			if ($otp_password_verified === true) {
				$_SESSION["mpass_attempts"]        = 0;
				$_SESSION["mpass_session_expires"] = (\time() + \pulsecore\get_configs()->session->max_session_time);
				
				$_SESSION["acl_role"] = $datum_user->acl_role;
				
				$encrypted_password_storage     = \crypt($datum_user->password, $datum_user->password);
				$_SESSION["mpass_pass-{$path}"] = $encrypted_password_storage;
				
				$_SESSION["login_username"] = $param_username;
				
				$_SESSION["user_group_list"] = $datum_user->user_group_list;
				
				\session_write_close();
				
				\setcookie ("mpass_pass-$path", $encrypted_password_storage, (time() + \pulsecore\get_configs()->session->login->mpass_pass_cookie_lifetime), $path, $domain, false, true);
				\header("Location: " . login__redirect_url("index.php") );
				exit;
			}
		}
	}
	
}

//if no failed attempts yet, set to 0
if (empty($_SESSION["mpass_attempts"])) {
	$_SESSION["mpass_attempts"] = 0;
}

//failed attempt or session expired
if (    \pulsecore\acl_role\is_session_expired(    $_SESSION)
		or !\pulsecore\acl_role\is_valid_session_token($_SESSION, $path)
		) {
	
	sleep(1);
	
	#\pulsecore\session\cleanup();
	$_SESSION['acl_role'] = 'guest';
	
	if (isset($_SESSION["mpass_pass-{$path}"]) and (crypt($cmp_pass,$_SESSION["mpass_pass-{$path}"]) != $_SESSION["mpass_pass-{$path}"])) {
		$_SESSION["mpass_attempts"]++;
	}
	
	if (($max_attempts > 1) and ($_SESSION["mpass_attempts"] >= $max_attempts)) {
	    
		exit("Too many login failures.");
	}

	$_SESSION["mpass_session_expires"] = "";
?>
<!DOCTYPE html>
<html>
<head>
		<title><?php echo $lang_title; ?></title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<link rel="stylesheet" href="<?php echo $path.'/'.$admin; ?>/css/admin.css" media="all" />
		<link rel="stylesheet" href="<?php echo $path.'/'.$admin; ?>/css/animate.css" />
		<link rel="stylesheet" href="<?php echo $path.'/'.$admin; ?>/css/login.css" />
	<script src="<?php echo $path.'/'.$admin; ?>/js/jquery.js"></script>
	<link rel="shortcut icon" type="image/ico" href="<?php echo $path; ?>/content/media/branding/favicon.ico" />
	<link rel="apple-touch-icon-precomposed" href="<?php echo $path; ?>/content/media/branding/apple-touch-icon.png" />
</head>
<body id="login-page">
	
	<div id="logo"></div>
	
	<div id="login-form" class="animated fadeInDown">
		    
		<div id="avatarArea"></div>
		     
		<h1 class="flash"><?php echo ((\strlen(\pulsecore\wedge\config\get_json_configs()->json->template->admin_login_welcome) > 0) ? \pulsecore\wedge\config\get_json_configs()->json->template->admin_login_welcome : "<span>{$GLOBALS['lang_login_welcome']}</span> {$GLOBALS['lang_login_name']}"); ?></h1>
		
		<form name="login" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" id="login">
			      
			<?php if (     !empty($_POST["mpass_pass"])
								and !(\password_verify($_POST["mpass_pass"], $cmp_pass) or \password_verify($_POST["mpass_pass"], \pulsecore\wedge\config\get_json_configs()->json->editor_user_password))
								) {
							echo "<p class='errorMsg animated shake'>$lang_login_incorrect</p>";
						}
				foreach (\pulsecore\session\status_get_all() as $msg) {
					?>
					<p class='errorMsg animated shake'><?php echo \htmlentities($msg->message); ?></p>
					<?php
				}
			?>
			
			<input name="username" list="user_list" autofocus required />
			<datalist id="user_list">
				<option value="administrator">administrator</option>
				<option value="editor">editor</option>
				<?php foreach (\pulsecore\wedge\config\get_json_configs()->json->user_list as $value) { ?>
					<option value="<?php echo \htmlentities($value->username); ?>"><?php echo \htmlentities($value->username); ?></option>
				<?php } ?>
			</datalist>
			
			<input type="password" size="27" id="password" name="mpass_pass"     placeholder="<?php echo $lang_login_password;?>" />
			
			<?php if (\pulsecore\wedge\config\get_json_configs()->json->otp_activate === true) { ?>
				<input type="password" size="27" id="password" class="otp" name="mpass_pass_otp" placeholder="<?php echo $lang_login_otp;?>" />
			<?php } ?>
			
			<input type="hidden" name="log_token" value="<?php echo $_SESSION["log_token"]; ?>" />
			
			<button class="btn login-btn"><?php echo $lang_login_button;?></button>
			
			<p class="forgot_password">
				<a href="<?php echo $path; ?>/<?php echo $admin; ?>/index.php?p=login_forgot_password"><?php echo \htmlspecialchars($lang_login_forgot_password); ?></a>
			</p>
		</form>
	</div>
</body>

</html>
<?php 
exit();
}
$_SESSION["mpass_attempts"]        = 0;
$_SESSION["mpass_session_expires"] = (time() + \pulsecore\get_configs()->session->max_session_time);
?>