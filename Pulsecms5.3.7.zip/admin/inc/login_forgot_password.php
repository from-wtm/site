<?php
/**
 * forgot password handler
 */
# ===========================================================================>
require_once (PULSE_BASE_DIR . '/pulsecore/filter.php');

#start the session_cache_expire handling
\session_start();

# ===========================================================================>
/**
 * page processed here
 * NB session affected
 * \return void
 */
function login_forgot_password__process( array $params ) {
	
	# rate limit calls
	if (!isset($_SESSION['login_forgot_password'])) {
		
		$_SESSION['login_forgot_password'] = time() - 100; # set in the past for the first call
	}
	
	# process
	if ((\time() - $_SESSION['login_forgot_password']) > 60) {
		
		$_SESSION['login_forgot_password'] = time();
		
		$email_list = \pulsecore\wedge\config\get_json_configs()->json->email_contact;
		
		#set up the mailer
		$mail = new \PHPMailer\PHPMailer\PHPMailer();
		
		if (    (\strlen(\pulsecore\wedge\config\get_json_configs()->json->smtp_host    ) >  0)
				and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->smtp_username) >  0)
				and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->smtp_password) >  0)
				and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->smtp_port    ) >  0)
			) {
				// If your host requires smtp authentication, uncomment and fill out the lines below. 
				$mail->isSMTP();                                                                      // Do nothing here
				$mail->Host       = \pulsecore\wedge\config\get_json_configs()->json->smtp_host;      // Specify main server
				$mail->SMTPAuth   = true;                                                             // Do nothing here
				$mail->Username   = \pulsecore\wedge\config\get_json_configs()->json->smtp_username;  // SMTP username
				$mail->Password   = \pulsecore\wedge\config\get_json_configs()->json->smtp_password;  // SMTP password
				$mail->Port       = \pulsecore\wedge\config\get_json_configs()->json->smtp_port;      // SMTP port 	
				$mail->SMTPSecure = 'tls';                                                            // Enable encryption, 'ssl' also accepted
				
				#$mail->SMTPDebug = 2;
		}
		
		$mail->From     = reset($email_list);
		$mail->FromName = $GLOBALS['lang_login_forgot_password_email_subject_line'];
		
		foreach ($email_list as $email) {
			$mail->addAddress($email);
		}
		
		$mail->Subject  = $GLOBALS['lang_login_forgot_password_email_subject_line'];
		$mail->Body     = \str_replace( 'PASSWORD',
																		 (\pulsecore\wedge\config\get_json_configs()->json->password_cleartext . ' and OPT password: ' . (\pulsecore\wedge\config\get_json_configs()->json->password_otp)),
																		 $GLOBALS['lang_login_forgot_password_email_body']
																		);
				
		$mail->send();
		
		\pulsecore\session\status_add( $GLOBALS['lang_login_forgot_password_message'] );
		
	} else {
		# rate limit for password reset
		
	}
	
	#redirect back to login page
	\header("Location: index.php" );
	exit;
}
# ===========================================================================>
# ===========================================================================>
# ===========================================================================>

login_forgot_password__process( \array_merge($_GET, $_POST) );

# ===========================================================================>
# ===========================================================================>
# ===========================================================================>
