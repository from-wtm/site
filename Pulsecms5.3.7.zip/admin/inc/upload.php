<?php

require_once (PULSE_ADMIN_DIR . '/inc/media_upload_handler.php');
