<?php
# require_once (PULSE_ADMIN_DIR . '/inc/login.php'); # redundant admin/index.php includes login.php already

# generates a warning since its called after the session starts
# \session_set_cookie_params(0, \pulsecore\wedge\config\get_json_configs()->json->path, $GLOBALS['domain'], false, true);

# nuke page caches
$cache_manager = new \pulsecore\cache\Manager();
$cache_pool    = $cache_manager->pool( \pulsecore\cache\Manager::DAY_1 );
$cache_pool->nuke_tags( array('page') );

/*
$cmp_pass = \md5($password);
$domain = $_SERVER['SERVER_NAME'];

if (\crypt($cmp_pass,$_SESSION["mpass_pass-$path"] == $_SESSION["mpass_pass-$path"])) {
	unset($_SESSION["mpass_pass-$path"]);
	$_SESSION["mpass_attempts"]        = 0;
	$_SESSION["mpass_session_expires"] = 0;
	\setcookie ("mpass_pass-$path","", time() + \pulsecore\get_configs()->session->login->mpass_pass_cookie_lifetime, $path, $domain, false, true);
}
*/

# nuke mpass-pass cookie
\setcookie ("mpass_pass-{$GLOBALS['path']}","", \time() - \pulsecore\get_configs()->session->login->mpass_pass_cookie_lifetime, $GLOBALS['path'], $GLOBALS['domain'], false, true);

\pulsecore\session\cleanup();

$_SESSION["acl_role"] = 'guest';

# regenerate the session ID
\session_regenerate_id();

# destroy session save to ensure storage is cleared on the backend
\session_destroy();

\header("Location: index.php");
die();
