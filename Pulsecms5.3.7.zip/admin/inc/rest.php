<?php

require_once (PULSE_BASE_DIR . '/config.php');

include_once (PULSE_ADMIN_DIR . '/inc/login.php');

# check editor permissions
\pulsecore\acl_role\is_editor_allowed();

/**
 * admin REST handler - NB has some non REST quirks 
 */
function page_rest() {
	
	$page_handler = new \pulsecore\page\admin\Rest();
	echo $page_handler->process(
		$_GET,
		$_POST,
		$_COOKIE,
		(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'get')
	);
}

# call
echo page_rest();
