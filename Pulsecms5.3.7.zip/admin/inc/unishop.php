<?php

require_once (PULSE_BASE_DIR . '/pulsecore/wedge/config.php');
require_once (PULSE_BASE_DIR . '/pulsecore/wedge/config_edit.php');

require_once (PULSE_ADMIN_DIR . '/inc/login.php');

# check editor permissions
\pulsecore\acl_role\is_editor_allowed();

/**
 * process the page
 */
function page_unishop () {
	
	$page = new \pulsecore\page\admin\Unishop();
	
	$result = $page->process(
		$_GET,
		$_POST,
		$_COOKIE,
		(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'get')
	);
	
	return $result;
}

# call
echo page_unishop();
