<?php

require_once (PULSE_BASE_DIR . '/pulsecore/wedge/config.php');
require_once (PULSE_BASE_DIR . '/pulsecore/wedge/config_edit.php');

require_once (PULSE_BASE_DIR . '/pulsecore/theme.php');

require_once (PULSE_ADMIN_DIR . '/inc/login.php');

#check editor permissions
\pulsecore\acl_role\is_editor_allowed();

#handle form post
if (isset($_POST['save_configs'])) {
	
	\pulsecore\wedge\config_edit\process_form( $_POST );
	
	# status message
	\pulsecore\session\status_add( $GLOBALS['lang_status_ok'] );
	
	#redirect
	\header('Location: index.php?p=settings');
	exit;
}

# page list to select home page from
$page_list = \pulsecore\store\page\Base::list_pages_only( \pulsecore\get_configs()->dir_content . '/pages' );

$page_list_cleaned = array();

foreach ($page_list as $page) {
	
	$page_location = $page->get_location();
	$page_location = \str_replace( 'pages/', '', $page_location );
	
	$page_list_cleaned[ $page_location ] = $page_location;
}

?>

<!-- bread crumbs -->
<div class="breadcrumb">
	<?php include ('breadcrumbs.php'); ?>	
</div>

<div class="pulsecore">
	
	<form class="create-form wide" name="textfile" method="post" action="index.php?p=settings">
		
		<div class="tab_container">
			<h1><?php echo $GLOBALS['lang_settings_title']; ?></h1>
			<input id="tab1" type="radio" name="tabs" checked />
			<label for="tab1"><i class="fa fa-bolt"></i><span><?php echo $GLOBALS['lang_settings_general']; ?></span></label>
			
			<input id="tab2" type="radio" name="tabs" />
			<label for="tab2"><i class="fa fa-check-square"></i><span><?php echo $GLOBALS['lang_settings_forms']; ?></span></label>
			
			<input id="tab3" type="radio" name="tabs" />
			<label for="tab3"><i class="fa fa-shield-alt"></i><span><?php echo $GLOBALS['lang_settings_security']; ?></span></label>
			
			<input id="tab4" type="radio" name="tabs" />
			<label for="tab4"><i class="fa fa-user"></i><span><?php echo $GLOBALS['lang_settings_permissions']; ?></span></label>
			
			<input id="tab5" type="radio" name="tabs" />
			<label for="tab5"><i class="fa fa-paint-brush"></i><span><?php echo $GLOBALS['lang_settings_extend']; ?></span></label>
			
			<script type="text/javascript" async defer>
				(function () {
						// jump to a tab
						var url = window.location.href;
						var fragment = url.split('#');
						
						if (fragment.length == 2) {
							fragment = fragment[1];
							console.log( fragment );
							jQuery( '#' + fragment ).click();
						}
					}
				)();
			</script>
			
			<!-- general -->
			<section id="content1" class="tab-content">
				<h3><?php echo $GLOBALS['lang_settings_general']; ?></h3>
				
				<?php
					# autodetect the path
					if (\strlen($path) == 0) {
						$path = \pulsecore\autodetect_root_path( $_SERVER['REQUEST_URI'], (PULSE_ADMIN_URL . '/index.php') );
					}
				?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'path',         'textfield', $path,        $GLOBALS['lang_settings_path_tooltip'],     $GLOBALS['lang_settings_path'],     array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'admin',        'textfield', $admin,       $GLOBALS['lang_settings_admin_tooltip'],    $GLOBALS['lang_settings_admin'],    array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'password',     'textfield', '',           $GLOBALS['lang_settings_password_tooltip'], $GLOBALS['lang_settings_password'], array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'old_password', 'hidden',    $password,    'password',                                 'password',                         array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'home_page',  'select', \pulsecore\wedge\config\get_json_configs()->json->home_page, 'home page selection', $GLOBALS['lang_settings_home_page'], $page_list_cleaned ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'autobackup',       'boolean',   $autobackup,                                                        'autobackup',       $GLOBALS['lang_settings_backup_tooltip'],       array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'autobackup_email', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->autobackup_email, $GLOBALS['lang_settings_backupemail_tooltip'], $GLOBALS['lang_settings_backupemail'], array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'date_default_timezone_set', 'select', \date_default_timezone_get(), 'default timezone', $GLOBALS['lang_settings_time'], \DateTimeZone::listIdentifiers() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'language',     'select',    $language,     'language',     $GLOBALS['lang_settings_language'],     \pulsecore\get_configs()->languages ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'front_page_display',       'select', \pulsecore\wedge\config\get_json_configs()->json->front_page_display,       'front page display',       $GLOBALS['lang_settings_frontpage'],      \pulsecore\get_configs()->front_page_display_options ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'admin_front_page_display', 'select', \pulsecore\wedge\config\get_json_configs()->json->admin_front_page_display, 'admin front page display', $GLOBALS['lang_settings_adminfrontpage'], \pulsecore\get_configs()->admin_front_page_display_options ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'administrator_name',       'textfield', \pulsecore\wedge\config\get_json_configs()->json->administrator_name,    $GLOBALS['lang_settings_adminname_tooltip'],       $GLOBALS['lang_settings_adminname'],       array() ); ?>
				
				<p><a href='index.php?p=avatar' class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_avatar_upload']; ?></a></p>
				<br/>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'inline_css', 'textarea',   \pulsecore\wedge\config\get_json_configs()->json->inline->css, $GLOBALS['lang_settings_css_tooltip'], $GLOBALS['lang_settings_css'], array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'inline_js',  'textarea',   \pulsecore\wedge\config\get_json_configs()->json->inline->js,  $GLOBALS['lang_settings_js_tooltip'],  $GLOBALS['lang_settings_js'],  array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_gdpr']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'gdpr_enable_in_form', 'boolean',  \pulsecore\wedge\config\get_json_configs()->json->gdpr->enable_in_form, 'enable gdpr in form tags', $GLOBALS['lang_settings_gdpr_enable_in_form'], array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'gdpr_enable_in_tag', 'boolean',   \pulsecore\wedge\config\get_json_configs()->json->gdpr->enable_in_tag, 'enable gdpr in tag', $GLOBALS['lang_settings_gdpr_enable_in_tag'],                                  array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'gdpr_tag_text',      'textfield', \pulsecore\wedge\config\get_json_configs()->json->gdpr->tag_text,                            $GLOBALS['lang_settings_gdpr_tag_text_tooltip'], $GLOBALS['lang_settings_gdpr_tag_text'], array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_cache']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'cache_html_enable', 'boolean',  \pulsecore\wedge\config\get_json_configs()->json->cache_html_enable, 'otp cache_html_enable', $GLOBALS['lang_settings_cache'], array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_editor']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'wysiwyg', 'boolean',   $wysiwyg,                 'wysiwyg', $GLOBALS['lang_settings_wysiwyg'], array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'allow',   'textfield', \implode(', ', $allow),   $GLOBALS['lang_settings_upload_tooltip'],   $GLOBALS['lang_settings_upload'],   array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'wysiwyg_on_page', 'boolean', \pulsecore\wedge\config\get_json_configs()->json->wysiwyg_on_page, 'wysiwyg_on_page', $GLOBALS['lang_settings_wysiwygpages'], array() ); ?>
				
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_media']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'jpeg_quality',        'textfield', $jpeg_quality,        $GLOBALS['lang_settings_jpeg_tooltip'],        $GLOBALS['lang_settings_jpeg'],        array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'jpeg_resampling_off', 'boolean',   $jpeg_resampling_off, 'jpeg_resampling_off', $GLOBALS['lang_settings_jpegresample'], array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'jpeg_size',           'textfield', $jpeg_size,           $GLOBALS['lang_settings_jpegsize_tooltip'],           $GLOBALS['lang_settings_jpegsize'],           array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'thumbnail_height',    'textfield', $thumbnail_height,    $GLOBALS['lang_settings_thumbheight_tooltip'],    $GLOBALS['lang_settings_thumbheight'],    array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'create_thumbnails',   'boolean',   $create_thumbnails,   'create_thumbnails',   $GLOBALS['lang_settings_thumb'],   array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_made_in_pulse']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'made_in_pulse', 'boolean',  \pulsecore\wedge\config\get_json_configs()->json->made_in_pulse, $GLOBALS['lang_settings_made_in_pulse_label'], $GLOBALS['lang_settings_made_in_pulse'], array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'theme_meta_author_show', 'boolean',  \pulsecore\wedge\config\get_json_configs()->json->theme_meta_author_show, $GLOBALS['lang_settings_theme_meta_author_show_label'], $GLOBALS['lang_settings_theme_meta_author_show'], array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_navigation']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'navigation_options_logged_in_menu', 'select', \pulsecore\wedge\config\get_json_configs()->json->navigation_options->logged_in_menu, 'navigation_options_logged_in_menu', $GLOBALS['lang_settings_navigationmenu'], \pulsecore\get_configs()->navigation_options->logged_in_menu ); ?>
				<!--<p><a href='index.php?p=manage_navigation' class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_title_managenavigation']; ?></a></p>
				<br />-->
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_geoip']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'geoip_enable',  'boolean',   \pulsecore\wedge\config\get_json_configs()->json->geoip_enable,   $GLOBALS['lang_settings_geoip_label'],           $GLOBALS['lang_settings_geoip'],         array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'geoip_service', 'select_kv', \pulsecore\wedge\config\get_json_configs()->json->geoip->service, $GLOBALS['lang_settings_geoip_service_tooltip'], $GLOBALS['lang_settings_geoip_service'], \pulsecore\get_configs()->geoip->service_options ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'geoip_api_key', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->geoip->api_key, $GLOBALS['lang_settings_geoip_api_key_tooltip'], $GLOBALS['lang_settings_geoip_api_key'], array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_google']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'google_analytics', 'textarea',   \pulsecore\wedge\config\get_json_configs()->json->google_analytics, $GLOBALS['lang_settings_google_tooltip'], $GLOBALS['lang_settings_google'], array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'anonymize_ip', 'boolean',   $anonymize_ip, 'anonymize_ip', $GLOBALS['lang_settings_ip'], array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_ogp']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'ogp_default_image', 'textfield', ((\strlen(\pulsecore\wedge\config\get_json_configs()->json->ogp_default_image) > 0) ? \pulsecore\wedge\config\get_json_configs()->json->ogp_default_image : \pulsecore\get_configs()->ogp_default_image), $GLOBALS['lang_settings_ogp_tooltip'],   $GLOBALS['lang_settings_ogp'],     array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'ogp_facebook_admin',   'textfield', \pulsecore\wedge\config\get_json_configs()->json->ogp_facebook_admin,   $GLOBALS['lang_settings_ogp_facebook_admin_tooltip'],   $GLOBALS['lang_settings_ogp_facebook_admin'],   array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'ogp_facebook_id',      'textfield', \pulsecore\wedge\config\get_json_configs()->json->ogp_facebook_id,      $GLOBALS['lang_settings_ogp_facebook_id_tooltip'],      $GLOBALS['lang_settings_ogp_facebook_id'],      array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'ogp_twitter_creator',  'textfield', \pulsecore\wedge\config\get_json_configs()->json->ogp_twitter_creator,  $GLOBALS['lang_settings_ogp_twitter_creator_tooltip'],  $GLOBALS['lang_settings_ogp_twitter_creator'],  array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'ogp_twitter_username', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->ogp_twitter_username, $GLOBALS['lang_settings_ogp_twitter_username_tooltip'], $GLOBALS['lang_settings_ogp_twitter_username'], array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_blog']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'result_per_page',  'textfield', $result_per_page,  'result_per_page',  $GLOBALS['lang_settings_blogresults'],  array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'disqus_comments',  'boolean',   $disqus_comments,  'disqus_comments',  $GLOBALS['lang_settings_blogdisqus'],  array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'disqus_shortname', 'textfield', $disqus_shortname, $GLOBALS['lang_settings_blogdisqususer_tooltip'], $GLOBALS['lang_settings_blogdisqususer'], array() ); ?>
				
				<?php /* echo \pulsecore\wedge\config_edit\render_form_row( 'date_format', 'select',    $date_format, $GLOBALS['lang_settings_blogdate_tooltip'],       $GLOBALS['lang_settings_blogdate'],       \pulsecore\get_configs()->date_format->{$language} ); */ ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'date_format', 'textfield', $date_format, $GLOBALS['lang_settings_blogdate_tooltip'],       $GLOBALS['lang_settings_blogdate'],       \pulsecore\get_configs()->date_format->{$language} ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'blog_flag_reverse',   'boolean', \pulsecore\wedge\config\get_json_configs()->json->blog_flag_reverse,   'blog flaf reverse', $GLOBALS['lang_settings_blog_flag_reverse'],        array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'blog_page_masonry',   'boolean', \pulsecore\wedge\config\get_json_configs()->json->blog_page_masonry,   'blog page masonry', $GLOBALS['lang_settings_blogmasonry'],              array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'blog_flag_show_link', 'boolean', \pulsecore\wedge\config\get_json_configs()->json->blog_flag_show_link, 'blog flag link',    $GLOBALS['lang_settings_blog_blog_flag_show_link'], array() ); ?>
				<p><a href='index.php?p=manage_tags' class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_manage_tags']; ?></a></p>
				<!-- -->
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_rss']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'blog_title',       'textfield', $blog_title,       $GLOBALS['lang_settings_rsstitle_tooltip'],       $GLOBALS['lang_settings_rsstitle'],       array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'blog_description', 'textfield', $blog_description, $GLOBALS['lang_settings_rssdescription_tooltip'], $GLOBALS['lang_settings_rssdescription'], array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'blog_url',         'textfield', $blog_url,         $GLOBALS['lang_settings_rssurl_tooltip'],         $GLOBALS['lang_settings_rssurl'],         array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'rss_lang',         'textfield', $rss_lang,         $GLOBALS['lang_settings_rsslang_tooltip'],        $GLOBALS['lang_settings_rsslang'],        array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'url_prefix',       'textfield', $url_prefix,       $GLOBALS['lang_settings_rssurlprefix_tooltip'],   $GLOBALS['lang_settings_rssurlprefix'],   array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_smtp']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'smtp_username', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->smtp_username, $GLOBALS['lang_settings_smtpusername_tooltip'], $GLOBALS['lang_settings_smtpusername'], array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'smtp_password', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->smtp_password, $GLOBALS['lang_settings_smtppassword_tooltip'], $GLOBALS['lang_settings_smtppassword'], array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'smtp_host',     'textfield', \pulsecore\wedge\config\get_json_configs()->json->smtp_host,     $GLOBALS['lang_settings_smtphost_tooltip'],     $GLOBALS['lang_settings_smtphost'],     array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'smtp_port',     'textfield', \pulsecore\wedge\config\get_json_configs()->json->smtp_port,     $GLOBALS['lang_settings_smtpport_tooltip'],     $GLOBALS['lang_settings_smtpport'],     array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_sweetalert']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'sweetalert_active',  'boolean',   \pulsecore\wedge\config\get_json_configs()->json->sweetalert->active,  $GLOBALS['lang_settings_sweetalert_active_tooltip'],  $GLOBALS['lang_settings_sweetalert_active'],  array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'sweetalert_timeout', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->sweetalert->timeout, $GLOBALS['lang_settings_sweetalert_timeout_tooltip'], $GLOBALS['lang_settings_sweetalert_timeout'], array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_template_strings']; ?></h3>
				
				<?php
					$default_value_template_admin_login_welcome = ((\strlen(\pulsecore\wedge\config\get_json_configs()->json->template->admin_login_welcome) > 0) ? \pulsecore\wedge\config\get_json_configs()->json->template->admin_login_welcome : "<span>{$GLOBALS['lang_login_welcome']}</span> {$GLOBALS['lang_login_name']}");
					echo \pulsecore\wedge\config_edit\render_form_row( 'template_string_admin_login_welcome', 'textfield', $default_value_template_admin_login_welcome, $GLOBALS['lang_settings_template_string_admin_login_welcome_tooltip'], $GLOBALS['lang_settings_template_string_admin_login_welcome'],  array() );
				?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_pagination']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'pagination_page_links_to_show',     'textfield', \pulsecore\wedge\config\get_json_configs()->json->pagination_page_links_to_show,     $GLOBALS['lang_settings_paginationlinks_tooltip'], $GLOBALS['lang_settings_paginationlinks'], array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'pagination_admin_results_per_page', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->pagination_admin_results_per_page, $GLOBALS['lang_settings_paginationpages_tooltip'], $GLOBALS['lang_settings_paginationpages'], array() ); ?>
				
			
			</section>
			
			<!-- forms -->
			<section id="content2" class="tab-content">
				<h3><?php echo $GLOBALS['lang_settings_forms']; ?></h3>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'mail_inputs_name',  'textfield', $mail_inputs->Name,  $GLOBALS['lang_settings_forminputname'],          $GLOBALS['lang_settings_forminputname'],  array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'mail_inputs_email', 'textfield', $mail_inputs->Email, $GLOBALS['lang_settings_forminputemail_tooltip'], $GLOBALS['lang_settings_forminputemail'], array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'mail_inputs_phone', 'textfield', $mail_inputs->Phone, $GLOBALS['lang_settings_forminputtel_tooltip'],   $GLOBALS['lang_settings_forminputtel'],   array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'lang_form_name',    'textfield', $GLOBALS['lang_form_name'],  $GLOBALS['lang_settings_formnamename_tooltip'],  $GLOBALS['lang_settings_formnamename'],   array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'lang_form_email',   'textfield', $GLOBALS['lang_form_email'], $GLOBALS['lang_settings_formemailname_tooltip'], $GLOBALS['lang_settings_formemailname'],  array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'lang_form_comment', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->lang_form_comment, $GLOBALS['lang_settings_formcommentname_tooltip'], $GLOBALS['lang_settings_formcomment'], array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'lang_form_gdpr',    'textfield', \pulsecore\wedge\config\get_json_configs()->json->lang_form_gdpr,    $GLOBALS['lang_settings_form_gdpr_name_tooltip'],  $GLOBALS['lang_settings_form_gdpr'],   array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'lang_form_phone',   'textfield', \pulsecore\wedge\config\get_json_configs()->json->lang_form_phone,   $GLOBALS['lang_settings_formphonename_tooltip'],   $GLOBALS['lang_settings_formphone'],   array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'mail_textarea_comment', 'textfield', $mail_textarea->Comment, $GLOBALS['lang_settings_formtextarea_tooltip'], $GLOBALS['lang_settings_formtextarea'], array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'email_contact',   'textfield', \implode(', ', $email_contact),   $GLOBALS['lang_settings_formemail_tooltip'],   $GLOBALS['lang_settings_formemail'],   array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'config_contact_form_subject_line', 'textfield', (isset(\pulsecore\wedge\config\get_json_configs()->json->config_contact_form_subject_line) ? \pulsecore\wedge\config\get_json_configs()->json->config_contact_form_subject_line : $GLOBALS['lang_form_subject_line']), $GLOBALS['lang_settings_formsubject_tooltip'], $GLOBALS['lang_settings_formsubject'], array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'config_contact_form_auto_thank', 'boolean', \pulsecore\wedge\config\get_json_configs()->json->config_contact_form_auto_thank, 'config_contact_form_auto_thank', $GLOBALS['lang_settings_formthanks'], array() ); ?>
				
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'contact_form_redirect', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->contact_form_redirect, $GLOBALS['lang_settings_formredirect_tooltip'], $GLOBALS['lang_settings_formredirect'], array() ); ?>
				
			</section>
			
			<!-- security -->
			<section id="content3" class="tab-content">
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_otp']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'otp_activate',      'boolean',   \pulsecore\wedge\config\get_json_configs()->json->otp_activate,      'otp_activate',      $GLOBALS['lang_settings_otpactivate'],      array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'otp_shared_secret', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->otp_shared_secret, $GLOBALS['lang_settings_otpsecret_tooltip'], $GLOBALS['lang_settings_otpsecret'], array() ); ?>
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_recap']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'recapcha_site_key',   'textfield', \pulsecore\wedge\config\get_json_configs()->json->recapcha_site_key,   $GLOBALS['lang_settings_recapkey_tooltip'],       $GLOBALS['lang_settings_recapkey'],       array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'recapcha_secret_key', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->recapcha_secret_key, $GLOBALS['lang_settings_recapkeysecret_tooltip'], $GLOBALS['lang_settings_recapkeysecret'], array() ); ?>
				
				
			</section>
			
			<!-- permissions -->
			<section id="content4" class="tab-content">
				
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_editor']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'editor_user_enable',       'boolean',   \pulsecore\wedge\config\get_json_configs()->json->editor_user_enable,   'editor_user_enable',       $GLOBALS['lang_settings_editor'],       array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'editor_user_password',     'textfield', '',                                                                     $GLOBALS['lang_settings_editorpass_tooltip'],     $GLOBALS['lang_settings_editorpass'],     array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'editor_user_old_password', 'hidden',    \pulsecore\wedge\config\get_json_configs()->json->editor_user_password, 'editor_user_old_password', 'editor_user_old_password', array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'editor_name',              'textfield', \pulsecore\wedge\config\get_json_configs()->json->editor_name,          $GLOBALS['lang_settings_editoruser_tooltip'],              $GLOBALS['lang_settings_editoruser'],              array() ); ?>
				
				<h4><?php echo $GLOBALS['lang_settings_title_editorotp']; ?></h4>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'editor_user_otp_activate',      'boolean',   \pulsecore\wedge\config\get_json_configs()->json->editor_user_otp_activate,      'otp activate',      $GLOBALS['lang_settings_editorotpactivate'],      array() ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'editor_user_otp_shared_secret', 'textfield', \pulsecore\wedge\config\get_json_configs()->json->editor_user_otp_shared_secret, $GLOBALS['lang_settings_editorotpsecret_tooltip'], $GLOBALS['lang_settings_editorotpsecret'], array() ); ?>
				
				
				<h4><?php echo $GLOBALS['lang_settings_title_editoraccess']; ?></h4>
				<?php
					$block_list = \pulsecore\store\block\Base::list_blocks_only( \pulsecore\get_configs()->dir_content . '/blocks' );
					
					foreach ($block_list as $block) {
						
						$block_location = $block->get_location() . '.txt';
				?>
					<?php echo \pulsecore\wedge\config_edit\render_form_row(
							"editor_acl_resource_block[{$block_location}]",
							'boolean',
							(
								         isset(\pulsecore\wedge\config\get_json_configs()->json->editor_acl_resource_block->{$block_location})
								and ('true' == \pulsecore\wedge\config\get_json_configs()->json->editor_acl_resource_block->{$block_location})
							),
							$block_location,
							$block_location,
							array()
						); ?>
				<?php } ?>
				
				<h4><?php echo $GLOBALS['lang_settings_title_editorpagesaccess']; ?></h4>
				<?php
					foreach ($page_list as $page) {
						
						$page_location = $page->get_location() . '.txt';
				?>
					<?php echo \pulsecore\wedge\config_edit\render_form_row(
						"editor_acl_resource_page[{$page_location}]",
						'boolean',
						(
							         isset(\pulsecore\wedge\config\get_json_configs()->json->editor_acl_resource_page->{$page_location})
							and ('true' == \pulsecore\wedge\config\get_json_configs()->json->editor_acl_resource_page->{$page_location})
						),
						$page_location,
						$page_location,
						array()
						); ?>
				<?php } ?>
			</section>
			
			<!-- styles -->
			<section id="content5" class="tab-content">
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_themes']; ?></h3>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'theme_selected', 'select', \pulsecore\wedge\config\get_json_configs()->json->theme_selected, 'theme_selected',  $GLOBALS['lang_settings_themeselect'],  \pulsecore\theme\get_themes() ); ?>
				<p><a href='index.php?p=template_upload_handler' class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_themeupload']; ?></a></p>
				<br />
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_plugins']; ?></h3>
				<p><a href='index.php?p=plugin_upload_handler' class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_pluginupload']; ?></a></p>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'integrate_rapidweaver', 'boolean', \pulsecore\wedge\config\get_json_configs()->json->integrate_rapidweaver, 'integrate_rapidweaver', $GLOBALS['lang_settings_integrate_rapidweaver'], [] ); ?>
				<?php echo \pulsecore\wedge\config_edit\render_form_row( 'integrate_ecommerce', 'boolean', \pulsecore\wedge\config\get_json_configs()->json->integrate_ecommerce, 'integrate_ecommerce', $GLOBALS['lang_settings_integrate_ecommerce'], [] ); ?>
				<br />
				<!-- -->
				<h3><?php echo $GLOBALS['lang_settings_title_customposts']; ?></h3>
				<p><a href='index.php?p=custom_post_type_definitions' class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_managecustomposts']; ?></a></p>
				<!-- -->
				<!--<h3><?php echo $GLOBALS['lang_settings_title_user_list']; ?></h3>
				<p><a href='index.php?p=manage_user_list'       class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_manage_user_list']; ?></a></p>
				<p><a href='index.php?p=manage_user_group_list' class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_manage_user_group_list']; ?></a></p>-->
				<!-- -->
				<!--<h3><?php echo $GLOBALS['lang_settings_title_debug_info']; ?></h3>
				<p><a href='index.php?p=debug_info' class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_manage_debug_info']; ?></a></p>
				<p><a href='index.php?p=log_viewer' class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_manage_log_viewer']; ?></a></p>-->
				<!-- -->
				<!--<h3><?php echo $GLOBALS['lang_settings_title_update']; ?></h3>
				<p><a href='index.php?p=update' class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_manage_update']; ?></a></p>-->
				<!-- -->
				
				<!-- -->
				<!--<h3><?php echo $GLOBALS['lang_settings_unishop_title']; ?></h3>
				<p><a href='index.php?p=unishop' class="cancel btn toggle_duplicate_btn"><?php echo $GLOBALS['lang_settings_unishop_update']; ?></a></p>-->
			</section>
	</div>
	
	<input type="hidden" name="token" value="<?php echo (isset($_SESSION["token"]) ? $_SESSION["token"] : ''); ?>" />
		
		<!-- -->
		
		<br />
		<br />
		
		<button class="btn" type="submit" name="save_configs"><?php echo $GLOBALS['lang_save']; ?></button>
		<p style="margin:0;float:right;"><a href="https://help.pulsecms.com/article/10-version-history" target="_blank">v. <?php echo $pulse_version;?></a></p>
		
	</form>
</div>
