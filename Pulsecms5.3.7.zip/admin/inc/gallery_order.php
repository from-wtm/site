<?php
require_once (PULSE_BASE_DIR . '/config.php');
require_once (PULSE_ADMIN_DIR . '/inc/login.php');

/**
 * process the page
 */
function page_gallery_order() {
	
	$page = new \pulsecore\page\admin\GalleryOrder();
	
	$result = $page->process(
		$_GET,
		$_POST,
		$_COOKIE,
		(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'get')
	);
	
	return $result;
}

# call
echo page_gallery_order();
