<?php

require_once (PULSE_BASE_DIR . '/pulsecore/wedge/config.php');
require_once (PULSE_BASE_DIR . '/pulsecore/wedge/config_edit.php');

require_once (PULSE_ADMIN_DIR . '/inc/login.php');

#check editor permissions
\pulsecore\acl_role\is_editor_allowed();

/**
 * custom post type definition page handler
 */
function page_custom_post_type_definition_handler() {
	
	$page_handler = new \pulsecore\page\admin\CustomPostTypeDefinition();
	echo $page_handler->process(
		$_GET,
		$_POST,
		$_COOKIE,
		(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'get')
	);
}

# call
echo page_custom_post_type_definition_handler();
