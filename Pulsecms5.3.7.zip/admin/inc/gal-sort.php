<?php

\error_reporting(\E_STRICT|\E_ALL);

require_once (__DIR__ . '/../../symlink_safe.php');

require_once (PULSE_BASE_DIR . '/config.php');
require_once (PULSE_ADMIN_DIR . '/inc/login.php');

/**
 * process the page
 */
function page_gal_sort() {
	
	$page = new \pulsecore\page\admin\GalSort();
	
	$result = $page->process(
		$_GET,
		$_POST,
		$_COOKIE,
		(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'get')
	);
	
	return $result;
}

# call
echo page_gal_sort();
