<?php

\error_reporting(\E_STRICT|\E_ALL);

require_once (__DIR__ . '/../../../symlink_safe.php');

require_once (PULSE_BASE_DIR . '/pulsecore/wedge/config.php');

# require_once (PULSE_ADMIN_DIR . '/inc/login.php');

require_once (PULSE_BASE_DIR . '/pulsecore/filter.php');

$zip = $_GET['z'];

$zip = \pulsecore\filter\file_name( $zip ); # block any slashes in parameter

$local_file = \realpath(\pulsecore\get_configs()->dir_content . "/backups/{$zip}");

// set the download rate limit (=> 200 kb/s)
$download_rate = 200;
if (\file_exists($local_file) and \is_file($local_file)) {
	
	\header('Cache-control: private');
	\header('Content-Type: application/octet-stream');
	\header('Content-Length: ' . \filesize($local_file));
	\header('Content-Disposition: filename=' . \basename($local_file));
	
	\flush();
	
	$file = \fopen($local_file, "r");
	
	while (!\feof($file)) {
		// send the current file part to the browser
		print \fread($file, \round($download_rate * 1024));
		// flush the content to the browser
		\flush();
		// sleep one second
		\sleep(1);
	}
	
	\fclose($file);
	
} else {
	die('Error: The file '.$local_file.' does not exist!');
}
