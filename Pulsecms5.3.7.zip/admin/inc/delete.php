<?php

require_once (PULSE_ADMIN_DIR . '/inc/login.php');

/**
 * process the page
 */
function page_delete() {
	
	$page = new \pulsecore\page\admin\Delete();
	
	$result = $page->process(
		$_GET,
		$_POST,
		$_COOKIE,
		(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'get')
	);
	
	return $result;
}

# call
echo page_delete();
