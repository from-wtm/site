<?php

require_once (__DIR__ . '/symlink_safe.php');

require_once (PULSE_BASE_DIR . '/config.php');
require_once (PULSE_BASE_DIR . '/inc/plugins/parsedown.php');
require_once (PULSE_BASE_DIR . '/pulsecore/page/end_point.php');

#set up the globals
$parsedown = new \Parsedown();

#set up the globals - language
require_once (PULSE_BASE_DIR . "/{$admin}/inc/lang/english.php");
if (!empty($language) and \file_exists(PULSE_BASE_DIR . "/{$admin}/inc/lang/{$language}.php")) {
	require_once (PULSE_BASE_DIR . "/{$admin}/inc/lang/{$language}.php");
}

/**
 * end point for embedding things in non-pulse pages
 */
\header( 'Access-Control-Allow-Origin: *' );
?><!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		
		<title>Pulse CMS</title>
	</head>
	<body>
		<?php echo \pulsecore\page\end_point\process( $_GET, $_POST, $_COOKIE ); ?>
		
		<script type="text/javascript">
			document.addEventListener(
				'readystatechange',
				function() {
					
					// receiver
					function receiver_handler(evnt) {
						
						var message = evnt.data; 
						var source  = evnt.source;
						
						if (message.msg && (message.msg == 'poll')) {
							
							//var content_height = document.body.scrollHeight;
							
							var content_height = Math.max(
								document.body.scrollHeight, document.documentElement.scrollHeight,
								document.body.offsetHeight, document.documentElement.offsetHeight,
								document.body.clientHeight, document.documentElement.clientHeight
							);
							
							source.postMessage( {msg: 'content height', height: content_height}, '*' );
						}
					};
					
					window.addEventListener( 'message', receiver_handler, false );
				},
				false
			);
		</script>
	</body>
</html>
 