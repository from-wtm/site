<?php

// **Pulse CMS Version Number**
$pulse_version   ='5.3.7' ;

//**IMPORTANT**
//You don't need to edit this file anymore. This is used just for the initial load. Just upload Pulse to your server, go to /admin and log in with the password "demo", navigate to settings and change all things from there, including the password. If you want to change in the future from outside of the Pulse admin, go to pulsecore > storage > config.json and edit the information there. Otherwise, use the Pulse Admin UI!


// GENERAL

// Tip: Copy only the contents of the "pulse" folder into the site root, not the folder itself.
// If you want to install in a subfolder, you can, but it must be reflected in the path setting.
	
$path             = ''; // If installed in root, leave blank. If in "subfolder", use "/subfolder"
$admin            = 'admin'; // Admin folder name
$password         = '$2y$10$y1OxlJMDaxuPQGM.0fZy6.Sc2q19VR5i3CxJGz9d7ncUl9bqqtDdi'; // Admin login - "demo"
$autobackup       = true; // Turn on/off auto-backup feature
date_default_timezone_set('Asia/Tokyo'); // More: https://php.net/manual/en/timezones.php
$language         = 'english';
$anonymize_ip     = false;


// EDITOR

$wysiwyg          = true; // Toggle on/off WYSIWYG editor in blocks and blog
$allow            = array('txt','jpeg','gif','jpg','svg','png','pdf','zip','csv','xls','xlsx'); // File types allowed to be uploaded


// MEDIA

$jpeg_resampling_off = false; // Toggle on/off jpeg resampling
$jpeg_quality     = '85'; // Use 100 for full jpeg quality (larger files)
$jpeg_size        = '1200'; // Scale jpegs to a max pixel size (height)
$thumbnail_height     = '120';


// FORM

$mail_inputs      = (object)array('Name'=>'text','Email'=>'email','Phone'=>'text'); // Input fields
$lang_form_name   = 'Name'; // Must match "Name" input above
$lang_form_email  = 'Email'; // Must match "Email" input above
$mail_textarea    = (object)array('Comment'=>'7'); // 7 = Number of rows in comment textarea
$email_contact    = array('you@mail.com'); // Example: 'one@mail.com','two@mail.com'
$config_contact_form_auto_thank = true;

// Tip: To add more form fields, add to the $mail_inputs array
// Tip 2: For more complex forms, use the {{justforms:formid:height}} tag available to all Pulse Cloud Club users:  https://upgrade.pulsecms.com/business.html

// BLOG

$result_per_page  = 5; // Blog posts per page
$blog_url         = "http://example.com/blog";
$disqus_comments  = false; // Turn on/off blog comments (Disqus)
$disqus_shortname = "sample-name"; // Your disqus account name
$date_format      = "M j, Y"; // More: https://php.net/manual/en/function.date.php

// RSS

$blog_title       = 'My Blog';
$blog_description = 'This is my blog.';
$rss_lang         = 'en-us';
$url_prefix   	  = 'blog'; // blog-1-post-title, if changed also edit htaccess

# ===========================================================================>
if (!\defined('NO_JSON_CONFIG_LOAD')) {
	/**
	 * wedge in the updated configs from pulsecore
	 */
	require_once (PULSE_BASE_DIR . '/pulsecore/wedge/config.php');
	
	\pulsecore\wedge\config\wedge_config();
	
	# bootstrap i18n
	\pulsecore\set_i18n(
		\pulsecore\wedge\config\get_json_configs()->json->date_default_timezone_set,
		\pulsecore\wedge\config\get_json_configs()->json->language
	);
}
# ===========================================================================>
