<?php

require_once (__DIR__ . '/symlink_safe.php');

require_once (PULSE_BASE_DIR . '/config.php');

require_once (PULSE_BASE_DIR . '/pulsecore/page/rss.php');

#process the page
\pulsecore\page\rss\process_page(
	$_GET,
	$_POST,
	$_COOKIE
);
