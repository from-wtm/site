"use strict";

/**
 * auto populate the blog title slug from the blog title
 */
function Pulsecore_Widget_BlogTitleSlug( dom_node, target_node ) {
	
	var self = this;
	
	this.dom  = {};
	this.dom.node   = dom_node;
	this.dom.target = target_node;
	
	this.state = {};
}

/**
 * initialise
 * attach the event handlers
 */
Pulsecore_Widget_BlogTitleSlug.prototype.initialise = function() {
	
	var self = this;
	
	// wire up the events we will need
	self.dom.node.addEventListener( 'blur', function(evnt){ self.on_blur(evnt); } );
};

/**
 * click handler - blur
 */
Pulsecore_Widget_BlogTitleSlug.prototype.on_blur = function(evnt) {
	
	var self = this;
	
	var value = this.dom.node.value;
	
	if (value.length > 0) {
		
		var re = new RegExp( '[^a-zA-Z0-9\-]', 'g' );
		
		var last = false;
		
		console.log( last != value );
		
		while (last != value) {
			last  = value;
			value = value.replace( re, '-');
			console.log( value );
		}
		
		self.dom.target.value = value;
	}
};
