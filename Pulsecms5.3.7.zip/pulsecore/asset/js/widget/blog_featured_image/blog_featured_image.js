"use strict";

/**
 * inline edit widget
 */
(function() {
	
	/**
	 * imports
	 */
	//none
	
	/**
	 * state management
	 */
	const state = {
		
		image_list: [],
		
		modal_open: false,
		
		picked: '',
		
		selected_folder: '/'
	};
	
	// start up
	const app = new Vue(
		{
			/**
			 * created callback
			 */
			created: function () {
				
				this.load_image_list();
			},
			
			/**
			 * app mounted callback
			 */
			mounted: function () {
				
				// console.log( 'mounted', this.$el );
				
				this.picked = this.$el.attributes.meta_featured_image.value;
			},
			
			/**
			 * element instance is attached to
			 */
			el:   '#blog-featured-image',
			
			/**
			 * state
			 */
			data: state,
			
			/**
			 * methods
			 */
			methods: {
				
				/*
				 * images to select
				 */
				load_image_list: function () {
					
					const self = this;
					
					window.fetch(
						window.pulsecore.admin_url + '/inc/data_json.php?filter=' + window.encodeURI(self.selected_folder),
					).then(
						function (response) {
							
							response.json().then(
								function (data) {
									
									self.image_list = data;
								}
							);
						}
					);
				},
				
				/**
				 * open the dialog
				 */
				onclick_open: function () {
					
					const self = this;
					
					self.modal_open = false;
					
					Vue.nextTick(
						function () {
							self.modal_open = true;
						}
					);
				},
				
				/*
				 * save data for an item
				 */
				onclick_select: function (item) {
					
					const self = this;
					
					self.picked = item.url;
					
					if (item.pulse_type != 'folder') {
						// images
						self.$refs.meta_featured_image.value = self.picked;
						
						self.modal_open = false;
						
					} else {
						// folders
						self.selected_folder = self.picked.replace('/content/media', '');
						
						self.load_image_list();
					}
				}
			},
			
			/**
			 * watched
			 */
			watch: {
			}
		}
	);
	
	/**
	 * exports
	 */
	window.pulsecore.blog_featured_image = {app: app};
	
})();
