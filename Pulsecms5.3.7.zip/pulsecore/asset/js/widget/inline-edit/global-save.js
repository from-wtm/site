"use strict";

/**
 * global save button for inline edit
 */
(function() {
		
		/**
		 * imports
		 */
		const message_bus = window.pulsecore.inline_edit.component.message_bus;
		
		/**
		 * the Vue component
		 */
		const toolbar = Vue.component(
			'pulsecore-inline-edit-global-save',
			{
				
				/**
				 * lifecyle - created
				 * created
				 */
			created: function () {
				
					const self = this;
					
					/*
					 * custom event - from child component
					 */
					message_bus.$on(
						'modal_open',
						function(flag, packed) {
							
							if ((packed.id == self.id) && (packed.type == self.type)) {
								
								self.item = packed.item;
							}
						}
					);
				},
				
				/**
				 * component state
				 */
				data: function() {
					return {
						
						item: {}
					};
				},
				methods: {
					/*
					 * event handler - click on save
					 */
					onclick_save: function(evnt) {
						
						const self = this;
						
						message_bus.$emit('global_save', true, {id: self.id, type: self.type, item: self.item} );
					}
				},
				props: [
					'header',
					'id',
					'type',
					
					'widget_id'
				],
				template: '<div class="pulsecore-inline-edit-global-save"><span v-on:click.stop.prevent="onclick_save"><i class="fa fa-save" aria-hidden="true"></i></span> </div>'
			}
		);
		
		/**
		 * exports
		 */
		window.pulsecore.inline_edit.component.toolbar = toolbar;
		
})();
