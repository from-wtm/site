"use strict";

/**
 * toolbar component
 */
(function() {
		
		/**
		 * imports
		 */
		const message_bus = window.pulsecore.inline_edit.component.message_bus;
		
		/**
		 * the Vue component
		 */
		const thingy = Vue.component(
			'pulsecore-inline-edit-content',
			{
				// lifecyle - created
				// created
			created: function () {
				
					const self = this;
					
					/**
					 * custom event - from child component
					 */
					message_bus.$on(
						'global_save',
						function(flag, packed) {
							
							self.custom_on_global_save( flag, packed );
						}
					);
					
					/**
					 * custom event - from child component
					 */
					message_bus.$on(
						'modal_open',
						function(flag, packed) {
							
							if ((packed.id == self.id) && (packed.type == self.type)) {
								
								self.item = packed.item;
								
								self.redactor_instantiate();
								
								$R('#' + self.element_id + ' div.edit_box', 'source.setCode', self.item.html );
							}
						}
					);
				},
				
				// lifecyle - mounted - template plugged in
				mounted: function () {
					const self = this;
					
					self.$nextTick(
						function () {
							//component.redactor_instantiate();
						}
					);
				},
				
				// computed data
				computed: {
					/*
					 * DOM node ID
					 */
					element_id: function () {
						let result = 'pulsecore-inline-edit-content_' + this.widget_id;
						return result;
					}
				},
				
				// state
				data: function() {
					return {
						
						item: {},
						
						redactor_on: false
					};
				},
				
				// behaviour
				methods: {
					
								/**
								 * custom event handler - global save
								 */
								custom_on_global_save: function(flag, packed) {
									
									const self = this;
									
									if ((packed.id == self.id) && (packed.type == self.type)) {
										
										if (self.redactor_on) {
											
											self.onclick_save();
										}
									}
								},
								
								/*
								 * event handler - content area click
								 */
								onclick_content_area: function () {
									
									const self = this;
									
									// load data to start redactor
									if (!self.redactor_on) {
										message_bus.$emit('load_item', self.id, self.type );
									}
								},
								
								
								/*
								 * event handler - save
								 */
								onclick_save: function() {
									
									const self = this;
									
									const html = $R('#' + self.element_id + ' div.edit_box', 'source.getCode');
									
									self.item.html = html;
									
									message_bus.$emit('save_item', self.id, self.type, self.item, self.widget_id );
									
									self.redactor_tear_down();
								},
								
								/*
								 * event handler - update state
								 */
								onclick_cancel: function() {
									
									const self = this;
									
									this.redactor_tear_down();
								},
								
								/*
								 * create the redactor instance
								 */
								redactor_instantiate: function () {
									
									const self = this;
									
									window.setTimeout(
										function () {
											$R(
												('#' + self.element_id + ' div.edit_box'),
												{
													lang: (pulsecore.lang_short || "en"),
													pastePlainText: true,
													paragraphize: true,
													replaceDivs: false,
													autoresize: true,
													minHeight: 300,
													buttonSource: true,
													imageUpload:      window.pulsecore.admin_url + '/inc/editor_images.php',
													imageManagerJson: window.pulsecore.admin_url + '/inc/data_json.php',
													fileUpload:       window.pulsecore.admin_url + '/inc/editor_files.php',
													imageResizable: true,
													imagePosition: true,
													plugins: [
															'alignment',
															//'clips',
															'filemanager',
															'fontcolor',
															//'fontsize',
															//'fontfamily',
															//'fullscreen',
															'imagemanager',
															'inlinestyle',
															//'properties',
															//'table',
															//'textdirection',
															'video' 
															//'widget',
															//'mail'
															
															//'codemirror'
													],
													/*
													codemirror: {
															lineNumbers: true,
															mode: 'xml',
															indentUnit: 4
													},
													*/
													
													clips: [
														['More', '##more##']
													],
													air: true,
													styles: true,
													/*
													toolbarFixed: true,
													toolbarFixedTarget: '#textfile',
													toolbarOverflow: true,
													*/
													
													clickToEdit:   true,
													clickToSave:   {title: pulsecore.translations.lang_save_button },
													clickToCancel: {title: pulsecore.translations.lang_cancel_button },
													callbacks: {
														clickStart: function (html) {
															console.log( 'redactor click to edit - start' );
														},
														clickSave: function (html) {
															self.onclick_save();
														},
														clickCancel: function (html) {
															self.onclick_cancel();
														}
													}
													
												}
											);
										}, 100);
									
									self.redactor_on = true;
								},
								
								/**
								 * tear down redactor
								 */
								redactor_tear_down: function () {
									
									const self = this;
									
									$R(
										('#' + self.element_id + ' div.edit_box'),
										'destroy'
									);
									self.redactor_on = false;
								}
				},
				
				// data from parent
				props: {
					item: Object,
					
					header: String,
					id:     String,
					type:   String,
					
					widget_id: String
				},
				
				// template
				template: [
					'<div v-bind:id="element_id" class="pulsecore-inline-edit-content" v-on:click.prevent.stop="onclick_content_area">',
						'<div class="edit_box">',
							'<slot></slot>',
						'</div>',
					'</div>'
				].join('')
				
				/*
				'<div v-if="redactor_on">',
							'<div class="btn btn-secondary" v-on:click.prevent.stop="onclick_save">Save</div>',
							'<div class="btn btn-secondary" v-on:click.prevent.stop="onclick_cancel">Cancel</div>',
						'</div>',
				*/
			}
		);
		
		/**
		 * exports
		 */
		window.pulsecore.inline_edit.component.content = thingy;
		
})();
