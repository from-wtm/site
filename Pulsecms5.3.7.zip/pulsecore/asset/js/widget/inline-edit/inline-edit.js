"use strict";

/**
 * inline edit widget
 */
(function() {
		
		/**
		 * imports
		 */
		//none
		
		/**
		 * state management
		 */
		const state = {
		};
		
		// start up
		const app = new Vue(
			{
				el:   '.inner.group',
				data: state,
				methods: {
					
					/*
					 * load data for an item
					 */
					load_item: function(id, type, widget_id) {
						
						this.$http.get(
							window.pulsecore.admin_url + '/index.php?p=rest',
							{
								params: {
									id:   id,
									type: type,

									widget_id: widget_id
								}
							}

						).then(
							function(item) {

								let packed = {
									item: item.body,
									id:   id,
									type: type,

									widget_id: widget_id
								};
								
								window.pulsecore.inline_edit.component.message_bus.$emit( 'modal_open', true, packed );
							}
						);
					},
					
					/*
					 * save data for an item
					 */
					save_item: function(id, type, item) {
						
						// NB
						item.id = id;
						
						this.$http.post(
							window.pulsecore.admin_url + '/index.php?p=rest&id=' + id + '&type=' + type,
								item
								,{emulateJSON: true}

						).then(
							function(data) {
								window.location.reload();
							}
						);
					}
				}
			}
		);
		
		/*
		 * custom event - from child component
		 */
		window.pulsecore.inline_edit.component.message_bus.$on(
			'load_item',
			function(id, type) {
				window.pulsecore.inline_edit.app.load_item(id, type);
			}
		);
		
		/*
		 * custom event - from child component
		 */
		window.pulsecore.inline_edit.component.message_bus.$on(
			'save_item',
			function(id, type, item) {
				window.pulsecore.inline_edit.app.save_item(id, type, item);
			}
		);
		
		/**
		 * exports
		 */
		window.pulsecore.inline_edit.app = app;
		
})();
