"use strict";

/**
 * toolbar component
 */
(function() {
		
		/**
		 * imports
		 */
		const message_bus = window.pulsecore.inline_edit.component.message_bus;
		
		/**
		 * the Vue component
		 */
		const toolbar = Vue.component(
			'pulsecore-inline-edit-toolbar',
			{
				data: function() {
					return {
					};
				},
				methods: {
					/*
					 * event handler - click on edit in toolbar
					 */
					onclick_edit: function(evnt) {
						
						message_bus.$emit('load_item', this.id, this.type )
					}
				},
				props: [
					'header',
					'id',
					'type',
					
					'widget_id'
				],
				template: '<div class="pulsecore-inline-edit-toolbar">{{ header }}: {{ id }} <span class="edit" v-on:click.stop.prevent="onclick_edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span></div>'
			}
		);
		
		/**
		 * exports
		 */
		window.pulsecore.inline_edit.component.toolbar = toolbar;
		
})();
