"use strict";

/**
 * modal component
 */
(function() {
		
		let redactor_loaded = 0;
		
		/**
		 * imports
		 */
		const message_bus = window.pulsecore.inline_edit.component.message_bus;
		
		/**
		 * modal
		 */
		const Modal = Vue.component(
			'pulsecore-inline-edit-modal',
			{
				created: function() {
					let self = this;
					
					/*
					 * custom event - from child component
					 */
					message_bus.$on(
						'modal_open',
						function(flag, packed) {
							
							self.render(flag, packed);
						}
					);
					
				},
				data: function() {
					return {
						item: {},
						flag: false,
						id:   '',
						type: '',
						
						widget_id: ''
					};
				},
				methods: {
					/*
					 * event handler - close modal
					 */
					onclick_close: function(evnt) {
						
						this.render(false);
					},
					
					
					/*
					 * event handler - update state
					 */
					onclick_update: function(id,type,item, widget_id) {
						
						this.render(false);
						
						item.html = document.getElementById('modal-content-html').val();
						
						message_bus.$emit('save_item', id, type, item, widget_id )
					},
					
					/*
					 * show the modal
					 */
					render: function(flag, packed) {
						
						let self = this;
						
						// open
						if (flag === true) {
							this.item = packed.item;
							this.flag = true;
							this.id   = packed.id;
							this.type = packed.type;
							
							this.widget_id = packed.widget_id;
							
							if (redactor_loaded == 0) {
								// start redactor - NB delay
								window.setTimeout(
									function() {
										
										if (redactor_loaded > 0) {
											return;
										}
										
										redactor_loaded++;
										
										$R('#modal-content-html', 
											{
													pastePlainText: true,
													paragraphize: true,
													replaceDivs: false,
													autoresize: true,
													minHeight: 300,
													buttonSource: true,
													imageUpload:      window.pulsecore.admin_url + '/inc/editor_images.php',
													imageManagerJson: window.pulsecore.admin_url + '/inc/data_json.php',
													fileUpload:       window.pulsecore.admin_url + '/inc/editor_files.php',
													imageResizable: true,
													imagePosition: true,
													plugins: [
															'alignment',
															'fontsize',
															'fontcolor',
															'fontfamily',
															'inlinestyle',
															'properties',
															'table',
															'imagemanager',
															'video', 
															'filemanager',
															'codemirror',
															'snippets',
															'textdirection',
															// 'fullscreen',
															],
													codemirror: {
															lineNumbers: true,
															mode: 'xml',
															indentUnit: 4
													},
													toolbarFixed: true,
													toolbarFixedTarget: '#textfile',
													toolbarOverflow: true
											}
										);
									},
									1000
								);
							}
							
						} else if (flag == false) {
							// close
							this.item = {};
							this.flag = false;
							this.id   = '';
							this.type = '';
							
							this.widget_id = '';
						}
					}
					
				},
				template: [
					'<div class="pulsecore-inline-edit-modal" v-show="flag">',
						'<div class="pulsecore-inline-edit-modal-container">',
							'<header class="modal"><span class="close" v-on:click.stop.prevent="onclick_close"><i class="fa fa-times" aria-hidden="true"></i></span></header>',
							'<form class="modal-content">',
								
								//author
								'<div class="row author" v-show="(type == \'blog\')">',
									'<label for="modal-content-author">Author:</label>',
									'<input type="text" id="modal-content-author" v-model="item.author" />',
								'</div>',
								
								//title
								'<div class="row title" v-show="(type == \'block\') || (type==\'page\')">',
									'<label for="modal-content-title">Title:</label>',
									'<input type="text" id="modal-content-title" v-model="item.title" />',
								'</div>',
								
								//date
								'<div class="row date" v-show="(type == \'blog\')">',
									'<label for="modal-content-date">Date:</label>',
									'<input type="text" id="modal-content-date" v-model="item.date" />',
								'</div>',
								
								//description
								'<div class="row description" v-show="(type == \'block\') || (type==\'page\')">',
									'<label for="modal-content-description">Description:</label>',
									'<textarea id="modal-content-description" v-model="item.description"></textarea>',
								'</div>',
								
								//html
								'<div class="row html">',
									'<label for="modal-content-html">Content:</label>',
									'<textarea id="modal-content-html">{{item.html}}</textarea>',
								'</div>',
								
								//tags
								'<div class="row tags" v-show="(type == \'blog\')">',
									'<label for="modal-content-tags">Tags:</label>',
									'<input type="text" id="modal-content-tags" v-model="item.tags" />',
								'</div>',
								
								'<button v-on:click.stop.prevent="onclick_update(id,type,item)">Update</button>',
							
							'</form>',
							'<footer class="modal"></footer>',
						'</div>',
					'</div>'
				].join("\n")
			}
		);
		
		/**
		 * exports
		 */
		window.pulsecore.inline_edit.component.modal = new Modal();
		
})();
