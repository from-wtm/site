"use strict";

/**
 * message bus component
 */
(function() {
		
		/**
		 * imports
		 */
		//none
		
		/**
		 * message bus
		 */
		const message_bus = new Vue();
		
		/**
		 * exports
		 */
		window.pulsecore.inline_edit.component.message_bus = message_bus;
		
})();
