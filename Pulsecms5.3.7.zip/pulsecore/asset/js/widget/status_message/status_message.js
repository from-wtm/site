"use strict";

(function() {
	
	/**
	 * display a status message as needed
	 */
	function Controller() {
		
		this.dom = {};
	};
	
	/*
	 * initialisation
	 */
	Controller.prototype.init = function() {
		
		var self = this;
		
		this.render();
	};
	
	/*
	 * render the message data
	 */
	Controller.prototype.render = function() {
		
		var self = this;
		
		if ((typeof pulsecore != 'undefined') && (typeof pulsecore.status_messages == 'string') && (pulsecore.alert.active == 1)) {
			
			var decoded = jQuery.parseJSON( pulsecore.status_messages );
			
			var level = 'info';
			
			if (decoded.length > 0) {
				
				var collected_text = [];
				
				for (var k = 0; k < decoded.length; k++) {
					collected_text[k] = (decoded[k].message + "\n");
					
					if (decoded[k].level != 'info') {
						level = decoded[k].level;
					}
				}
				
				collected_text = collected_text.join( '' );
				
				// adjust icon according to level
				var icon = (pulsecore.base_url + "/pulsecore/asset/img/tick_green.jpg");
				
				if (level != 'info') {
					icon = (pulsecore.base_url + "/pulsecore/asset/img/cross_red.jpg");
				}
				
				swal(
					{
						button: pulsecore._('lang_sweetalert_ok'), //the old confirmButtonText
						icon: icon,
						title: pulsecore._('lang_sweetalert_saved'),
						text: collected_text,
						//type: "info",
						closeOnEsc: true,
						closeOnClickOutside: true,
						timer: pulsecore.alert.timeout
					}
				);
			}
		}
	};
	
	/**
	 * startup
	 */
	jQuery(document).ready(
		function() {
			var c = new Controller();
			c.init();
		}
	);
		
})();
