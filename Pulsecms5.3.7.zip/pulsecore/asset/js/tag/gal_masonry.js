
document.addEventListener(
	'DOMContentLoaded',
	function(evnt) {
		baguetteBox.run( ".gallery_masonry", {captions: true} );
	}
);
