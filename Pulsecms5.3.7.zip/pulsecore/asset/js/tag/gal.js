
document.addEventListener(
	'DOMContentLoaded',
	function (evnt) {
		baguetteBox.run( ".gallery", {captions: true} );
	}
);
