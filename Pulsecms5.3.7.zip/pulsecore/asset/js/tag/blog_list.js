"use strict";

(function(){

	/**
	 * the list of tags widget
	 */
	function Pulsecore_Tag_BlogList() {
		
		var self = this;
	}
	
	/*
	 * initialise
	 */
	Pulsecore_Tag_BlogList.prototype.initialise = function() {
		
		var self = this;
	};
	
	/**
	 * start up
	 */
	document.addEventListener(
		'DOMContentLoaded',
		function(evnt) {
			
			var tag = new Pulsecore_Tag_BlogList();
			tag.initialise();
		}
	);

})();
