/*
jQuery(document).ready(
	function() {
		jQuery('.grid').masonry(
			{
				// options
				itemSelector: '.grid-item',
				columnWidth: 100,
				gutter: 1
			}
		);
	}
);
*/
