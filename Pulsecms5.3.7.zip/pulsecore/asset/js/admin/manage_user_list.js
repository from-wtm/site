"use strict";

/**
 * manage usr list
 */
(function() {
		
		/**
		 * constructor
		 */
		function Page() {
			
			this.dom = {};
		}
		
		// wire up
		document.addEventListener(
			'DOMContentLoaded',
			function(evnt) {
				const module = new Page();
			}
		);
		
})();
