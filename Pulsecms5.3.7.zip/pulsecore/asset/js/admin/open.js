"use strict";

/**
 * wire up date picker/etc on the open page
 */
(function() {
		
		/*
		 * constructor
		 */
		function Page() {
			
			this.widget = {};
		}
		
		/*
		 * blog
		 */
		Page.prototype.blog = function() {
			
			var fmt = jQuery( 'form input.blog-date-input' ).data('format');
			
			// console.log( fmt );
			
			jQuery( 'form input.blog-date-input' ).pikaday(
				{
					format:  fmt//,
					//defaultDate: moment().toDate(),
					//setDefaultDate: true
				}
			);
			
			// tags
			this.widget.tag = new Pulsecore_Widget_ListTag( jQuery('input[name="blog_tags"]') );
			this.widget.tag.initialise();
			
			// blog title slug
			this.widget.blog_title_slug = new Pulsecore_Widget_BlogTitleSlug(
				document.getElementsByName('head1'   ).item(0),
				document.getElementsByName('blog_url').item(0)
			);
			this.widget.blog_title_slug.initialise();
		};
		
		// wire up
		jQuery(document).ready(
			function() {
				var module = new Page();
				
				module.blog();
			}
		);
		
})();