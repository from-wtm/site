/**
 * manage the navigation list bits
 */
(function () {
	
	/**
	 * reference to this in the vue instance
	 */
	let vi = false;
	
	/**
	 * methods
	 */
	const _methods = {
		
		/**
		 * factory for menu items
		 */
		factory_menu_item: function (name, url, active, nuke, is_submenu) {
			const result = {name: name, url: url, active: active, nuke: nuke, is_submenu: is_submenu, sub_menu: []};
			return result;
		},
		
		/**
		 * add a new menu item
		 */
		onclick_menu_item_add: function () {
			const item = vi.factory_menu_item( vi.menu_item_new, vi.menu_item_new, true, false, false);
			vi.state.push( item );
			vi.menu_item_new = '';
		},
		
		/**
		 * delete a new menu item
		 */
		onclick_menu_item_delete: function (index) {
			
			const item = vi.state[index];
			
			// dont allow for deleting "all" mandatory category
			if (item.url == 'all') {
				return;
			}
			
			// find all
			const all_index = vi.state.findIndex(
				function (arg) {
					return (arg.url == 'all');
				}
			);
			
			// move entry into all
			vi.state[all_index].sub_menu.push( vi.factory_menu_item(item.name, item.url, item.active, item.nuke, false) );
			
			//move entries into all - normal menu item
			for (let k = 0; k < item.sub_menu.length; k++) {
				vi.state[all_index].sub_menu.push( item.sub_menu[k] );
			}
			
			// remove from list
			vi.state = [].concat(
				vi.state.slice( 0, index),
				vi.state.slice( (index + 1), vi.state.length )
			);
			vi.menu_item_new = '';
			
			// re-render
			const tmp = vi.state;
			vi.state = [];
			Vue.nextTick(
				function() {
					vi.state = tmp;
				}
			);
			
		},
		
		/**
		 * add a new sub menu for this menu item
		 */
		onclick_add_sub_menu: function (menu_item) {
			
			const self = this;
			
			const deferred = swal(
				{
					title: "Sub-menu",
					text: "Enter the submenu name",
					content: {
						element: "input",
						attributes: {
							placeholder: "sub-menu"
						}
					},
					buttons: {
						cancel: {
							closeModal: true
						},
						confirm: {
							closeModal: true
						}
					}
				}
			);
			
			deferred.then(
				function (inputValue) {
					
					// close
					if (inputValue === false) {
						return false;
					}
					
					// no data
					if (inputValue === "") {
						swal.showInputError("You need to write something!");
						return false
					}
					
					// update state
					if (inputValue.length > 0) {
						const item = vi.factory_menu_item( inputValue, inputValue, true, false, true);
						//vi.state.push( item );
						menu_item.sub_menu.push( item );
					}
				}
			);
			
		},
		
		/**
		 * add a non pulse page for this menu item
		 */
		onclick_add_non_pulse_page: function (menu_item) {
			
			const self = this;
			
			const form = jQuery('<div></div>').append(
					jQuery('<div><label for="#name">' + pulsecore.translations.lang_settings_navigation_non_pulse_name + '</label> <input id="name" type="text" name="name" value="" placeholder="' + pulsecore.translations.lang_settings_navigation_non_pulse_name + '" /></div>'),
					jQuery('<div><label for="#url">'  + pulsecore.translations.lang_settings_navigation_non_pulse_url  + '</label> <input id="url"  type="text" name="url"  value="" placeholder="' + pulsecore.translations.lang_settings_navigation_non_pulse_url  + '" /></div>')
			);
			
			const deferred = swal(
				{
					title: pulsecore.translations.lang_settings_navigation_non_pulse_page,
					text:  pulsecore.translations.lang_settings_navigation_non_pulse_page,
					content: form[0],
					buttons: {
						cancel: {
							closeModal: true
						},
						confirm: {
							closeModal: true
						}
					}
				}
			);
			
			deferred.then(
				function (inputValue) {
					
					const name = jQuery( 'input[name="name"]', form).val();
					const url  = jQuery( 'input[name="url"]',  form).val();
					
					// close
					if (inputValue === false) {
						return false;
					}
					
					// find all
					const all_index = vi.state.findIndex(
						function (arg) {
							return (arg.url == 'all');
						}
					);
					
					// update state
					if ((name.length > 0) && (url.length > 0)) {
						const qqq = vi.factory_menu_item( name, url, true, false, false);
						vi.state[all_index].sub_menu.push( qqq );
					}
				}
			);
		},
		
		/**
		 * drag adnd drop done
		 */
		on_dnd_change_menu: function (arg) {
		},
		
		/**
		 * drag adnd drop done
		 */
		on_dnd_change_submenu: function (arg) {
		},
		
		/**
		 * drag adnd drop done
		 */
		on_dnd_change_subsubmenu: function (arg) {
		},
		
		/**
		 * transmit the form
		 */
		onclick_save: function () {
			
			// active
			const build_active_list = function (arg) {
				const result = {};
				
				for (let k = 0; k < arg.length; k++) {
					const ooo = arg[k];
					
					if (ooo.sub_menu.length == 0) {
						// corner case - top level
						result[ooo.name] = (ooo.active ? '1' : '0');
					} else {
						// sub menu
						result[ooo.name] = build_active_list( ooo.sub_menu );
					}
				}
				
				return result;
			};
			
			// nav list
			const build_nav_list = function (arg) {
				const result = {};
				
				for (let k = 0; k < arg.length; k++) {
					const ooo = arg[k];
					
					if (ooo.sub_menu.length == 0) {
						result[ooo.name] = ooo.url;
					} else {
						result[ooo.name] = build_nav_list( ooo.sub_menu );
					}
				}
				
				return result;
			};
			
			// nuke
			const build_nuke_list = function (arg) {
				const result = {};
				
				for (let k = 0; k < arg.length; k++) {
					const ooo = arg[k];
					
					if (ooo.sub_menu.length == 0) {
						// corner case - top level
						result[ooo.name] = (ooo.nuke ? '1' : '0');
					} else {
						// sub menu
						result[ooo.name] = build_nuke_list( ooo.sub_menu );
					}
				}
				
				return result;
			};
			
			// consolidate
			const data = {
				active:   build_active_list(vi.state),
				nav_list: build_nav_list(   vi.state),
				nuke:     build_nuke_list(  vi.state),
				
				csrf_token: vi.csrf_token
			};
			
			// now post
			const deferred = jQuery.post(
				pulsecore.admin_url + '/index.php?p=manage_navigation&method=put',
				data
			);
			
			deferred.done(
				function () {
					window.location.href = (pulsecore.admin_url + '/index.php?p=settings');
				}
			);
		},
		
		/**
		 * sub menu - activate - toggle activation in menu items too
		 */
		onclick_menu_active: function (menu_item) {
			
			for (let k = 0; k < menu_item.sub_menu.length; k++) {
				
				const thing = menu_item.sub_menu[k];
				
				thing.active = !menu_item.active;
			}
		},
		
		/**
		 * sub menu - nuke/delete - toggle activation in menu items too
		 */
		onclick_menu_nuke: function (menu_item) {
			
			for (let k = 0; k < menu_item.sub_menu.length; k++) {
				
				const thing = menu_item.sub_menu[k];
				
				thing.nuke = !menu_item.nuke;
			}
		}
	};
	
	
	/**
	 * vue app
	 */
	const thingy = new Vue(
		{
			el: '.pulsecore.manage_navigation_list',
			
			/**
			 * state
			 */
			data: {
				
				csrf_token: '',
				
				menu_item_new: '',
				
				state: []
			},
			
			/**
			 * callable things
			 */
			methods: _methods,
			
			/**
			 * life cycle - create
			 */
			created: function () {
				vi = this;
				
				// import csrf token
				vi.csrf_token =  pulsecore.manage_navigation.csrf_token;
				
				// import data
				const data = pulsecore.manage_navigation.data;
				
				// convert to list NB impedance mismatch between what is stored in the pulsecore configs (objects nested) and what vue-draggable will expect (arrays)
				for (let k in data) {
					
					const item = data[k];
					
					let zzz = vi.factory_menu_item( k, k, item.active, false, false);
					
					if (item.url) {
						zzz.sub_menu = [];
					} else {
						let tmp = [];
						
						for (let q in item) {
							
							let vvv = vi.factory_menu_item( q, item[q].url, item[q].active, false, false);
							
							// sub-sub menus
							if (!item[q].url) {
								const mmm = item[q];
								
								for (let n in mmm) {
									const sub_menu_item = vi.factory_menu_item( n, mmm[n].url, /*mmm.active*/ true, false, false);
									
									vvv.sub_menu.push( sub_menu_item );
								}
								
								vvv.active     = true;
								vvv.is_submenu = true;
							}
							
							tmp.push( vvv );
						}
						zzz.sub_menu = tmp;
					}
					
					vi.state.push( zzz );
				}
				
				// ensure that top level "all" name is present
				const detected = vi.state.findIndex(
					function (arg) {
						return (arg.url == 'all');
					}
				);
				if (detected == -1) {
					const qqq = vi.factory_menu_item( 'all', 'all', true, false);
					vi.state.push( qqq );
				}
			},
			
			/*
			 * lifecycle - mounted - template loaded
			 */
			mounted: function () {
				
				const self = this;
				/*
				jQuery( ".pulsecore .navigation, .pulsecore .navigation .sub_menu" ).sortable(
					{
						axis: 'y',
						cancel: 'dummy',
						connectWith: '.connected_sortable',
						dropOnEmpty: true,
						items: "li",
						placeholder: "ui-state-highlight",
					}
				).disableSelection();
				
				// warning the order of the event wire ups is important
				jQuery( ".pulsecore .navigation" ).on( 'sortstop', null, null, function(evnt, ui){ return self.on_sortstop(evnt, ui); } );
				*/
			}
		}
	);
	
})();
