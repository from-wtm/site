"use strict";

/**
 * manage navigation
 */
(function() {
		
		/*
		 * constructor
		 */
		function Page() {
			
			this.dom = {};
		}
		
		// wire up
		jQuery(document).ready(
			function() {
				const module = new Page();
				
			}
		);
		
})();
