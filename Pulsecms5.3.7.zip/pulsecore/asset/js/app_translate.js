"use strict";

/**
 * wire up JS inline translations
 */
window.pulsecore._ = function( arg ) {
	
	var result = arg;
	
	if (window.pulsecore.translations[arg]) {
		
		result = window.pulsecore.translations[arg];
	}
	
	return result;
};
