<?php
namespace standalone\sb_login;

# ===========================================================================>
/**
 * basic OTP interface
 * \param $otp_shared_secret string The shared secret
 * \return object
 */
function otp_get( $otp_shared_secret ) {
	
	static $totp = false;
	
	if ($totp === false) {
		#new totp
		$totp = new \OTPHP\TOTP();
		$totp->setLabel( \standalone\sb_login\get_configs()->otp->label    )
			->setDigits(   \standalone\sb_login\get_configs()->otp->digits   )
			->setDigest(   \standalone\sb_login\get_configs()->otp->digest   )
			->setInterval( \standalone\sb_login\get_configs()->otp->interval )
			->setSecret(   $otp_shared_secret );
	}
	
	return $totp;
}

/**
 * verify OTP password
 * \param $otp_password string
 * \param $otp_shared_secret string The shared secret
 * \return bool
 */
function otp_verify_password( $otp_password, $otp_shared_secret ) {
	
	$totp = otp_get( $otp_shared_secret );
	
	$result = $totp->verify( $otp_password );
	
	return $result;
}

# ===========================================================================>
