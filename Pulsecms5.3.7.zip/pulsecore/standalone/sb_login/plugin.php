<?php
namespace standalone\sb_login;

#error reporting
\error_reporting(\E_STRICT|\E_ALL);

/**
 * bootstrap the extra code for pulse cms - autoload vendor library
 */
require_once (__DIR__ . '/vendor/autoload.php');

require_once (__DIR__ . '/config.php');
require_once (__DIR__ . '/otp.php');

#start session if needed
if (\session_status() != \PHP_SESSION_ACTIVE) {
	\session_start();
}

/**
 * standalone password protected page with OTP - inject form
 * \param $password string The password (clear text) to compare against
 * \param $otp_shared_secret string The (optional) OTP shared secret to use for OTP
 * \param $error_message string The message to show if the login fails
 * return boolean True if password accepted, false if not (or no password)
 */
function helper( $password, $otp_shared_secret = '', $error_message = '') {
	
	$state = (object)array(
		'password'          => $password,
		'message'           => $error_message,
		'otp_shared_secret' => $otp_shared_secret
		);
	
	# ensure that the session variable is set
	if (!isset($_SESSION['standalone_sb_login'])) {
		$_SESSION['standalone_sb_login'] = array();
	}
	
	# check to see if this password has already been seen
	$result = (isset($_SESSION['standalone_sb_login']) and \is_array($_SESSION['standalone_sb_login']) and \in_array($password, $_SESSION['standalone_sb_login']));
	
	if ($result === false) {
	
		#render if not logged in`
		if (    isset($_POST['standalone_sb_login_tx'])
				and isset($_POST['standalone_sb_login_password'])
				and isset($_POST['standalone_sb_login_otp']) ) {
			$result = handle_request_post( $_GET, $_POST, $_COOKIE, $state );
			
			# if the login has failed then show the form template again
			if ($result === false) {
				$state->message = (\strlen($error_message) > 0) ? $state->message : $GLOBALS['lang_login_incorrect'];
				render( $state );
			}
			
		} else {
			# show the form template
			render( $state );
		}
	}
	
	return $result;
}

/**
 * standalone password protected page with OTP - process form POST
 * \param $param_get array GET parameters
 * \param $param_post array POST parameters
 * \param $param_cookie array COOKIE variables
 * \param $state stdClass The helper input paramaters
 * \return boolean true if password accepted, false if not
 */
function handle_request_post( array $param_get, array $param_post, array $param_cookie, \stdClass $state ) {
	
	$result = false;
	
	if (    isset($_POST['standalone_sb_login_tx'])
	    and isset($_POST['standalone_sb_login_password'])
	    and isset($_POST['standalone_sb_login_otp']) ) {
	
	# CSRF
		if (!isset($param_post['csrf_token']) or !\pulsecore\session\csrf\verify_expire($param_post['csrf_token']) ) {
			\error_log( 'CSRF token mis-match: ' . $_SERVER['REQUEST_URI'] );
			exit;
		}
	
		$password = $_POST['standalone_sb_login_password'];
		$otp      = $_POST['standalone_sb_login_otp'];
		
		$password = \trim($password);
		$otp      = \trim($otp);
		
		if ($password == $state->password) {
			
			if (\strlen($state->otp_shared_secret) > 0) {
				#otp
				if (otp_verify_password($otp, $state->otp_shared_secret)) {
					$result = true;
					
					$_SESSION['standalone_sb_login'][] = $password;
					\session_write_close();
				}
			} else {
				#no otp
				$result = true;
				
				$_SESSION['standalone_sb_login'][] = $password;
				\session_write_close();
			}
		}
	}
	
	return $result;
}

/**
 * render the template
 * \param $state stdClass The helper input paramaters
 */
function render( \stdClass $state ) {
	
	#autodetect baseurl
	$base_url = $_SERVER['PHP_SELF'];
	$base_url = \dirname( $base_url );
	$base_url = \rtrim( $base_url, '/' );
	$base_url = \rtrim( $base_url, '\\' );
	
	#render
	$view_model = new \stdClass();
	$view_model->base_url = $base_url;
	$view_model->state    = $state;
	
	#jog the OTP state
	$otp = otp_get( $state->otp_shared_secret );
	$view_model->otp_now = $otp->now();
	
	include (__DIR__ . '/template.phtml');
}
 
