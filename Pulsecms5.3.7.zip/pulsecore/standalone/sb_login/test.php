<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
		<?php
			require_once (__DIR__ . '/plugin.php');
			
			if (true === \standalone\sb_login\helper( 'test', '1234567890' )) { ?>
				<p>Logged in!</p>
		<?php } ?>
	</body>
</html>
