<?php
namespace standalone\sb_login;

/**
 * some basic configuration
 */
function get_configs() {
	
	return (object)array(
		
		#otp related settings
		'otp' => (object)array(
			'label'    => 'pulse cms',
			'digits'   => 6,
			'digest'   => 'sha1',
			'interval' => 30
		),
		
		#session related
		'session' => (object)array(
			
			'max_session_time' => 3600, //seconds
			
			#anything login related in the session
			'login' => (object)array(
				
			)
		)
		
	);
}

/**
 * context - or state storage when needed
 * fields correspond to things we need to keep track of
 * \return stdClass
 */
function get_context() {
	
	static $result = false;
	
	if ($result === false) {
		
		$result = new \stdClass();
		
		#high level data storage
		$result->state = new \stdClass();
		
		#theme related - view resources
		$result->theme      = new \stdClass();
		$result->theme->css = new \pulsecore\view\helper\Css();
		$result->theme->js  = new \pulsecore\view\helper\js();
	}
	
	return $result;
}
