<?php
namespace pulsecore\test\page\rss;

/**
 * unit tests for page
 */
class BlogTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\page\rss\Blog();
	}
	
	/**
	 * test
	 * @expectedException LogicException
	 */
	public function test_process_delete() {
		$this->iii->process( array(), array(), array(), 'delete' );
	}
	
	/**
	 * test
	 */
	public function test_process_get() {
		
		\ob_start();
		$this->iii->process( array('d' => 'meep'), array(), array(), 'get' );
		$result = \ob_get_contents();
		\ob_end_clean();
		
		# parse`
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $result );
		
		# valid HTML
		$this->assertTrue( $status );
		
		# ensure header
		$xpath = new \DOMXPath( $doc );
		$query = '//rss/channel';
		$nodes = $xpath->query( $query );
		
		$this->assertTrue( \sizeof($nodes) == 1 );
	}
	
	/**
	 * test
	 * @expectedException LogicException
	 */
	public function test_process_post() {
		$this->iii->process( array(), array(), array(), 'post' );
	}
	
	/**
	 * test
	 * @expectedException LogicException
	 */
	public function test_process_put() {
		$this->iii->process( array(), array(), array(), 'put' );
	}
}
