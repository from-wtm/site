<?php
namespace pulsecore\test\page;

include (PULSE_BASE_DIR . '/pulsecore/page/rss.php');

/**
 * unit tests for page
 */
class RssTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		# $this->iii = new \pulsecore\page\Rss();
	}
	
	/**
	 * test
	 */
	public function test_process_page() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
