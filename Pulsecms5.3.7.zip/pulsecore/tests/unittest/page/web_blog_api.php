<?php
namespace pulsecore\test\page;

/**
 * unit tests for page
 */
class WebBlogApiTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\page\WebBlogApi( true );
	}
	
	/**
	 * test
	 */
	public function test_process_delete () {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_process_get() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_process_post___rpc_delete_post () {
		
		# setup
		$blog_item = new \pulsecore\store\blog\Item();
		$blog_item->save( \pulsecore\get_configs()->dir_content . '/blog/5555.txt');
		
		# setup - get the UUID we need
		$blog_item_uuid_cache = \pulsecore\page\WebBlogApi::blog_item_uuid_cache_rebuild( true );
		
		$post_id = \array_search( "blog/5555", ((array)$blog_item_uuid_cache->items) );
		
		# build the xml rpc post body
		$param_post_body =<<<EOD
<?xml version="1.0"?>
<methodCall>
	<methodName>blogger.deletePost</methodName>
	<params>
		<param>
			<value>abcdef</value>
		</param>
		<param>
			<value>{$post_id}</value>
		</param>
		<param>
			<value>administrator</value>
		</param>
		<param>
			<value>demo</value>
		</param>
		<param>
			<value><boolean>true</boolean></value>
		</param>
	</params>
</methodCall>
EOD;
		
		$packed = 'data://text/plain;base64,' . \base64_encode($param_post_body);
		
		$this->iii = new \pulsecore\page\WebBlogApi( true, $packed );
		
		\ob_start();
		$this->iii->process(
			array(), # get
			array(), # post
			array(), # cookie,
			'post'   # request_method
		);
		$result = \ob_get_contents();
		\ob_end_clean();
		
		# var_dump($result); exit;
		
		$this->assertTrue( is_string($result) );
		$this->assertTrue(    strlen($result) > 0 );
		$this->assertTrue( stripos($result, '<methodResponse>') !== false );
		
		$this->assertTrue( stripos($result, '<fault>') == false );
		
		$this->assertTrue( \file_exists(\pulsecore\get_configs()->dir_content . '/blog/5555.txt') == false );
	}
	
	/**
	 * test
	 */
	public function test_process_post___rpc_edit_post () {
		
		# setup - get the UUID we need
		$blog_item_uuid_cache = \pulsecore\page\WebBlogApi::blog_item_uuid_cache_rebuild( true );
		
		$post_id = \array_search( "blog/6", ((array)$blog_item_uuid_cache->items) );
		
		# build the xml rpc post body
		$param_post_body =<<<EOD
<?xml version="1.0"?>
<methodCall>
	<methodName>metaWeblog.editPost</methodName>
	<params>
		<param>
			<value>{$post_id}</value>
		</param>
		<param>
			<value>administrator</value>
		</param>
		<param>
			<value>demo</value>
		</param>
		<param>
			<value>
				<struct>
					<member>
						<name>description</name>
						<value>in the serengeti</value>
					</member>
					<member>
						<name>title</name>
						<value>hippos and elephants</value>
					</member>
					<member>
						<name>categories</name>
						<value>
							<array>
								<data>
									<value>one</value>
									<value>two</value>
								</data>
							</array>
						</value>
					</member>
				</struct>
			</value>
		</param>
		<param>
			<value><boolean>true</boolean></value>
		</param>
	</params>
</methodCall>
EOD;
		
		$packed = 'data://text/plain;base64,' . \base64_encode($param_post_body);
		
		$this->iii = new \pulsecore\page\WebBlogApi( true, $packed );
		
		\ob_start();
		$this->iii->process(
			array(), # get
			array(), # post
			array(), # cookie,
			'post'   # request_method
		);
		$result = \ob_get_contents();
		\ob_end_clean();
		
		# var_dump($result); exit;
		
		$this->assertTrue( is_string($result) );
		$this->assertTrue(    strlen($result) > 0 );
		$this->assertTrue( stripos($result, '<methodResponse>') !== false );
		
		$this->assertTrue( stripos($result, '<fault>') == false );
	}
	
	/**
	 * test
	 */
	public function test_process_post___rpc_get_categories() {
		
		# setup - get the UUID we need
		$blog_item_uuid_cache = \pulsecore\page\WebBlogApi::blog_item_uuid_cache_rebuild( true );
		
		$blog_id = \array_search( "/blog/", ((array)$blog_item_uuid_cache->blogs) );
		
		# build the xml rpc post body
		$param_post_body =<<<EOD
<?xml version="1.0"?>
<methodCall>
	<methodName>metaWeblog.getCategories</methodName>
	<params>
		<param>
			<value>{$blog_id}</value>
		</param>
		<param>
			<value>administrator</value>
		</param>
		<param>
			<value>demo</value>
		</param>
	</params>
</methodCall>
EOD;
		
		$packed = 'data://text/plain;base64,' . \base64_encode($param_post_body);
		
		$this->iii = new \pulsecore\page\WebBlogApi( true, $packed );
		
		\ob_start();
		$this->iii->process(
			array(), # get
			array(), # post
			array(), # cookie,
			'post'   # request_method
		);
		$result = \ob_get_contents();
		\ob_end_clean();
		
		# var_dump($result);
		
		$this->assertTrue( is_string($result) );
		$this->assertTrue(    strlen($result) > 0 );
		$this->assertTrue( stripos($result, '<methodResponse>') !== false );
		
		$this->assertTrue( stripos($result, '<fault>') == false );
	}
	
	/**
	 * test
	 */
	public function test_process_post___rpc_get_categories__marsedit () {
		
		# setup - get the UUID we need
		$blog_item_uuid_cache = \pulsecore\page\WebBlogApi::blog_item_uuid_cache_rebuild( true );
		
		$blog_id = \array_search( "/blog/", ((array)$blog_item_uuid_cache->blogs) );
		
		# build the xml rpc post body
		$param_post_body =<<<EOD
<?xml version="1.0" encoding="utf-8"?>
<methodCall>
	<methodName>metaWeblog.getCategories</methodName>
	<params>
		<param>
			<value><string>{$blog_id}</string></value>
			</param>
		<param>
			<value><string></string></value>
			</param>
		<param>
			<value><string></string></value>
			</param>
		</params>
	</methodCall>
EOD;
		
		$packed = 'data://text/plain;base64,' . \base64_encode($param_post_body);
		
		$this->iii = new \pulsecore\page\WebBlogApi( true, $packed );
		
		\ob_start();
		$this->iii->process(
			array(), # get
			array(), # post
			array(), # cookie,
			'post'   # request_method
		);
		$result = \ob_get_contents();
		\ob_end_clean();
		
		# var_dump($result);
		
		$this->assertTrue( is_string($result) );
		$this->assertTrue(    strlen($result) > 0 );
		$this->assertTrue( stripos($result, '<methodResponse>') !== false );
		
		$this->assertTrue( stripos($result, '<fault>') == false );
	}
	
	/**
	 * test
	 */
	public function test_process_post___rpc_get_post () {
		
		# setup - get the UUID we need
		$blog_item_uuid_cache = \pulsecore\page\WebBlogApi::blog_item_uuid_cache_rebuild( true );
		
		$post_id = \array_search( "blog/6", ((array)$blog_item_uuid_cache->items) );
		
		# build the xml rpc post body
		$param_post_body =<<<EOD
<?xml version="1.0"?>
<methodCall>
	<methodName>metaWeblog.getPost</methodName>
	<params>
		<param>
			<value>{$post_id}</value>
		</param>
		<param>
			<value>administrator</value>
		</param>
		<param>
			<value>demo</value>
		</param>
	</params>
</methodCall>
EOD;
		
		$packed = 'data://text/plain;base64,' . \base64_encode($param_post_body);
		
		$this->iii = new \pulsecore\page\WebBlogApi( true, $packed );
		
		\ob_start();
		$this->iii->process(
			array(), # get
			array(), # post
			array(), # cookie,
			'post'   # request_method
		);
		$result = \ob_get_contents();
		\ob_end_clean();
		
		# var_dump($result);
		
		$this->assertTrue( is_string($result) );
		$this->assertTrue(    strlen($result) > 0 );
		$this->assertTrue( stripos($result, '<methodResponse>') !== false );
		
		$this->assertTrue( stripos($result, '<fault>') == false );
	}
	
	/**
	 * test
	 */
	public function test_process_post___rpc_get_recent_posts () {
		
		# setup - get the UUID we need
		$blog_item_uuid_cache = \pulsecore\page\WebBlogApi::blog_item_uuid_cache_rebuild( true );
		
		$blog_id = \array_search( "/blog/", ((array)$blog_item_uuid_cache->blogs) );
		
		# build the xml rpc post body
		$param_post_body =<<<EOD
<?xml version="1.0"?>
<methodCall>
	<methodName>metaWeblog.getRecentPosts</methodName>
	<params>
		<param>
			<value>{$blog_id}</value>
		</param>
		<param>
			<value>administrator</value>
		</param>
		<param>
			<value>demo</value>
		</param>
		<param>
			<value><int>3</int></value>
		</param>
	</params>
</methodCall>
EOD;
		
		$packed = 'data://text/plain;base64,' . \base64_encode($param_post_body);
		
		$this->iii = new \pulsecore\page\WebBlogApi( true, $packed );
		
		\ob_start();
		$this->iii->process(
			array(), # get
			array(), # post
			array(), # cookie,
			'post'   # request_method
		);
		$result = \ob_get_contents();
		\ob_end_clean();
		
		# var_dump($result);
		
		$this->assertTrue( is_string($result) );
		$this->assertTrue(    strlen($result) > 0 );
		$this->assertTrue( stripos($result, '<methodResponse>') !== false );
		
		$this->assertTrue( stripos($result, '<fault>') == false );
	}
	
	/**
	 * test
	 */
	public function test_process_post___rpc_get_users_blogs () {
		
		# build the xml rpc post body
		$param_post_body =<<<EOD
<?xml version="1.0"?>
<methodCall>
	<methodName>blogger.getUsersBlogs</methodName>
	<params>
		<param>
			<value>abcdef</value>
		</param>
		<param>
			<value>administrator</value>
		</param>
		<param>
			<value>demo</value>
		</param>
	</params>
</methodCall>
EOD;
		
		$packed = 'data://text/plain;base64,' . \base64_encode($param_post_body);
		
		$this->iii = new \pulsecore\page\WebBlogApi( true, $packed );
		
		\ob_start();
		$this->iii->process(
			array(), # get
			array(), # post
			array(), # cookie,
			'post'   # request_method
		);
		$result = \ob_get_contents();
		\ob_end_clean();
		
		# var_dump($result);
		
		$this->assertTrue( is_string($result) );
		$this->assertTrue(    strlen($result) > 0 );
		$this->assertTrue( stripos($result, '<methodResponse>') !== false );
		
		$this->assertTrue( stripos($result, '<fault>') == false );
	}
	
	/**
	 * test
	 */
	public function test_process_post___rpc_new_post () {
		
		# setup - get the UUID we need
		$blog_item_uuid_cache = \pulsecore\page\WebBlogApi::blog_item_uuid_cache_rebuild( true );
		
		$blog_id = \array_search( "/blog/", ((array)$blog_item_uuid_cache->blogs) );
		
		# build the xml rpc post body
		$param_post_body =<<<EOD
<?xml version="1.0"?>
<methodCall>
	<methodName>metaWeblog.newPost</methodName>
	<params>
		<param>
			<value>{$blog_id}</value>
		</param>
		<param>
			<value>administrator</value>
		</param>
		<param>
			<value>demo</value>
		</param>
		<param>
			<value>
				<struct>
					<member>
						<name>description</name>
						<value>in the okavango</value>
					</member>
					<member>
						<name>title</name>
						<value>botswana</value>
					</member>
					<member>
						<name>categories</name>
						<value>
							<array>
								<data>
									<value>alpha</value>
									<value>beta</value>
								</data>
							</array>
						</value>
					</member>
				</struct>
			</value>
		</param>
		<param>
			<value><boolean>true</boolean></value>
		</param>
	</params>
</methodCall>
EOD;
		
		$packed = 'data://text/plain;base64,' . \base64_encode($param_post_body);
		
		$this->iii = new \pulsecore\page\WebBlogApi( true, $packed );
		
		\ob_start();
		$this->iii->process(
			array(), # get
			array(), # post
			array(), # cookie,
			'post'   # request_method
		);
		$result = \ob_get_contents();
		\ob_end_clean();
		
		# var_dump($result);
		
		$this->assertTrue( is_string($result) );
		$this->assertTrue(    strlen($result) > 0 );
		$this->assertTrue( stripos($result, '<methodResponse>') !== false );
		
		$this->assertTrue( stripos($result, '<fault>') == false );
	}
	
	/**
	 * test
	 */
	public function test_process_post___rpc_new_media_object () {
		
		$image_payload = \file_get_contents(\pulsecore\test\TEST_DIR . '/content/media/gallery/avatar.jpg');
		$image_payload = \base64_encode( $image_payload );
		
		# setup - get the UUID we need
		$blog_item_uuid_cache = \pulsecore\page\WebBlogApi::blog_item_uuid_cache_rebuild( true );
		
		$blog_id = \array_search( "/blog/", ((array)$blog_item_uuid_cache->blogs) );
		
		# build the xml rpc post body
		$param_post_body =<<<EOD
<?xml version="1.0"?>
<methodCall>
	<methodName>metaWeblog.newMediaObject</methodName>
	<params>
		<param>
			<value>{$blog_id}</value>
		</param>
		<param>
			<value>administrator</value>
		</param>
		<param>
			<value>demo</value>
		</param>
		<param>
			<value>
				<struct>
					<member>
						<name>name</name>
						<value>media_test.jpg</value>
					</member>
					<member>
						<name>type</name>
						<value>jpeg</value>
					</member>
					<member>
						<name>bits</name>
						<value>
							<base64>{$image_payload}</base64>
						</value>
					</member>
				</struct>
			</value>
		</param>
	</params>
</methodCall>
EOD;
		
		$packed = 'data://text/plain;base64,' . \base64_encode($param_post_body);
		
		$this->iii = new \pulsecore\page\WebBlogApi( true, $packed );
		
		\ob_start();
		$this->iii->process(
			array(), # get
			array(), # post
			array(), # cookie,
			'post'   # request_method
		);
		$result = \ob_get_contents();
		\ob_end_clean();
		
		# var_dump($result);
		
		$this->assertTrue( is_string($result) );
		$this->assertTrue(    strlen($result) > 0 );
		$this->assertTrue( stripos($result, '<methodResponse>') !== false );
		
		$this->assertTrue( stripos($result, '<fault>') == false );
		
		$this->assertTrue( stripos($result, '<name>url</name>') !== false );
	}
	
	/**
	 * test
	 */
	public function test_process_put () {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
