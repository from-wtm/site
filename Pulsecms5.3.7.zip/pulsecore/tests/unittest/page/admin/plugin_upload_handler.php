<?php
namespace pulsecore\test\page\admin;

/**
 * unit tests for page
 */
class PluginUploadHandlerTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\page\admin\PluginUploadHandler();
	}
	
	/**
	 * test
	 */
	public function test_process_delete() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_process_get() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_process_post() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_process_put() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
