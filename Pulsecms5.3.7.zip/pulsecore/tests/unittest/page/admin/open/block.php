<?php
namespace pulsecore\test\page\admin\open;

/**
 * unit tests for page
 */
class BlockTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\page\admin\open\Block();
	}
	
	/**
	 * test
	 */
	public function test_handle_delete() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_handle_get() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_handle_post() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_handle_put() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
