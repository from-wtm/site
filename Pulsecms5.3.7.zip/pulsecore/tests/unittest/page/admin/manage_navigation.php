<?php
namespace pulsecore\test\page\admin;

/**
 * unit tests for page
 */
class ManageNavigationTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\page\admin\ManageNavigation();
	}
	
	/**
	 * test
	 * @expectedException LogicException
	 */
	public function test_process_delete() {
		$this->iii->process( array(), array(), array(), 'delete');
	}
	
	/**
	 * test
	 */
	public function test_process_get() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
		
		/*
		\ob_start();
		$this->iii->process( array(), array(), array(), 'get');
		$result = \ob_get_contents();
		\ob_end_clean();
		
		# parse`
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $result );
		
		# valid HTML
		$this->assertTrue( $status );
		
		# ensure header
		$xpath = new \DOMXPath( $doc );
		$query = '//html/body/div/h1';
		$nodes = $xpath->query( $query );
		
		$this->assertTrue( \sizeof($nodes) == 1 );
		*/
	}
	
	/**
	 * test
	 * @expectedException LogicException
	 */
	public function test_process_post() {
		$this->iii->process( array(), array(), array(), 'post');
	}
	
	/**
	 * test
	 */
	public function test_process_put() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
		
		/*
		$json = \file_get_contents( \pulsecore\test\TEST_DIR . '/page/admin/manage_navigation_put.json' );
		$request_params = \json_decode( $json, true );
		
		$this->iii->process( array(), $request_params, array(), 'put');
		*/
	}
}
