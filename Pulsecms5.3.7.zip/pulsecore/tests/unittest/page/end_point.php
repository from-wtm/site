<?php
namespace pulsecore\test\page;

include (PULSE_BASE_DIR . '/pulsecore/page/end_point.php');

/**
 * unit tests for page
 */
class EndPointTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		# $this->iii = new \pulsecore\page\EndPoint();
	}
	
	/**
	 * test
	 */
	public function test_process() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
