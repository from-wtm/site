<?php
namespace pulsecore\test\logic;

/**
 * unit tests for logic
 */
class UserAgentTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * logic instance
	 */
	protected $logic = false;
	
	/**
	 * setup
	 */
	protected function setUp () {
		
		$this->logic = new \pulsecore\logic\UserAgent();
	}
	
	/**
	 * test - no geoip
	 */
	public function test_process_1 () {
		
		$result = $this->logic->process(
			array(
				'geoip_enable'    => false,
				'header_list'     => array(
					'Accept-Language' => 'en-US',
					'User-Agent'      => 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0'
				),
				'ip'              => '224.244.209.18'
			)
		);
		
		$this->assertTrue( isset($result) );
		$this->assertTrue( isset($result->browser) );
		$this->assertTrue( isset($result->country) );
		$this->assertTrue( isset($result->device) );
		$this->assertTrue( isset($result->language) );
		$this->assertTrue( isset($result->locale) );
		$this->assertTrue( isset($result->system) );
		
		$this->assertEquals( 'en',    $result->language);
		$this->assertEquals( 'en-US', $result->locale);
	}
	
	/**
	 * test - with geoip
	 */
	public function test_process_2 () {
		
		$result = $this->logic->process(
			array(
				'geoip_enable'    => true,
				'header_list'     => array(
					'Accept-Language' => 'en-US',
					'User-Agent'      => 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0'
				),
				'ip'              => '224.244.209.18'
			)
		);
		
		$this->assertTrue( isset($result) );
		$this->assertTrue( isset($result->browser) );
		$this->assertTrue( isset($result->country) );
		$this->assertTrue( isset($result->device) );
		$this->assertTrue( isset($result->language) );
		$this->assertTrue( isset($result->locale) );
		$this->assertTrue( isset($result->system) );
		
		$this->assertEquals( 'United States', $result->country);
		$this->assertEquals( 'en',            $result->language);
		$this->assertEquals( 'en-US',         $result->locale);
	}
	
	/**
	 * test - no language header
	 */
	public function test_process_3 () {
		
		$result = $this->logic->process(
			array(
				'geoip_enable'    => true,
				'header_list'     => array(
					'User-Agent'      => 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0'
				),
				'ip'              => '224.244.209.18'
			)
		);
		
		$this->assertTrue( isset($result) );
		$this->assertTrue( isset($result->browser) );
		$this->assertTrue( isset($result->country) );
		$this->assertTrue( isset($result->device) );
		$this->assertTrue( isset($result->language) );
		$this->assertTrue( isset($result->locale) );
		$this->assertTrue( isset($result->system) );
		
		$this->assertEquals( 'GeoIP disabled (or missing headers)', $result->country);
		$this->assertEquals( '',                                    $result->language);
		$this->assertEquals( '',                                    $result->locale);
	}
	
	/**
	 * test - no user agent header
	 */
	public function test_process_4 () {
		
		$result = $this->logic->process(
			array(
				'geoip_enable'    => true,
				'header_list'     => array(
					'Accept-Language' => 'en-US',
				),
				'ip'              => '224.244.209.18'
			)
		);
		
		$this->assertTrue( isset($result) );
		$this->assertTrue( isset($result->browser) );
		$this->assertTrue( isset($result->country) );
		$this->assertTrue( isset($result->device) );
		$this->assertTrue( isset($result->language) );
		$this->assertTrue( isset($result->locale) );
		$this->assertTrue( isset($result->system) );
		
		$this->assertEquals( 'GeoIP disabled (or missing headers)', $result->country);
		$this->assertEquals( 'en',                                  $result->language);
		$this->assertEquals( 'en-US',                               $result->locale);
	}
}
