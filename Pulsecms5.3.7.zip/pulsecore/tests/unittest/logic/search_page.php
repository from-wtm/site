<?php
namespace pulsecore\test\logic;

/**
 * unit tests for logic
 */
class SearchPageTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * logic instance
	 */
	protected $logic = false;
	
	/**
	 * setup
	 */
	protected function setUp () {
		
		$this->logic = new \pulsecore\logic\SearchPage();
	}
	
	/**
	 * test
	 *
	public function test_build_snippet() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	*/
	
	/**
	 * test
	 *
	public function test_build_title() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	*/
	
	/**
	 * test
	 *
	public function test_build_url() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	*/
	
	/**
	 * test
	 */
	public function test_process() {
		
		$result = $this->logic->process( array('term' => 'recentposts') );
		
		$this->assertTrue( isset($result) );
		$this->assertTrue( sizeof($result->results) > 0);
	}
}
