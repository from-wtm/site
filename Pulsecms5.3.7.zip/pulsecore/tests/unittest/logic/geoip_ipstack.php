<?php
namespace pulsecore\test\logic;

/**
 * unit tests for geoip logic
 */
class GeoIpIpStackTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * logic instance
	 */
	protected $logic = false;
	
	/**
	 * setup
	 */
	protected function setUp () {
		
		$this->logic = new \pulsecore\logic\GeoIpIpStack();
	}
	
	/**
	 * test
	 */
	public function test_process() {
		
		$result = $this->logic->process( array('ip' => '192.30.253.112') ); # github
		
		$this->assertEquals( 'United States', $result->country );
	}
}
