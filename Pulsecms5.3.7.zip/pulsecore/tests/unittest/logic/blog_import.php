<?php
namespace pulsecore\test\logic;

require_once (PULSE_BASE_DIR . '/pulsecore/logic/blog_import.php');

/**
 * unit tests for logic
 */
class BlogImportTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 */
	public function test_import() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_import_from_atom() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_import_from_rss() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_import_from_rss_2_rapidweaver() {
		
		$raw_xml = \file_get_contents( \pulsecore\test\TEST_DIR . '/example/rss/rss_2_rapidweaver.xml' );
		
		$xml = \pulsecore\logic\blog_import\load_xml( $raw_xml );
		
		$status = \pulsecore\logic\blog_import\import_from_rss( $xml, 'http://localhost' );
		
		$this->assertTrue( isset($status) );
	}
	
	/**
	 * test
	 */
	public function test_import_from_rss_wordpress () {
		
		$raw_xml = \file_get_contents( \pulsecore\test\TEST_DIR . '/example/rss/wordpress_feed.xml' );
		
		$xml = \pulsecore\logic\blog_import\load_xml( $raw_xml );
		
		$status = \pulsecore\logic\blog_import\import_from_rss( $xml, 'http://localhost' );
		
		$this->assertTrue( isset($status) );
	}
	
	/**
	 * test
	 */
	public function test_import_page() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_load_file() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_load_xml() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_mangle() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_pull_image() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
