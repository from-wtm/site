<?php
namespace pulsecore\test\logic;

/**
 * unit tests for logic
 */
class FindImageTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * logic instance
	 */
	protected $logic = false;
	
	/**
	 * setup
	 */
	protected function setUp () {
		
		$this->logic = new \pulsecore\logic\FindImage();
	}
	
	/**
	 * test
	 */
	public function test_process() {
		
		$result = $this->logic->process( array('blog_id' => 'blog/1') );
		
		$this->assertTrue( isset($result->filepath) );
		$this->assertTrue( isset($result->url) );
	}
}
