<?php
namespace pulsecore\test\logic;

/**
 * unit tests for logic
 */
class FeaturedImageTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * logic instance
	 */
	protected $logic = false;
	
	/**
	 * setup
	 */
	protected function setUp () {
		
		$this->logic = new \pulsecore\logic\FeaturedImage();
	}
	
	/**
	 * test
	 */
	public function test_process() {
		
		$result = $this->logic->process( array('blog_id' => '1') );
		
		$this->assertTrue( isset($result->filepath) );
		$this->assertTrue( isset($result->url) );
	}
}
