<?php
namespace pulsecore\test;

/**
 * utility for test cases
 */
class TestCase extends \PHPUnit\Framework\TestCase {
	
	/**
	 * fetch html page from url
	 * \param $url string
	 * \param $method string
	 * \param $cookies array
	 * \param $headers array
	 * \param $post_data array
	 */
	public function fetch_url ($url, $method = 'get', array $cookies = array(), array $headers = array(), array $post_data = array() ) {
		
		$curl_handle = \curl_init();
		
		$options = array(
			\CURLOPT_URL            => $url,
			\CURLOPT_USERAGENT      => 'spider',
			
			\CURLOPT_ENCODING       => 'UTF-8',
			\CURLOPT_RETURNTRANSFER => true,
			
			\CURLOPT_TIMEOUT        => 120,
			\CURLOPT_CONNECTTIMEOUT =>  30,
			
			\CURLOPT_MAXREDIRS      =>   5,
			\CURLOPT_FOLLOWLOCATION => true,
			
			\CURLOPT_HEADER => true
		);
		
		# set the HTTP cookies
		if (\sizeof($cookies) > 0) {
			
			$cookie_string = array();
			
			foreach ($cookies as $key => $value) {
				$cookie_string[] = "{$key}={$value}";
			}
			
			$options[\CURLOPT_COOKIE] = \implode( '; ', $cookie_string);
		}
		
		# set the http headers
		if (\sizeof($headers) > 0) {
			$options[\CURLOPT_HTTPHEADER] = $headers;
		}
		
		# set the HTTP request type
		if ($method == 'delete') {
			$options[\CURLOPT_CUSTOMREQUEST] = 'delete';
			
		} else if ($method == 'get') {
			$options[\CURLOPT_HTTPGET] = true;
			
		} else if ($method == 'post') {
			$options[\CURLOPT_POST] = true;
			$options[\CURLOPT_POSTFIELDS] = $post_data;
			
		} else if ($method == 'put') {
			$options[\CURLOPT_PUT] = true;
		}
		
		\curl_setopt_array(
			$curl_handle,
			$options
		);
		
		$response = \curl_exec($curl_handle);
		
		\curl_close($curl_handle);
		
		# parse the response
		$result = (object)array(
			'version'       => '',
			'response_code' => '',
			'headers'       => array(),
			'body'          => ''
		);
		
		$lines = \explode("\n", $response);
		
		$result->version       = \trim( \array_shift($lines) );
		$result->response_code = \explode(' ', $result->version );
		$result->response_code = $result->response_code[1];
		
		while (($lll = \array_shift($lines)) != null) {
			
			$lll = \trim($lll);
			
			if (\strlen($lll) == 0) {
				
				$result->body = \implode("\n", $lines);
				$result->body = \trim( $result->body );
				break;
				
			} else {
				
				$splitted = \explode(':', $lll);
				
				$result->headers[ $splitted[0] ] = $splitted[1];
			}
		}
		
		return $result;
	}
}
