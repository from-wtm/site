<?php
namespace pulsecore\test\common;

/**
 * unit tests for session
 */
class SessionCsrfTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 */
	public function test_create() {
		# short
		$_SESSION = [];
		
		$token = \pulsecore\session\csrf\create( 'short' );
		
		$this->assertTrue( isset($_SESSION[\pulsecore\session\csrf\NAME][$token]) );
		
		# long
		$_SESSION = [];
		
		$token = \pulsecore\session\csrf\create( 'long' );
		
		$this->assertTrue( isset($_SESSION[\pulsecore\session\csrf\NAME][$token]) );
	}
	
	/**
	 * test
	 */
	public function test_expire() {
		
		$_SESSION = [
		\pulsecore\session\csrf\NAME => [
				'aaa' => \time() + \pulsecore\get_configs()->csrf->timeout,
				'bbb' => \time() + \pulsecore\get_configs()->csrf->timeout
			]
		];
		
		\pulsecore\session\csrf\expire('aaa');
		
		$this->assertFalse( isset($_SESSION[\pulsecore\session\csrf\NAME]['aaa']) );
		$this->assertTrue(  isset($_SESSION[\pulsecore\session\csrf\NAME]['bbb']) );
	}
	
	/**
	 * test
	 */
	public function test_gc() {
		
		$_SESSION = [
		\pulsecore\session\csrf\NAME => [
				'aaa' => \time() - \pulsecore\get_configs()->csrf->timeout,
				'bbb' => \time() + \pulsecore\get_configs()->csrf->timeout
			]
		];
		
		\pulsecore\session\csrf\gc();
		
		$this->assertFalse( isset($_SESSION[\pulsecore\session\csrf\NAME]['aaa']) );
		$this->assertTrue(  isset($_SESSION[\pulsecore\session\csrf\NAME]['bbb']) );
	}
	
	/**
	 * test
	 */
	public function test_init() {
		
		$_SESSION = [];
		
		$this->assertFalse( isset($_SESSION[ \pulsecore\session\csrf\NAME ] ) );
		
		\pulsecore\session\csrf\init();
		
		$this->assertTrue( isset($_SESSION[ \pulsecore\session\csrf\NAME ] ) );
	}
	
	/**
	 * test
	 */
	public function test_verify() {
		
		$_SESSION = [
		\pulsecore\session\csrf\NAME => [
				'aaa' => \time() - \pulsecore\get_configs()->csrf->timeout,
				'bbb' => \time() + \pulsecore\get_configs()->csrf->timeout
			]
		];
		
		$status = \pulsecore\session\csrf\verify('aaa');
		
		$this->assertEquals( false, $status );
		
		$this->assertFalse( isset($_SESSION[\pulsecore\session\csrf\NAME]['aaa']) );
		$this->assertTrue(  isset($_SESSION[\pulsecore\session\csrf\NAME]['bbb']) );
		
		$status = \pulsecore\session\csrf\verify('bbb');
		
		$this->assertEquals( true, $status );
		
		$this->assertFalse( isset($_SESSION[\pulsecore\session\csrf\NAME]['aaa']) );
		$this->assertTrue(  isset($_SESSION[\pulsecore\session\csrf\NAME]['bbb']) );
	}
	
	/**
	 * test
	 */
	public function test_verify_expire() {
		
		$_SESSION = [
		\pulsecore\session\csrf\NAME => [
				'aaa' => \time() - \pulsecore\get_configs()->csrf->timeout,
				'bbb' => \time() + \pulsecore\get_configs()->csrf->timeout,
				'ccc' => \time() + \pulsecore\get_configs()->csrf->timeout
			]
		];
		
		$status = \pulsecore\session\csrf\verify_expire('bbb');
		
		$this->assertEquals( true, $status );
		
		$this->assertFalse( isset($_SESSION[\pulsecore\session\csrf\NAME]['aaa']) );
		$this->assertFalse( isset($_SESSION[\pulsecore\session\csrf\NAME]['bbb']) );
		$this->assertTrue(  isset($_SESSION[\pulsecore\session\csrf\NAME]['ccc']) );
	}
}
