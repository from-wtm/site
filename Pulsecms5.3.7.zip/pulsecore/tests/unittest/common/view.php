<?php
namespace pulsecore\test\common;

/**
 * unit tests for view
 */
class ViewTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * view
	 */
	protected $view = false;
	
	/**
	 * view model
	 */
	protected $view_model = false;
	
	/**
	 * set up the view
	 */
	protected function setUp () {
		
		$this->view_model = new \pulsecore\ViewModel();
		
		$this->view_model->header = 'animals';
		
		$this->view_model->data = ['hippo', 'meerkat', 'ratel', 'boomslang'];
		
		$this->view = new \pulsecore\View( \pulsecore\test\TEST_DIR . '/view.phtml');
	}
	
	/**
	 * test
	 */
	public function test_render() {
		
		\ob_start();
		$this->view->render( $this->view_model );
		$result = \ob_get_contents();
		\ob_end_clean();
		
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $result );
		
		# valid HTML
		$this->assertTrue( $status );
		
		# ensure header
		$xpath = new \DOMXPath( $doc );
		$query = '//html/body/h1';
		$nodes = $xpath->query( $query );
		
		$this->assertTrue( \sizeof($nodes) == 1 );
		
		# ensure data
		$xpath = new \DOMXPath( $doc );
		$query = '//html/body/ul/li';
		$nodes = $xpath->query( $query );
		
		$this->assertTrue( \sizeof($nodes) == 4 );
	}
	
	/**
	 * test
	 */
	public function test_render_captured() {
		
		$result = $this->view->render_captured( $this->view_model );
		
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $result );
		
		# valid HTML
		$this->assertTrue( $status );
		
		# ensure header
		$xpath = new \DOMXPath( $doc );
		$query = '//html/body/h1';
		$nodes = $xpath->query( $query );
		
		$this->assertTrue( \sizeof($nodes) == 1 );
		
		# ensure data
		$xpath = new \DOMXPath( $doc );
		$query = '//html/body/ul/li';
		$nodes = $xpath->query( $query );
		
		$this->assertTrue( \sizeof($nodes) == 4 );
		
	}
}
