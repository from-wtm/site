<?php
namespace pulsecore\test\common;

/**
 * unit tests for DBC
 */
class DbcTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 * @expectedException LogicException
	 */
	public function test_invariant() {
		
		\pulsecore\invariant( false );
	}
	
	/**
	 * test
	 * @expectedException LogicException
	 */
	public function test_pre_condition() {
		
		\pulsecore\pre_condition( false );
	}
	
	/**
	 * test
	 * @expectedException LogicException
	 */
	public function test_post_condition() {
		
		\pulsecore\post_condition( false );
	}
}
