<?php
namespace pulsecore\test\common;

/**
 * unit tests for session
 */
class SessionTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 */
	public function test_cleanup() {
		
		$_SESSION = array(
			'foo' => 'bar'
		);
		
		\pulsecore\session\cleanup();
		
		$this->assertTrue( \sizeof($_SESSION) == 0);
		
	}
	
	/**
	 * test
	 */
	public function test_start() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_status_add() {
		
		$_SESSION = [];
		
		\pulsecore\session\status_add( 'test' );
		
		$this->assertTrue( isset($_SESSION['status-message']) );
		
		$probe = reset($_SESSION['status-message']);
		
		$this->assertEquals( 'test', $probe->message );
	}
	
	/**
	 * test
	 */
	public function test_status_get_all() {
		
		$_SESSION = [];
		
		\pulsecore\session\status_add( 'test' );
		
		$result = \pulsecore\session\status_get_all();
		
		$this->assertTrue(   isset($_SESSION['status-message']) );
		$this->assertTrue( \sizeof($_SESSION['status-message']) == 0);
		
		$this->assertTrue( \sizeof($result) == 1);
		
		$probe = reset($result);
		
		$this->assertEquals( 'test', $probe->message );
	}
	
	/**
	 * test
	 */
	public function test_status_init() {
		
		$_SESSION = [];
		
		\pulsecore\session\status_init();
		
		$this->assertTrue( isset($_SESSION['status-message']) );
	}
	
	/**
	 * test
	 */
	public function test_status_to_js() {
		
		$_SESSION = [];
		
		\pulsecore\session\status_add( 'test' );
		
		$result = \pulsecore\session\status_to_js();
		
		$this->assertTrue( \strlen($result) > 0 );
	}
}
