<?php
namespace pulsecore\test\common;

/**
 * unit tests for misc functions
 */
class MiscTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 */
	public function test_apply_default_params () {
		
		$result = \pulsecore\apply_default_params(
			[
				'a' => 'aaa',
				'b' => null,
			],
			[
				'a' => 'b',
				'b' => 'two'
			]
		);
		
		$this->assertEquals( 'aaa', $result['a']);
		$this->assertEquals( 'two', $result['b']);
	}
	
	/**
	 * test
	 */
	public function test_autodetect_domain() {
		
		$result = \pulsecore\autodetect_domain('http://www.google.com/a/b/c');
		
		$this->assertEquals( 'www.google.com', $result );
	}
	
	/**
	 * test
	 * @dataProvider provider_autodetect_root_path
	 */
	public function test_autodetect_root_path ($uri, $probe, $expected) {
		
		$result = \pulsecore\autodetect_root_path( $uri, $probe );
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_autodetect_root_path () {
		return [
			["https://localghost/admin/index.php?p=settings", "https://localhost/admin/index.php", ""],
			["/admin/index.php?p=settings",                   "https://localhost/admin/index.php", ""],
			
			["/admin/index.php?p=settings",                   "/admin/index.php", ""]
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_autodetect_script_dir
	 */
	public function test_autodetect_script_dir ($arg, $expected) {
		$this->assertEquals( $expected, \pulsecore\autodetect_script_dir($arg) );
	}
	
	/**
	 * provider
	 */
	public function provider_autodetect_script_dir () {
		return [
			["/var/www/moose/install.php", "/var/www/moose"]
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_language_to_iso
	 */
	public function test_language_to_iso ($arg, $expected) {
		$this->assertEquals( $expected, \pulsecore\language_to_iso($arg) );
	}
	
	/**
	 * provider
	 */
	public function provider_language_to_iso () {
		return [
			["czech",     "cs"],
			["deutsch",   "de"],
			["dutch",     "nl"],
			["english",   "en"],
			["hungarian", "hu"],
			["japanese",  "ja"],
			["polish",    "pl"],
			["portuguese_BR",    "pt_br"],
			["romanian",  "ro"],
			["russian",  "ru"],
			["slovak",    "sk"],
			["spanish",    "es"]
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_detect_all_headers
	 */
	public function test_detect_all_headers ($arg, $expected) {
		
		$tmp = \pulsecore\detect_all_headers($arg);
		
		$this->assertEquals( \sizeof($expected), \sizeof($tmp) );
		
		foreach ($tmp as $key => $value) {
			$this->assertEquals( $expected[$key], $value );
		}
	}
	
	/**
	 * provider
	 */
	public function provider_detect_all_headers () {
		return [
			[false, ['HTTP_HOST' => 'test.runner'] ],
			[true,  ['HTTP_HOST' => 'test.runner'] ]
		];
	}
	
	/**
	 * test
	 */
	public function test_convert_date_format_php_to_moment () {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_convert_date_format_to_strftime () {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 * @dataProvider provider_convert_date_format_to_intl
	 */
	public function test_convert_date_format_to_intl ($format, $expected) {
		
		$result = \pulsecore\convert_date_format_to_intl( $format );
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	function provider_convert_date_format_to_intl () {
		return [
			['M j, Y', 'MMM d, yyyy']
		];
	}
	
	/**
	 * test
	 */
	public function test_convert_to_utf8 () {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_dir_nuke () {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_dir_size () {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 * @dataProvider provider_format_bytes
	 */
	public function test_format_bytes ($arg, $expected) {
		$result = \pulsecore\format_bytes( $arg );
		
		$this->assertEquals( $expected, $result );
	}
	/**
	 * provider
	 */
	function provider_format_bytes () {
		return [
			[    10,                '10 B'],
			[  1024,                 '1 KB'],
			[ (1024*1024),           '1 MB'],
			[ (1024*1024*1024),      '1 GB'],
			[ (1024*1024*1024*1024), '1 TB']
			
		];
	}
	
	/**
	 * test
	 */
	public function test_generate_non_navigation_pages () {
		
		$page_list = \pulsecore\generate_non_navigation_pages(
			'/test/url/prefix',
			(object)array()
		);
		
		$this->assertTrue(     isset($page_list) );
		$this->assertTrue( \is_array($page_list) );
		
		# pick a page and test that
		$this->assertTrue( isset($page_list['about']) );
		$this->assertTrue(       $page_list['about'] instanceof \stdClass );
		
		$this->assertEquals( true,     $page_list['about']->active );
		$this->assertEquals( '/about', $page_list['about']->url );
	}
	
	/**
	 * test
	 */
	public function test_generate_uuid () {
		
		$uuid = \pulsecore\generate_uuid( 'this is a test' );
		
		$this->assertTrue(      isset($uuid) );
		$this->assertTrue( \is_string($uuid) );
		$this->assertTrue(    \strlen($uuid) == (32 + 4));
	}
	
	/**
	 * test
	 */
	public function test_generate_non_image_file_types () {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 * @dataProvider provider_maybe_base_url
	 */
	public function test_maybe_base_url ($url, $expected) {
		
		$result = \pulsecore\maybe_base_url ($url);
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	function provider_maybe_base_url () {
		return [
			['',     '/'],
			['/foo', '/foo'],
			['/foo', '/foo']
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_pulse_url
	 */
	public function test_pulse_url ($url, $expected) {
		
		$result = \pulsecore\pulse_url ($url);
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	function provider_pulse_url () {
		
		$domain      = \pulsecore\get_configs()->domain;
		$http_scheme = \pulsecore\get_configs()->http_scheme;
		
		$admin    = \pulsecore\wedge\config\get_json_configs()->json->admin;
		$path     = \pulsecore\wedge\config\get_json_configs()->json->path;
		
		
		return [
			['',           "{$http_scheme}://{$domain}$path"],
			['/foo',       "{$http_scheme}://{$domain}$path/foo"],
			['/admin/foo', "{$http_scheme}://{$domain}$path/{$admin}/foo"]
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_page_info_blog
	 */
	function test_page_info_blog ($url_info, $blog_prefix, $expected) {
		
		$result = \pulsecore\page_info_blog( $url_info, $blog_prefix );
		
		if ($expected === false) {
			$this->assertEquals( $expected, $result );
			
		} else {
			
			$this->assertEquals( $expected->blog_id,   $result->blog_id);
			$this->assertEquals( $expected->page_name, $result->page_name);
		}
	}
	
	/**
	 * provider
	 */
	function provider_page_info_blog () {
		return [
			[(object)[ 'url_info' => ['scheme' => 'http', 'host' => 'localhost', 'path' => '/'], 'url_broken' => ''],
			'blog',
			 false
			],
			[(object)[ 'url_info' => ['scheme' => 'http', 'host' => 'localhost', 'path' => '/blog'], 'url_broken' => 'blog'],
			'blog',
			 (object)[ 'page_name' => 'blog-home', 'blog_id' => false]
			],
			[(object)[ 'url_info' => ['scheme' => 'http', 'host' => 'localhost', 'path' => '/blog-5-A-Very-Nice-Blog-Post'], 'url_broken' => 'blog-5-A-Very-Nice-Blog-Post'],
			'blog',
			 (object)[ 'page_name' => 'blog', 'blog_id' => '5']
			]
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_page_info_url
	 */
	function test_page_info_url ($url, $blog_prefix, $expected) {
		
		$result = \pulsecore\page_info_url( $url, $blog_prefix );
		
		$this->assertEquals( $expected->url_info['scheme'], $result->url_info['scheme']);
		$this->assertEquals( $expected->url_info['host'],   $result->url_info['host']);
		$this->assertEquals( $expected->url_info['path'],   $result->url_info['path']);
		
		$this->assertEquals( $expected->url_broken, $result->url_broken);
	}
	
	/**
	 * provider
	 */
	function provider_page_info_url () {
		return [
			['http://localhost/',     'blog', (object)[ 'url_info' => ['scheme' => 'http', 'host' => 'localhost', 'path' => '/'], 'url_broken' => ''] ],
			['http://localhost/blog', 'blog', (object)[ 'url_info' => ['scheme' => 'http', 'host' => 'localhost', 'path' => '/blog'], 'url_broken' => 'blog'] ],
			['http://localhost/blog-5-A-Very-Nice-Blog-Post', 'blog', (object)['url_info' => ['scheme' => 'http', 'host' => 'localhost', 'path' => '/blog-5-A-Very-Nice-Blog-Post'], 'url_broken' => 'blog-5-A-Very-Nice-Blog-Post'] ]
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_strip_pulse_tags
	 */
	function test_strip_pulse_tags ($arg, $expected) {
		
		$result = \pulsecore\strip_pulse_tags( $arg );
		
		$this->assertEquals( $expected, $result);
	}
	
	/**
	 * provider
	 */
	function provider_strip_pulse_tags () {
		return [
			['a ##more## b', 'a  b'],
			['a {{qqq}} b',             'a   b'],
			['a {{qqq}}zzz{{\qqq}} b',  'a   b']
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_url_extract_blog_page
	 */
	public function test_url_extract_blog_page ($blog_prefix, $url, $expected) {
		
		$page = \pulsecore\url_extract_blog_page ($blog_prefix, $url);
		
		$this->assertEquals( $expected, $page );
	}
	
	/**
	 * provider
	 */
	function provider_url_extract_blog_page () {
		return [
			['blog', '/blog-page-1?blog_name=', 1], ['blog', 'http://www.domain.com/blog-page-1?blog_name=', 1],
			['blog', '/blog-page-2?blog_name=', 2], ['blog', 'http://www.domain.com/blog-page-2?blog_name=', 2],
			['blog', '/blog-page-3?blog_name=', 3], ['blog', 'http://www.domain.com/blog-page-3?blog_name=', 3],
			['blog', '/blog-page-4?blog_name=', 4], ['blog', 'http://www.domain.com/blog-page-4?blog_name=', 4],
			['blog', '/blog-page-5?blog_name=', 5], ['blog', 'http://www.domain.com/blog-page-5?blog_name=', 5],
			
			['blog', 'https://cakespirit.co.uk/tagged/blog-page-1?blog_name=&blog_tag_name=gluten+free', 1],
			['blog', 'https://cakespirit.co.uk/tagged/blog-page-2?blog_name=&blog_tag_name=gluten+free', 2],
			['blog', 'https://cakespirit.co.uk/tagged/blog-page-3?blog_name=&blog_tag_name=gluten+free', 3],
			['blog', 'https://cakespirit.co.uk/tagged/blog-page-4?blog_name=&blog_tag_name=gluten+free', 4],
			['blog', 'https://cakespirit.co.uk/tagged/blog-page-5?blog_name=&blog_tag_name=gluten+free', 5]
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_url_join
	 */
	public function test_url_join ($path1, $path2, $expected) {
		
		$result = \pulsecore\url_join ($path1, $path2);
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	function provider_url_join () {
		return [
			['',    '/a', '/a'],
			['/',   '/a', '/a'],
			['/a',  '/b', '/a/b'],
			['/a/', '/b', '/a/b']
		];
	}
	
	/**
	 * unit test
	 * @dataProvider provider_utf8_date_format
	 */
	public function test_utf8_date_format ($format, $timestamp, $expected) {
		
		$result = \pulsecore\utf8_date_format($format, $timestamp);
		
		$this->assertEquals( $expected, $result );
	}
	
	
	/**
	 * provider
	 */
	function provider_utf8_date_format () {
		return [
			#["%B %d, %Y %H:%M:%S", 1551796654, 'March 05, 2019 23:37:34'],
			['F d, Y H:i:s',       1551796654, 'March 05, 2019 23:37:34']
		];
	}
	
	/**
	 * unit test
	 * @dataProvider provider_word_truncate
	 */
	public function test_word_truncate ($arg, $limit, $expected) {
		
		$result = \pulsecore\word_truncate($arg, $limit);
		
		$this->assertEquals( $expected, $result );
	}
	
	
	/**
	 * provider
	 */
	function provider_word_truncate () {
		return [
			['a b c', 2, 'a b'],
			['a b,c', 2, 'a b,'],
			['a b;c', 2, 'a b;'],
			['a b:c', 2, 'a b:']
		];
	}
}
