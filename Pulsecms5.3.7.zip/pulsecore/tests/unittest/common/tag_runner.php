<?php
namespace pulsecore\test\common;

/**
 * unit tests for tag runner
 */
class TagRunnerTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 */
	public function test_expand_single_tag () {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_expand () {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 * @dataProvider provider_parse
	 */
	public function test_parse ($arg, $expected) {
		
		$result = \pulsecore\tag_runner\parse( $arg );
		
		$this->assertTrue( \is_array($result) );
		
		foreach ($result as $key => $value) {
			
			$this->assertTrue( isset($value->content) );
			$this->assertTrue( isset($value->data) );
			$this->assertTrue( isset($value->name) );
			
			$this->assertEquals( $expected[$key]->content, $value->content );
			$this->assertEquals( $expected[$key]->name,    $value->name );
			
			$this->assertEquals( \sizeof($expected[$key]->data), \sizeof($value->data) );
			
			foreach ($value->data as $p => $q) {
				$this->assertEquals( $expected[$key]->data[$p], $q );
			}
		}
	}
	
	/**
	 * provider
	 */
	public function provider_parse () {
		return [
			[
				'{{block:"foo"}}',
				[ 
					(object)[
						'data' => ['foo'],
						'name' => 'block',
						'content' => '{{block:"foo"}}'
					]
				]
			],
			[
				'{{block:foo}}',
				[ 
					(object)[
						'data' => ['foo'],
						'name' => 'block',
						'content' => '{{block:foo}}'
					]
				]
			],
			[
				'{{block:mouse/hippo}}',
				[ 
					(object)[
						'data' => ['mouse/hippo'],
						'name' => 'block',
						'content' => '{{block:mouse/hippo}}'
					]
				]
			]
		];
	}
}
