<?php
namespace pulsecore\test\common;

/**
 * unit tests for validation
 */
class ValidateTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 * @dataProvider provider_hex
	 */
	public function test_hex($expected, $arg) {
		
		$result = \pulsecore\validate\hex( $arg );
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_hex () {
		return [
			[true,  'abcdef0123456789'],
			[false, 'zzz']
		];
	}
}
