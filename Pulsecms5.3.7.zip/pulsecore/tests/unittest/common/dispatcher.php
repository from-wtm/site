<?php
namespace pulsecore\test\common;

/**
 * unit tests for dispatcher
 */
class DispatcherTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 * @dataProvider provider_dispatch
	 */
	public function test_dispatch($expected, $request_params, $request_cookie) {
		
		$result = \pulsecore\dispatch( $request_params, $request_cookie );
		
		foreach ($expected as $expected_key => $expected_value) {
			
			$this->assertTrue( isset($result[$expected_key]) );
			$this->assertEquals( $expected_value, $result[$expected_key] );
		}
	}
	
	/**
	 * provider
	 */
	public function provider_dispatch () {
		return [
			[['p' => 'blog', 'd' => '6'], ['p' => 'blog-6-a-very-nice-blog-post'], []],
			
			[['p' => 'rss_blog', 'd' => 'meep'],  ['p' => 'meep/rss'],  []],
			[['p' => 'rss_blog', 'd' => 'media'], ['p' => 'media/rss'], []]
		];
	}
}
