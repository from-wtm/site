<?php
namespace pulsecore\test\common;

/**
 * unit tests for filter functions
 */
class FilterTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 * @dataProvider provider_blog_item_id
	 */
	public function test_blog_item_id ($arg, $expected) {
		
		$result = \pulsecore\filter\blog_item_id($arg);
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_blog_item_id () {
		return [
			['20180309010644018', '20180309010644018'],
			['draft-aaa',         'draft-aaa'],
			['@#aaa',             'aaa'],
			['qwerty-meep/20180125010459006-blog-title', 'qwerty-meep/20180125010459006-blog-title']
		];
	}
	
	/**
	 * test
	 */
	public function test_blog_item_url() {
		
		$result = \pulsecore\filter\blog_item_url('media/20180309010644018');
		
		$this->assertEquals( 'media/20180309010644018', $result );
	}
	
	/**
	 * test
	 */
	public function test_blog_title_in_url() {
		
		$this->assertEquals( 'a-b12AB-c', \pulsecore\filter\blog_title_in_url('a b12AB-c') );
	}
	
	/**
	 * test
	 */
	public function test_custom_post_type_name () {
		
		$this->assertEquals( 'ab12AB-c/moose.txt', \pulsecore\filter\custom_post_type_name('a b12AB-c/moose.txt') );
	}
	
	/**
	 * test
	 */
	public function test_gallery_directory () {
		
		$this->assertEquals( 'ab12AB-c/moose', \pulsecore\filter\gallery_directory('a b12AB-c/moose') );
	}
	
	/**
	 * test
	 */
	public function test_f_int () {
		
		$this->assertEquals( '112312', \pulsecore\filter\f_int('+-1abc123.12') );
	}
	
	/**
	 * test
	 */
	public function test_f_param () {
		$this->assertEquals( 'a/B/1_2', \pulsecore\filter\f_param('../a/B/1_2') );
	}
	
	/**
	 * test
	 */
	public function test_file_extension () {
		$this->assertEquals( 'txtT01', \pulsecore\filter\f_param('.txtT01') );
	}
	
	/**
	 * test
	 */
	public function test_file_extension_list () {
		$this->assertEquals( 'mp4,mp3', \pulsecore\filter\file_extension_list('mp4, mp3') );
	}
	
	/**
	 * test
	 * @dataProvider provider_file_name
	 */
	public function test_file_name ($arg, $expected) {
		
		$result = \pulsecore\filter\file_name($arg);
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_file_name () {
		return [
			['m/abc.txtT01',     'm/abc.txtT01'],
			['heißt',            'heißt'],
			['Das Fußballspiel', 'DasFußballspiel'],
			['Frühstück',        'Frühstück']
		];
	}
	
	/**
	 * test
	 */
	public function test_hex () {
		$this->assertEquals( '0123456789abcdef', \pulsecore\filter\hex('0123456789abcdef_mnvzxqwrty') );
	}
	
	/**
	 * test
	 */
	public function test_ip () {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 * @dataProvider provider_item_url
	 */
	public function test_item_url ($arg, $expected) {
		$result = \pulsecore\filter\item_url( $arg );
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_item_url () {
		return [
			['/media/gallery1/dots.in.filename', 'media/gallery1/dots.in.filename'],
			['../../../a', 'a'],
			['/abc', 'abc'],
			['Frühstück', 'Frühstück'],
			['"abc"', 'abc']
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_navigation
	 */
	public function test_navigation ($arg, $expected) {
		$result = \pulsecore\filter\navigation($arg);
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_navigation () {
		return [
			['aa-bb',    'aa bb'],
			['aabbc',    'aabbc'],
			['abc123',   'abc123'],
			['aa_bbc',   'aa_bbc'],
			['aa/bb',    'aa bb'],
			['aa/bb-cc', 'aa bb cc'],
			
			['Füße',  'Füße'],
			['Länge', 'Länge']
		];
	}
	
	/**
	 * test
	 */
	public function test_normalise_fs_path () {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_page () {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 * @dataProvider provider_tag_param
	 */
	public function test_tag_param ($arg, $expected) {
		
		$result = \pulsecore\filter\tag_param( $arg );
		
		$this->assertEquals($expected, $result);
	}
	/**
	 * provider
	 */
	public function provider_tag_param () {
		return [
			['mars', 'mars'],
			['"mars"',  'mars' ],
			['""mars"""""',  'mars' ],
			
			['ma "args" rs',  'ma "args" rs' ]
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_yes_no
	 */
	public function test_yes_no ($arg, $expected) {
		
		$result = \pulsecore\filter\yes_no( $arg );
		
		$this->assertEquals($expected, $result);
	}
	/**
	 * provider
	 */
	public function provider_yes_no () {
		return [
			['yes', 'yes'],
			['no',  'no' ],
			['aa',  '']
		];
	}
	
	
	/**
	 * test
	 */
	public function test_url () {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 * @dataProvider provider_uuid
	 */
	public function test_uuid ($arg, $expected) {
		
		$result = \pulsecore\filter\uuid( $arg );
		
		$this->assertEquals( $expected, $result );
	}
	/**
	 * provider
	 */
	public function provider_uuid () {
		return [
			['233e4567-e89b-12d3-b456-426655441234', '233e4567-e89b-12d3-b456-426655441234']
		];
	}
	
	/**
	 * test
	 */
	public function test_variable_name () {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 * @dataProvider provider_view_helper_name
	 */
	public function test_view_helper_name ($arg, $expected) {
		
		$result = \pulsecore\filter\view_helper_name($arg);
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_view_helper_name () {
		return [
			['escape',    '\pulsecore\view\helper\Escape'],
			['test_this', '\pulsecore\view\helper\TestThis']
		];
	}
}
