<?php
namespace pulsecore\test\common;

/**
 * unit tests for ACL role testing
 */
class AclRoleTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 * @dataProvider provider_can_edit_resource
	 */
	public function test_can_edit_resource($expected, $edit_roles, $session) {
		
		$_SESSION = $session;
		
		$result = \pulsecore\acl_role\can_edit_resource($edit_roles);
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_can_edit_resource () {
		return [
			[true,  'admin', ['acl_role' => \pulsecore\get_configs()->acl_role->admin] ],
			[false, 'admin', ['acl_role' => \pulsecore\get_configs()->acl_role->editor] ],
			[false, 'admin', ['acl_role' => \pulsecore\get_configs()->acl_role->guest] ],
			
			[true,  'admin and editor', ['acl_role' => \pulsecore\get_configs()->acl_role->admin] ],
			[true,  'admin and editor', ['acl_role' => \pulsecore\get_configs()->acl_role->editor] ],
			[false, 'admin and editor', ['acl_role' => \pulsecore\get_configs()->acl_role->guest] ],
			
			[false, 'editor', ['acl_role' => \pulsecore\get_configs()->acl_role->admin] ],
			[true,  'editor', ['acl_role' => \pulsecore\get_configs()->acl_role->editor] ],
			[false, 'editor', ['acl_role' => \pulsecore\get_configs()->acl_role->guest] ]
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_check
	 */
	public function test_check ($role, $resource, $grant, $expected) {
		
		$result = \pulsecore\acl_role\check($role, $resource, $grant);
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_check () {
		return [
			[\pulsecore\get_configs()->acl_role->admin,  'p_home', 'view', true],
			[\pulsecore\get_configs()->acl_role->editor, 'p_home', 'view', true],
			[\pulsecore\get_configs()->acl_role->user,   'p_home', 'view', false],
			[\pulsecore\get_configs()->acl_role->guest,  'p_home', 'view', false]
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_check_or_redirect
	 * @runInSeparateProcess
	 */
	public function test_check_or_redirect ($role, $resource, $grant, $expected) {
		
		/*
		#\ob_start();
		
		\pulsecore\acl_role\check_or_redirect($role, $resource, $grant);
		
		#$html = \ob_get_contents();
		
		#\ob_end_clean();
		
		$this->assertContains( $expected );
		*/
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * provider
	 */
	public function provider_check_or_redirect () {
		return [
			[\pulsecore\get_configs()->acl_role->admin,  'p_home', 'view', ('Location: ' . PULSE_ADMIN_URL . "/index.php")],
			[\pulsecore\get_configs()->acl_role->editor, 'p_home', 'view', ('Location: ' . PULSE_ADMIN_URL . "/index.php")],
			[\pulsecore\get_configs()->acl_role->user,   'p_home', 'view', ('Location: ' . PULSE_ADMIN_URL . "/index.php")],
			[\pulsecore\get_configs()->acl_role->guest,  'p_home', 'view', ('Location: ' . PULSE_BASE_URL  . "/index.php")]
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_is_administrator
	 */
	public function test_is_administrator($expected, $session) {
		
		$_SESSION = $session;
		
		$result = \pulsecore\acl_role\is_administrator();
		
		$this->assertEquals( $expected, $result );
	}
	/**
	 * provider
	 */
	public function provider_is_administrator () {
		return [
			[true,  ['acl_role' => \pulsecore\get_configs()->acl_role->admin] ],
			[false, ['acl_role' => \pulsecore\get_configs()->acl_role->editor]],
			[false, ['acl_role' => \pulsecore\get_configs()->acl_role->guest] ],
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_is_editor
	 */
	public function test_is_editor($expected, $session) {
		
		$_SESSION = $session;
		
		$result = \pulsecore\acl_role\is_editor();
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_is_editor () {
		return [
			[false, ['acl_role' => \pulsecore\get_configs()->acl_role->admin] ],
			[true,  ['acl_role' => \pulsecore\get_configs()->acl_role->editor]],
			[false, ['acl_role' => \pulsecore\get_configs()->acl_role->guest] ],
		];
	}
	
	/**
	 * test
	 * @dataProvider provider_is_editor_allowed
	 */
	public function test_is_editor_allowed ($get_p, $get_f, $session_acl_role) {
		
		/*
		
		$_GET['p'] = $get_p;
		$_GET['f'] = $get_f;
		
		$_SESSION['acl_role'] = $session_acl_role;
		
		\ob_start();
		
		\pulsecore\acl_role\is_editor_allowed();
		
		$html = \ob_get_contents();
		
		\ob_end_clean();
		
		$this->assertEquals( $expected, $html );
		*/
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * provider
	 */
	public function provider_is_editor_allowed () {
		return [
			['blog',  '', \pulsecore\get_configs()->acl_role->admin,  true],
			['blog',  '', \pulsecore\get_configs()->acl_role->editor, true],
			['blog',  '', \pulsecore\get_configs()->acl_role->user,   true],
			['blog',  '', \pulsecore\get_configs()->acl_role->gues,   true]
		];
	}
	
	/**
	 * test
	 */
	public function is_editor_allowed_resource ($expected, $resource) {
		
		$result = \pulsecore\acl_role\is_editor_allowed_resource($resource);
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_is_editor_allowed_resource () {
		return [
			[true,  'block'],
			[true,  'page'],
			[false, 'mouse']
		];
	}
	
	/**
	 * test
	 */
	public function test_is_logged_in() {
		
		#\pulsecore\acl_role\is_logged_in();
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 * @dataProvider provider_is_session_expired
	 */
	public function test_is_session_expired($expected, $session) {
		
		$result = \pulsecore\acl_role\is_session_expired( $session );
		
		$this->assertEquals( $expected, $result );
	}
	
	/**
	 * provider
	 */
	public function provider_is_session_expired () {
		return [
			[true,  [] ],
			[true,  ['mpass_session_expires' => (\time() - 10000)]],
			[false, ['mpass_session_expires' => (\time() + 10000)] ],
		];
	}
	
	/**
	 * test
	 */
	public function test_is_valid_session_token() {
		
		# \pulsecore\acl_role\is_valid_session_token();
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
