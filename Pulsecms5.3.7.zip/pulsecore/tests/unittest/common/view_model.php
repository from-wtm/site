<?php
namespace pulsecore\test\common;

/**
 * unit tests for view model
 */
class ViewModelTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 */
	public function test_get_set() {
		
		$model = new \pulsecore\ViewModel();
		
		$model->a = 'b';
		
		$this->assertEquals( 'b', $model->a );
	}
	
	/**
	 * test
	 */
	public function test_isset() {
		
		$model = new \pulsecore\ViewModel();
		
		$model->a = 'b';
		
		$this->assertTrue(  isset($model->a) );
		$this->assertFalse( isset($model->b) );
	}
	
	/**
	 * test
	 */
	public function test_unset() {
		
		$model = new \pulsecore\ViewModel();
		
		$model->a = 'a';
		$model->b = 'b';
		
		$this->assertTrue(  isset($model->a) );
		$this->assertTrue(  isset($model->b) );
		
		unset( $model->b );
		
		$this->assertTrue(  isset($model->a) );
		$this->assertFalse( isset($model->b) );
	}
	
}
