<?php
namespace pulsecore\test\common;

/**
 * unit tests for image
 */
class ImageTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 */
	public function test_info() {
		
		$filename = \pulsecore\test\TEST_DIR . '/content/media/gallery/avatar.jpg';
		
		$result = \pulsecore\image\info( $filename );
		
		$this->assertTrue( $result instanceof \stdClass );
		$this->assertTrue( isset($result->width) );
		$this->assertTrue( isset($result->height) );
		$this->assertTrue( isset($result->type) );
		$this->assertTrue( isset($result->mime) );
		
		$this->assertTrue( \is_numeric($result->width) );
		$this->assertTrue( \is_numeric($result->height) );
	}
	
	/**
	 * test
	 */
	public function test_is_image () {
		
		# +ve
		$result = \pulsecore\image\is_image( \pulsecore\test\TEST_DIR . '/content/media/gallery/avatar.jpg' );
		
		$this->assertTrue( $result );
		
		# -ve
		$result = \pulsecore\image\is_image( \pulsecore\test\TEST_DIR . '/content/media/gallery/index.html' );
		
		$this->assertFalse( $result );
	}
	
	/**
	 * test
	 */
	public function test_load() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_scale() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_thumbnail() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_thumbnail_path() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
