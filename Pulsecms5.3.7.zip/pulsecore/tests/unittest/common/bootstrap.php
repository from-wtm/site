<?php
namespace pulsecore\test\common;

/**
 * unit tests for bootstrap functions
 */
class BootstrapTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * test
	 */
	public function test_get_configs () {
		
		$status = \pulsecore\get_configs();
		
		$this->assertTrue( $status instanceof \stdClass );
	}
	
	/**
	 * test
	 */
	public function test_get_context () {
		
		$status = \pulsecore\get_context();
		
		$this->assertTrue( $status instanceof \stdClass );
	}
	
	/**
	 * test
	 * @dataProvider provider_set_i18n
	 */
	public function test_set_i18n ($timezone, $language) {
		
		$status = \pulsecore\set_i18n( $timezone, $language );
		
		$this->assertTrue( $status );
	}
	
	/**
	 * provider
	 */
	public function provider_set_i18n () {
		return [
			['Europe/Prague',    'czech'],
			['Europe/Berlin',    'deutsch'],
			['Europe/Amsterdam', 'dutch'],
			['Europe/London',    'english'],
			['Europe/Budapest',  'hungarian'],
			['Asia/Tokyo',       'japanese'],
			['Europe/Warsaw',    'polish'],
			['America/Sao_Paulo','portuguese_BR'],
			['Europe/Bucharest', 'romanian'],
			['Europe/Moscow',    'russian'],
			['Europe/Ljubljana', 'slovak'],
			['Europe/Madrid',    'spanish']
		];
	}
}
