<?php
namespace pulsecore\test\route;

/**
 * unit tests for route
 */
class BlogItemTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\route\BlogItem();
	}
	
	/**
	 * test
	 * @param string $url
	 * @param array $route_params
	 * @param array $get HTTP get params
	 * @param array $cookie
	 * 
	 * @param array $expected value
	 * @dataProvider provider_dispatch
	 */
	public function test_dispatch (string $url, array $route_params, array $get, array $cookie, array $expected) {
		
		$result = $this->iii->dispatch( $url, $route_params, $get, $cookie );
		
		$this->assertEquals( $expected['d'], $result['d'] );
		$this->assertEquals( $expected['p'], $result['p'] );
	}
	
	/**
	 * provider
	 */
	public function provider_dispatch () {
		return [
			['blog/A-Very-Nice-Blog-Post/6',            ['subblog' => '',            'slug' => 'A-Very-Nice-Blog-Post', 'id' => '6'], [], [], ['p' => 'blog', 'd' => '6'] ],
			['blog/sub/A-Very-Nice-Blog-Post/6',        ['subblog' => '/sub',        'slug' => 'A-Very-Nice-Blog-Post', 'id' => '6'], [], [], ['p' => 'blog', 'd' => 'sub/6'] ],
			['blog/sub/subsub/A-Very-Nice-Blog-Post/6', ['subblog' => '/sub/subsub', 'slug' => 'A-Very-Nice-Blog-Post', 'id' => '6'], [], [], ['p' => 'blog', 'd' => 'sub/subsub/6'] ]
		];
	}
	
	/**
	 * test
	 * @param string $url
	 * @param array $get HTTP get params
	 * @param array $cookie
	 * @param bool $expected value
	 *
	 * @dataProvider provider_match
	 */
	public function test_match (string $url, array $get, array $cookie, bool $expected_status, array $expected_route_params) {
		
		list($result, $route_params) = $this->iii->match( $url, $get, $cookie );
		
		$this->assertEquals( $expected_status, $result );
		
		$this->assertEquals( $expected_route_params['subblog'], $route_params['subblog'] );
		$this->assertEquals( $expected_route_params['slug'],    $route_params['slug'] );
	}
	
	/**
	 * provider
	 */
	public function provider_match () {
		return [
			['blog/A-Very-Nice-Blog-Post/6',            [], [], true, ['subblog' => '',            'slug' => 'A-Very-Nice-Blog-Post', 'id' => '6'] ],
			['blog/sub/A-Very-Nice-Blog-Post/6',        [], [], true, ['subblog' => '/sub',        'slug' => 'A-Very-Nice-Blog-Post', 'id' => '6'] ],
			['blog/sub/subsub/A-Very-Nice-Blog-Post/6', [], [], true, ['subblog' => '/sub/subsub', 'slug' => 'A-Very-Nice-Blog-Post', 'id' => '6'] ]
		];
	}
}
