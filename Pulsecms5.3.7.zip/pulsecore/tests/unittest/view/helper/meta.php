<?php
namespace pulsecore\test\view\helper;

/**
 * unit tests for view helper
 */
class MetaTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\view\helper\Meta();
	}
	
	/**
	 * test
	 */
	public function test_render () {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
