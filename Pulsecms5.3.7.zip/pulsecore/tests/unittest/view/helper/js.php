<?php
namespace pulsecore\test\view\helper;

/**
 * unit tests for view helper
 */
class JsTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\view\helper\Js();
	}
	
	/**
	 * test
	 */
	public function test_render () {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
