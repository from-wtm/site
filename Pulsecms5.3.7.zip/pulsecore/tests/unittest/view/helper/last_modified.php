<?php
namespace pulsecore\test\view\helper;

/**
 * unit tests for view helper
 */
class LastModifiedTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\view\helper\LastModified();
	}
	
	/**
	 * test
	 */
	public function test_render () {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
