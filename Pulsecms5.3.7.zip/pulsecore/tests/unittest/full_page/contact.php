<?php
namespace pulsecore\test\full_page;

/**
 * unit tests for page
 */
class ContactTest extends \pulsecore\test\TestCase {
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
	}
	
	/**
	 * test
	 */
	public function test_run() {
		
		$result = $this->fetch_url( 'http://localhost/contact' );
		
		# hide the inevitable html formatting bugs
		\libxml_use_internal_errors(true);
		
		# parse`
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $result->body );
		
		# valid HTML
		$this->assertTrue( $status );
		
		# ensure header
		$xpath = new \DOMXPath( $doc );
		$query = '//html/body//div/h2';
		$nodes = $xpath->query( $query );
		
		$this->assertTrue( \sizeof($nodes) == 1 );
	}
}
