<?php
namespace pulsecore\test\full_page\admin;

/**
 * base class for unit tests for admin page
 */
abstract class Base extends \pulsecore\test\TestCase {
	
	/**
	 * common tests for a response
	 * \param $response stdClass
	 */
	protected function common_tests (\stdClass $response) {
		
		$this->assertTrue( \intval($response->response_code) == 200);
		
		$this->assertTrue( \strlen($response->body) > 0);
		
		$this->assertTrue( \stripos($response->body, 'Parse error:') === false);
		$this->assertTrue( \stripos($response->body, 'Notice:') === false);
		$this->assertTrue( \stripos($response->body, 'Warning:') === false);
	}
	
	/**
	 * login cookie
	 */
	public static $login_cookie = false;
	
	/**
	 * extract the cookies from a HTTP response
	 * \param $response stdClass
	 * \return array
	 */
	protected function extract_cookies (\stdClass $response) {
		
		$result = array();
		
		$cookies = $response->headers['Set-Cookie'];
		
		$value = $cookies;
		#foreach ($cookies as $value) {
			
			$splitted = \explode( ';', \trim($value) );
			
			$splitted = \explode('=', \trim($splitted[0]) );
			
			$result[ \urldecode($splitted[0]) ] = \urldecode( $splitted[1] );
		#}
		
		return $result;
	}
	
	/**
	 * extract the log token from a HTTP response
	 * \param $response stdClass
	 * \return string
	 */
	protected function extract_log_token (\stdClass $response) {
		
		# hide the inevitable html formatting bugs
		\libxml_use_internal_errors(true);
		
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $response->body );
		
		# valid HTML
		$this->assertTrue( $status );
		
		# ensure header
		$xpath     = new \DOMXPath( $doc );
		$query     = '//input[@name="log_token"]';
		$node_list = $xpath->query( $query );
		
		$log_token = $node_list->item(0)->attributes->getNamedItem('value')->value;
		
		return $log_token;
	}
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		if (Base::$login_cookie === false) {
			
			# load the form and cookie
			$result = $this->fetch_url(
				'http://localhost/admin/',
				'get'
			);
			
			Base::$login_cookie = $this->extract_cookies( $result );
			
			# parse`
			$log_token = $this->extract_log_token( $result );
			
			# POST
			$result = $this->fetch_url(
				'http://localhost/admin/',
				'post',
				Base::$login_cookie,
				array(),
				array(
					'username'   => 'administrator',
					'mpass_pass' => 'demo',
					'log_token'  => $log_token
				)
			);
			
			Base::$login_cookie = \array_merge(
				Base::$login_cookie,
				$this->extract_cookies( $result )
			);
			
		}
	}
	
	/**
	 * test
	 */
	abstract public function test_run( $url = '');
}
