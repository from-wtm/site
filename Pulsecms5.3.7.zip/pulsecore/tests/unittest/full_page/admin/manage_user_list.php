<?php
namespace pulsecore\test\full_page\admin;

require_once (__DIR__ . '/base.php' );

/**
 * unit tests for page
 */
class ManageUserListTest extends \pulsecore\test\full_page\admin\Base {
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		parent::setUp();
	}
	
	/**
	 * test
	 */
	public function test_run ($url = '') {
		
		$result = $this->fetch_url( 'http://localhost/admin/index.php?p=manage_user_list', 'get', Base::$login_cookie );
		
		# check response
		$this->common_tests($result);
		
		# hide the inevitable html formatting bugs
		\libxml_use_internal_errors(true);
		
		# parse`
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $result->body );
		
		# valid HTML
		$this->assertTrue( $status );
		
		# ensure header
		$xpath = new \DOMXPath( $doc );
		$query = '//html/body//i[@class="fa fa-tachometer-alt"]';
		$nodes = $xpath->query( $query );
		
		$this->assertTrue( \sizeof($nodes) > 0 );
	}
}
