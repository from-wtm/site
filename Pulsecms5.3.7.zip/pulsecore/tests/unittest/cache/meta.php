<?php
namespace pulsecore\test\cache;

/**
 * unit tests for cache
 */
class MetaTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * meta instance
	 */
	protected $meta = false;
	
	/**
	 * setup
	 */
	protected function setUp () {
		
		$this->meta = new \pulsecore\cache\Meta( \pulsecore\get_configs()->dir_storage . '/cache/' . \strval(\pulsecore\cache\Manager::HOUR_1) );
		
		$this->meta->add( \md5('aaa'), array('tag_a', 'tag_b') );
	}
	
	/**
	 * test
	 */
	public function test_add() {
		
		$this->meta->add( \md5('bbb'), array('tag_a', 'tag_add') );
		
		$result = $this->meta->exists_tag( 'tag_add' );
		
		$this->assertTrue( $result );
	}
	
	/**
	 * test
	 */
	public function test_exists_tag() {
		
		###
		$result = $this->meta->exists_tag( 'tag_a' );
		
		$this->assertTrue( $result );
		
		###
		$result = $this->meta->exists_tag( 'tag_zzz' );
		
		$this->assertFalse( $result );
	}
	
	/**
	 * test
	 */
	public function test_get_by_tags() {
		
		###
		$result = $this->meta->get_by_tags( array('tag_a') );
		
		$this->assertTrue( \sizeof($result) > 1 );
		
		$this->assertEquals( \md5('aaa'), $result[0] );
		
		###
		$result = $this->meta->get_by_tags( array('tag_zzz') );
		
		$this->assertTrue( \sizeof($result) == 0 );
	}
	
	/**
	 * test
	 */
	public function test_nuke() {
		
		$this->meta->add( \md5('ccc'), array('tag_y', 'tag_v') );
		
		$this->meta->nuke( \md5('ccc') );
		
		$result = $this->meta->exists_tag( 'tag_y' );
		
		$this->assertFalse( $result );
		
	}
}
