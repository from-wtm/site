<?php
namespace pulsecore\test\cache;

/**
 * unit tests for cache
 */
class PoolTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * pool instance
	 */
	protected $pool = false;
	
	/**
	 * setup
	 */
	protected function setUp () {
		
		$this->pool = new \pulsecore\cache\Pool( \pulsecore\cache\Manager::HOUR_1 );
		
		$this->pool->set( 'aaa', 'mouse', array('tag_a', 'tab_b') );
	}
	
	/**
	 * test
	 */
	public function test_clear() {
		
		$this->assertFileExists( \pulsecore\get_configs()->dir_storage . '/cache/' . \strval(\pulsecore\cache\Manager::HOUR_1) . '/' . \md5('aaa') );
		
		$this->pool->clear();
		
		$this->assertFileExists( \pulsecore\get_configs()->dir_storage . '/cache/' . \strval(\pulsecore\cache\Manager::HOUR_1) . '/' . \md5('aaa') );
		
	}
	
	/**
	 * test
	 */
	public function test_exists() {
		
		###
		$result = $this->pool->exists( 'aaa' );
		
		$this->assertTrue( $result );
		
		###
		$result = $this->pool->exists( 'zzz' );
		
		$this->assertFalse( $result );
	}
	
	/**
	 * test
	 */
	public function test_get() {
		
		###
		$result = $this->pool->get( 'aaa' );
		
		$this->assertEquals( 'mouse', $result );
		
		###
		$result = $this->pool->get( 'zzz' );
		
		$this->assertEquals( false, $result );
		
	}
	
	/**
	 * test
	 */
	public function test_is_valid() {
		
		###
		$result = $this->pool->is_valid( 'aaa' );
		
		$this->assertTrue( $result );
		
		###
		$result = $this->pool->is_valid( 'zzz' );
		
		$this->assertFalse( $result );
	}
	
	/**
	 * test
	 */
	public function test_nuke() {
		
		$this->pool->set( 'qqq', 'ocelot', array('tag_k', 'tab_n') );
		
		$this->assertFileExists( \pulsecore\get_configs()->dir_storage . '/cache/' . \strval(\pulsecore\cache\Manager::HOUR_1) . '/' . \md5('qqq') );
		
		$this->pool->nuke( 'qqq' );
		
		$this->assertFileNotExists( \pulsecore\get_configs()->dir_storage . '/cache/' . \strval(\pulsecore\cache\Manager::HOUR_1) . '/' . \md5('qqq') );
	}
	
	/**
	 * test
	 */
	public function test_nuke_hash() {
		
		$this->pool->set( 'qqq', 'ocelot', array('tag_k', 'tab_n') );
		
		$this->assertFileExists( \pulsecore\get_configs()->dir_storage . '/cache/' . \strval(\pulsecore\cache\Manager::HOUR_1) . '/' . \md5('qqq') );
		
		$this->pool->nuke_hash( \md5('qqq') );
		
		$this->assertFileNotExists( \pulsecore\get_configs()->dir_storage . '/cache/' . \strval(\pulsecore\cache\Manager::HOUR_1) . '/' . \md5('qqq') );
	}
	
	/**
	 * test
	 */
	public function test_nuke_tags() {
		
		$this->pool->set( 'qqq', 'ocelot', array('tag_k', 'tab_n') );
		
		$this->assertFileExists( \pulsecore\get_configs()->dir_storage . '/cache/' . \strval(\pulsecore\cache\Manager::HOUR_1) . '/' . \md5('qqq') );
		
		$this->pool->nuke_tags( array('tag_k', 'tab_n') );
		
		$this->assertFileNotExists( \pulsecore\get_configs()->dir_storage . '/cache/' . \strval(\pulsecore\cache\Manager::HOUR_1) . '/' . \md5('qqq') );
	}
	
	/**
	 * test
	 */
	public function test_set() {
		
		$this->assertFileExists( \pulsecore\get_configs()->dir_storage . '/cache/' . \strval(\pulsecore\cache\Manager::HOUR_1) . '/' . \md5('aaa') );
	}
}
