<?php
namespace pulsecore\test\cache;

/**
 * unit tests for cache
 */
class ManagerTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * manager instance
	 */
	protected $cache_manager = false;
	
	/**
	 * setup
	 */
	protected function setUp () {
		
		$this->cache_manager = new \pulsecore\cache\Manager();
	}
	
	/**
	 * test
	 */
	public function test_pool_day() {
		
		$pool = $this->cache_manager->pool( \pulsecore\cache\Manager::HOUR_1 );
		
		$this->assertTrue( $pool instanceof \pulsecore\cache\Pool );
	}
}
