<?php
namespace pulsecore\test;

require_once ('D:\Applications\php\phpunit\tools\dbunit-4.0.0.phar');

define( 'PULSE_BASE_DIR',  (__DIR__ . '/../../..') );
#define( 'PULSE_ADMIN_DIR', (PULSE_BASE_DIR . '/admin') );

const TEST_DIR = __DIR__ . '/_files';

# super globals
if (!isset($_SERVER['SERVER_NAME'])) {
	$_SERVER['HTTP_HOST'] = 'test.runner';
	
	$_SERVER['SERVER_NAME'] = 'test.runner';
	
	$_SERVER['REQUEST_URI'] = 'http://localhost/';
	$_SERVER['SERVER_PORT'] = '80';
}

require_once (PULSE_BASE_DIR . '/pulsecore/bootstrap.php' );

/**
 * wedge in the updated configs from pulsecore
 */
require_once (PULSE_BASE_DIR . '/pulsecore/wedge/config.php');

\pulsecore\wedge\config\wedge_config();

# bootstrap i18n
\pulsecore\set_i18n(
	\pulsecore\wedge\config\get_json_configs()->json->date_default_timezone_set,
	\pulsecore\wedge\config\get_json_configs()->json->language
);

# translations
require_once (PULSE_ADMIN_DIR . '/inc/lang/english.php' );

# test case
require_once (__DIR__ . '/test_case.php' );
