<?php
namespace pulsecore\test\tags;

/**
 * unit tests for tags
 */
class EmailListTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		# $this->iii = new \pulsecore\tags\EmailList();
	}
	
	/**
	 * test
	 */
	public function test_execute_tag() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_generate_html() {
		
		# global vars
		$GLOBALS['page'] = 'test';
		$GLOBALS['path'] = '';
		
		\ob_start();
		require_once (PULSE_BASE_DIR . '/pulsecore/tags/email-list.php');
		$html = \ob_get_contents();
		\ob_end_clean();
		
		$this->assertTrue( \is_string($html) );
		
		# mask some of the more usual html errors
		\libxml_use_internal_errors(true);
		
		# check html
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $html );
		
		# valid HTML
		$this->assertTrue( $status );
	}
}
