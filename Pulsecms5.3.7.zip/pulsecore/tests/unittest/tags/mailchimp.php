<?php
namespace pulsecore\test\tags;

/**
 * unit tests for tags
 */
class MailChimpTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		# $this->iii = new \pulsecore\tags\MailChimp();
	}
	
	/**
	 * test
	 */
	public function test_execute_tag() {
		
		# global vars
		$GLOBALS['tag_var1'] = 'ooooooo';
		$GLOBALS['tag_var2'] = 'ppppppp';
		
		\ob_start();
		include (PULSE_BASE_DIR . '/pulsecore/tags/mailchimp.php');
		$html = \ob_get_contents();
		\ob_end_clean();
		
		$this->assertTrue( \is_string($html) );
		
		# mask some of the more usual html errors
		\libxml_use_internal_errors(true);
		
		# check html
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $html );
		
		# valid HTML
		$this->assertTrue( $status );
	}
}
