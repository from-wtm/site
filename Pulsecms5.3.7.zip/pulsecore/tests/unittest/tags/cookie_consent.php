<?php
namespace pulsecore\test\tags;

/**
 * unit tests for tags
 */
class CookieConsentTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\tags\CookieConsent();
	}
	
	/**
	 * test
	 */
	public function test_execute_tag() {
		
		# global vars
		$GLOBALS['page'] = 'test';
		$GLOBALS['path'] = '';
		
		# context
		$tag_runner_context = array();
		
		# tag vars
		$tag_vars = array(
			'pbackground' => '#000',
			'bbackground' => '#f1d600',
			'theme'       => 'edgeless',
			'position'    => 'bottom',
			'href'        => '//www.google.com'
		);
		
		# process
		$html = $this->iii->generate_html( $tag_vars, $tag_runner_context );
		
		$this->assertTrue( \is_string($html) );
		
		/* # NO HTML only loading css/js
		# mask some of the more usual html errors
		\libxml_use_internal_errors(true);
		
		# check html
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $html );
		
		# valid HTML
		$this->assertTrue( $status );
		*/
		
		# css
		$css_list = \pulsecore\get_context()->theme->css->index_on_name();
		
		$this->assertTrue( isset($css_list['cookie_consent']) );
		
		# js
		$js_list = \pulsecore\get_context()->theme->js_body->index_on_name();
		
		$this->assertTrue(  isset($js_list['cookie_consent'])     );
		$this->assertTrue(  isset($js_list['cookie_consent_tag']) );
	}
	
	/**
	 * test
	 */
	public function test_generate_html() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
