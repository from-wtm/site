<?php
namespace pulsecore\test\tags;

require_once (PULSE_BASE_DIR . '/pulsecore/tags/end_point.php');

/**
 * unit tests for tags
 */
class EndPointTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		# $this->iii = new \pulsecore\tags\EndPoint();
	}
	
	/**
	 * test
	 */
	public function test_execute_tag() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_generate_html() {
		
		# global vars
		$GLOBALS['page'] = 'test';
		$GLOBALS['path'] = '';
		
		# context
		$tag_runner_context = array();
		
		# tag vars
		$tag_vars = array( 'probe' => 'blog' );
		
		# process
		$html = \pulsecore\tags\end_point\generate_html( '/base', 'http://test.localhost/test' );
		
		$this->assertTrue( \is_string($html) );
		
		# mask some of the more usual html errors
		\libxml_use_internal_errors(true);
		
		# check html
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $html );
		
		# valid HTML
		$this->assertTrue( $status );
	}
}
