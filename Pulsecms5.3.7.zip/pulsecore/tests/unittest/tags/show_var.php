<?php
namespace pulsecore\test\tags;

/**
 * unit tests for tags
 */
class ShowVarTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\tags\ShowVar();
	}
	
	/**
	 * test
	 */
	public function test_execute_tag() {
		
		# global vars
		$GLOBALS['page'] = 'test';
		$GLOBALS['path'] = '/reebo';
		
		# context
		$tag_runner_context = array();
		
		# tag vars
		$tag_vars = array( 'var_name' => 'path' );
		
		# process
		$html = $this->iii->execute_tag( $tag_vars, $tag_runner_context );
		
		$this->assertEquals( '/reebo', $html );
	}
	
	/**
	 * test
	 */
	public function test_generate_html() {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
