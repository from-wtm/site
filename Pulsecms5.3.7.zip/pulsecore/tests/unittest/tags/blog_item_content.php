<?php
namespace pulsecore\test\tags;

/**
 * unit tests for tags
 */
class BlogItemContentTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\tags\BlogItemContent();
	}
	
	/**
	 * test
	 */
	public function test_execute_tag() {
		
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_generate_html() {
		
		# global vars
		$GLOBALS['page'] = 'test';
		$GLOBALS['path'] = '';
		
		# context
		$tag_runner_context = array();
		
		# tag vars
		$blog_item = new \pulsecore\store\blog\Item();
		$blog_item->load( PULSE_BASE_DIR . '/content/blog/1.txt' );
		
		$tag_vars = array(
			'blog_item' => $blog_item
		);
		
		# process
		$html = $this->iii->generate_html( $tag_vars, $tag_runner_context );
		
		$this->assertTrue( \is_string($html) );
		
		# mask some of the more usual html errors
		\libxml_use_internal_errors(true);
		
		# check html
		$doc = new \DOMDocument();
		$status = $doc->loadHtml( $html );
		
		# valid HTML
		$this->assertTrue( $status );
	}
}
