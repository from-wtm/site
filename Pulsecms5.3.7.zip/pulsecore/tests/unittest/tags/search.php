<?php
namespace pulsecore\test\tags;

/**
 * unit tests for tags
 */
class SearchTest extends \PHPUnit\Framework\TestCase {
	
	/**
	 * instance
	 */
	protected $iii = false;
	
	/**
	 * initialise for test
	 */
	protected function setUp () {
		
		$this->iii = new \pulsecore\tags\Search();
	}
	
	/**
	 * test
	 */
	public function test_execute_tag() {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
	
	/**
	 * test
	 */
	public function test_generate_html() {
		$this->markTestIncomplete( 'Not implemented (yet)' );
	}
}
