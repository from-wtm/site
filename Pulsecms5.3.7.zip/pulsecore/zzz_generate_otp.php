<?php

/**
 * generate an OTP password
 */
 
require_once (PULSE_BASE_DIR . '/pulsecore/bootstrap.php');

# load configs
require_once (PULSE_BASE_DIR . '/pulsecore/wedge/config.php');
\pulsecore\wedge\config\wedge_config();

#var_dump( \pulsecore\get_configs()->otp->label ); exit;

$otp = \pulsecore\otp_get(\pulsecore\get_configs()->acl_role->admin);

echo ("OTP is: " . $otp->now());

echo "<br />", "editor", "<br />";
$otp = \pulsecore\otp_get(\pulsecore\get_configs()->acl_role->editor);

echo ("OTP is: " . $otp->now());

