<?php
namespace pulsecore;

/**
 * basic dessign-by-contract stuff - invariant
 * @param bool $test
 * @param string $message
 * @throw LogicException
 */
function invariant (bool $test, string $message = 'An invariant has failed') {
	
	if (false === $test) {
		
		$eee = new \LogicException($message);
		
		throw $eee;
	}
}

/**
 * log an exception
 * @param \Exception $eee The exception
 * @return void
 */
function log_exception (\Exception $eee) {
	
	\error_log( "exception raised: " . $eee->getMessage() );
	\error_log( $eee->getTraceAsString() );
}

/**
 * basic dessign-by-contract stuff - post condition
 * @param bool $test
 * @param string $message
 * @throw LogicException
 */
function post_condition (bool $test, string $message = 'A post-condition has failed') {
	
	invariant( $test, $message );
}

/**
 * basic dessign-by-contract stuff - pre condition
 * @param bool $test
 * @param string $message
 * @throw LogicException
 */
function pre_condition (bool $test, string $message = 'A pre-condition has failed') {
	
	invariant( $test, $message );
}
