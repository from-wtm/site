<?php
namespace pulsecore\page\admin;

/**
 * manage admin REST interface
 */
class Rest extends Base {
	
	/**
	 * delete request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_delete( array $request_params, array $request_cookie ) {
		
		\header('Content-type: application/json');
		echo \json_encode( array('msg' => 'method not supported') );
		exit;
	}
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		\pulsecore\pre_condition(         isset($request_params['id']) );
		\pulsecore\pre_condition(    \is_string($request_params['id']) );
		\pulsecore\pre_condition( \strlen(\trim($request_params['id'])) > 0 );
		
		\pulsecore\pre_condition(         isset($request_params['type']) );
		\pulsecore\pre_condition(    \is_string($request_params['type']) );
		\pulsecore\pre_condition( \strlen(\trim($request_params['type'])) > 0 );
		
		# extract
		$id   = $request_params['id'];
		$type = $request_params['type'];
		
		# filter
		$id   = \pulsecore\filter\item_url(      $id );
		$type = \pulsecore\filter\variable_name( $type );
		
		$result =  array('msg' => 'type or id not supported for GET');
		
		switch ($type) {
			
			case 'block':
				$result = new \pulsecore\store\block\Item();
				$result->load( \pulsecore\get_configs()->dir_content . "/blocks/{$id}.txt" );
				break;
			
			case 'blog':
				$result = new \pulsecore\store\blog\Item();
				$result->load( \pulsecore\get_configs()->dir_content . "/blog/{$id}.txt" );
				break;
			
			case 'page':
				$result = new \pulsecore\store\page\Item();
				$result->load( \pulsecore\get_configs()->dir_content . "/pages/{$id}.txt" );
				break;
		}
		
		# replace {{show_var:"path"}} with the actual path
		$config_path = \pulsecore\wedge\config\get_json_configs()->json->path;
		
		$result->html = \str_replace( 'src="{{show_var:"path"}}', "src=\"{$config_path}", $result->html );
		
		# tx
		\header('Content-type: application/json');
		echo \json_encode( $result );
		exit;
	}
	
	/**
	 * post request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		\pulsecore\pre_condition(         isset($request_params['id']) );
		\pulsecore\pre_condition(    \is_string($request_params['id']) );
		\pulsecore\pre_condition( \strlen(\trim($request_params['id'])) > 0 );
		
		\pulsecore\pre_condition(         isset($request_params['type']) );
		\pulsecore\pre_condition(    \is_string($request_params['type']) );
		\pulsecore\pre_condition( \strlen(\trim($request_params['type'])) > 0 );
		
		# extract
		$id   = $request_params['id'];
		$type = $request_params['type'];
		
		# filter
		$id   = \pulsecore\filter\item_url(      $id );
		$type = \pulsecore\filter\variable_name( $type );
		
		$result =  array('msg' => 'type or id not supported for POST');
		
		# cleanup path and convert to {{show_var:"path"}}
		$config_path = \pulsecore\wedge\config\get_json_configs()->json->path;
		
		foreach ($request_params as $key => $value) {
			if (\in_array($key, array('html', 'title'))) {
				$request_params[ $key ] = \str_replace( "src=\"{$config_path}", 'src="{{show_var:"path"}}', $value );
			}
		}
		
		# process
		switch ($type) {
			
			case 'block':
				$result = new \pulsecore\store\block\Item();
				$result->load( \pulsecore\get_configs()->dir_content . "/blocks/{$id}.txt" );
				
				foreach ($request_params as $key => $value) {
					if (\in_array($key, array('html', 'title'))) {
						$result->{$key} = $value;
					}
				}
				
				$result->save( \pulsecore\get_configs()->dir_content . "/blocks/{$id}.txt" );
				break;
			
			case 'blog':
				$result = new \pulsecore\store\blog\Item();
				$result->load( \pulsecore\get_configs()->dir_content . "/blog/{$id}.txt" );
				
				foreach ($request_params as $key => $value) {
					if (\in_array($key, array('author', 'date', 'description', 'html', 'tags', 'title'))) {
						$result->{$key} = $value;
					}
				}
				
				$result->save( \pulsecore\get_configs()->dir_content . "/blog/{$id}.txt" );
				break;
			
			case 'page':
				$result = new \pulsecore\store\page\Item();
				$result->load( \pulsecore\get_configs()->dir_content . "/pages/{$id}.txt" );
				
				foreach ($request_params as $key => $value) {
					if (\in_array($key, array('description', 'html', 'title'))) {
						$result->{$key} = $value;
					}
				}
				
				$result->save( \pulsecore\get_configs()->dir_content . "/pages/{$id}.txt" );
				break;
		}
		
		\header('Content-type: application/json');
		echo \json_encode( array('msg' => 'OK') );
		exit;
	}
	
	/**
	 * put request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_put( array $request_params, array $request_cookie ) {
		
		\header('Content-type: application/json');
		echo \json_encode( array('msg' => 'method not supported') );
		exit;
	}
}
