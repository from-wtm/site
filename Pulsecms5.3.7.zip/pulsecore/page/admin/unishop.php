<?php
namespace pulsecore\page\admin;

/**
 * unishop management
 */
class Unishop extends Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get (array $request_params, array $request_cookie) {
		
		# render model
		$view_model = new \pulsecore\ViewModel();
		
		$tags = new \stdClass();
		
		# load stored version - if present
		if (isset(\pulsecore\wedge\config\get_json_configs()->json->tags)) {
			$tags = \pulsecore\wedge\config\get_json_configs()->json->tags;
		}
		
		$view_model->tags = $tags;
		
		# breadcrumbs
		$GLOBALS['breadcrumb_custom_settings'] = (object)array(
			'entries' => array()
		);
		$GLOBALS['breadcrumb_custom_settings']->entries['Unishop'] = PULSE_ADMIN_URL . "/index.php?p=unishop&method=get";
		
		# render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/unishop.phtml' );
		
		\pulsecore\get_context()->theme->css->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/css/page.css', array(), 'unishop_xml_editor' );
		
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/vendor/node_modules/vue/dist/vue.js', array(), 'vue' );
		
		$inline_js =<<<EOD
window.pulse_xml_editor_app = {
	vm: false,
	mixins: [],
	event_bus: (new Vue({}))
};
EOD;
		\pulsecore\get_context()->theme->js_body->add_inline( 'unishop_editor_inline', $inline_js,  array('vue') );
		
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/mixin/hide_editor.js', array('unishop_editor_inline') );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/mixin/misc.js',        array('unishop_editor_inline') );
		
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/component/cell.js',                        array('unishop_editor_inline') );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/component/create_row.js',                  array('unishop_editor_inline') );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/component/delete_row.js',                  array('unishop_editor_inline') );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/component/options_option_add.js',          array('unishop_editor_inline') );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/component/options_option_entry.js',        array('unishop_editor_inline') );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/component/options_option_entry_add.js',    array('unishop_editor_inline') );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/component/options_option_entry_delete.js', array('unishop_editor_inline') );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/component/options_option.js',              array('unishop_editor_inline') );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/component/options.js',                     array('unishop_editor_inline') );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/component/quantity.js',                    array('unishop_editor_inline') );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/src/component/xml_editor.js',                  array('unishop_editor_inline') );
		
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/inc/plugins/unishop_editor/js/page.js', array('unishop_editor_inline'));
		
		$view->render( $view_model );
	}
}
