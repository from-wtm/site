<?php
namespace pulsecore\page\admin;

/**
 * deleting items
 */
class Delete extends Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		# inputs
		$view_model->param_d   = isset($request_params['d']) ? $request_params['d'] : '';
		$view_model->param_ext = isset($request_params['e']) ? $request_params['e'] : '';
		
		# filter
		$view_model->param_d   = \pulsecore\filter\item_url(       $view_model->param_d );
		$view_model->param_ext = \pulsecore\filter\file_extension( $view_model->param_ext );
		
		# fix extension
		if (!empty($view_model->param_ext)) {
			$view_model->param_ext = '.' . $view_model->param_ext;
		}
		
		$view_model->savepath = \pulsecore\get_configs()->dir_content . '/' . $view_model->param_d . $view_model->param_ext;
		$view_model->item     = $view_model->param_d;
		$view_model->back     = \explode('/', $view_model->item);
		$view_model->back     = \array_slice( $view_model->back, 0, -1);
		$view_model->go_back  = \implode('/', $view_model->back);
		
		# no item/folder to delete
		if (    empty($view_model->param_d) 
				or !isset($view_model->param_d)
				or !\file_exists($view_model->savepath)) {
		
			\header("Location: index.php?p=home");
			exit;
		}
		
		if (!empty($view_model->savepath) and \file_exists($view_model->savepath)) {
			
			if (empty($_SESSION["token"])) {
				$_SESSION["token"] = \md5(\uniqid(\rand(), true));
			}
			
			$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/delete.phtml' );
			$view->render( $view_model );
		}
	}
	
	/**
	 * post request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		# inputs
		$view_model->param_ext      = isset($request_params['ext'])     ? $request_params['ext']     : ''; # NB param includes leading dot
		$view_model->param_go_back  = isset($request_params['go_back']) ? $request_params['go_back'] : '';
		$view_model->param_item     = isset($request_params['item'])    ? $request_params['item']    : '';
		$view_model->param_token    = isset($request_params['token'])   ? $request_params['token']   : '';
		
		# filter
		$view_model->param_ext     = \pulsecore\filter\file_extension( $view_model->param_ext );
		$view_model->param_item    = \pulsecore\filter\item_url(       $view_model->param_item );
		$view_model->param_go_back = \pulsecore\filter\item_url(       $view_model->param_go_back );
		$view_model->param_token   = \pulsecore\filter\hex(            $view_model->param_token );
		
		if (    !(empty($view_model->param_go_back))
				and !(empty($view_model->param_item))
				and isset($_SESSION['token']) and !(empty($view_model->param_token))
				and ($_SESSION['token'] == $view_model->param_token)) {
			
			$view_model->param_savepath = \pulsecore\get_configs()->dir_content . '/' . $view_model->param_item . $view_model->param_ext;
			
			# status message
			\pulsecore\session\status_add( $GLOBALS['lang_status_ok'] );
			
			# process
			if (\file_exists($view_model->param_savepath) and !\is_dir($view_model->param_savepath)) {
				
				# remove thumbnail
				$thumbnail_image_file = \pulsecore\image\thumbnail_path(
					(\pulsecore\get_configs()->dir_content . 'media/thumbnails/' . \basename($view_model->param_savepath)),
					$view_model->param_savepath
				);
				
				if (\file_exists($thumbnail_image_file)) {
					\unlink($thumbnail_image_file);
				}
				
				\unlink($view_model->param_savepath);
				
				# re-generate gallery for media files
				if (\stripos($view_model->param_savepath, 'content/media/') !== false) {
					
					$gallery_file = \dirname($view_model->param_savepath) . '/gallery.txt';
					
					$datum_gallery = new \pulsecore\store\gallery\Item();
					$datum_gallery->load( $gallery_file );
					$datum_gallery->import(); # make sure all images are included
					$datum_gallery->order_by( 'date' );
					
					$datum_gallery->save( $gallery_file );
				}
				
				# update user group access permissions
				$this->handle_user_group_changes( $view_model->param_savepath );
				
			} else if (file_exists($view_model->param_savepath) and \is_dir($view_model->param_savepath)) {
				# Directory
				\pulsecore\dir_nuke($view_model->param_savepath);
			}
			
			# bounce out
			#\header("Location: index.php?p=home&f=" . $view_model->param_go_back );
			\header("Location: index.php?f=" . $view_model->param_go_back );
			exit;
		}
	}
	
	/**
	 * update the user group file access permissions as needed
	 * \param $filename string
	 * \return void
	 */
	protected function handle_user_group_changes ($filename) {
		
		# clean the paths up
		$clean_filename = \str_replace( \pulsecore\get_configs()->dir_content, '', $filename );
		
		$clean_filename = \ltrim( $clean_filename, '/' );
		
		$clean_filename = \str_replace( '.txt', '', $clean_filename );
		
		# transfer permissions
		$user_group_list = \pulsecore\wedge\config\get_json_configs()->json->user_group_list;
		
		foreach ($user_group_list as $key => $value) {
			
			$detected_types = $user_group_list->{$key}->permissions;
			
			foreach ($detected_types as $type => $dummy) {
				
				if (isset($user_group_list->{$key}->permissions->{$type}->{$clean_filename})) {
					unset( $user_group_list->{$key}->permissions->{$type}->{$clean_filename} );
				}
			}
		}
		
		\pulsecore\wedge\config\get_json_configs()->json->user_group_list = $user_group_list;
		\pulsecore\wedge\config\save_config( \pulsecore\wedge\config\get_json_configs()->json );
	}
}
