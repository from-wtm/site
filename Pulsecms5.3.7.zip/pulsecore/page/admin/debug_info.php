<?php
namespace pulsecore\page\admin;

/**
 * generate debug info
 */
class DebugInfo extends Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		# file permissions
		$dirs = array(
			'root directory' => (PULSE_BASE_DIR),
			
			'content'        => (\pulsecore\get_configs()->dir_content),
			'content/blocks' => (\pulsecore\get_configs()->dir_content . '/blocks'),
			'content/blog'   => (\pulsecore\get_configs()->dir_content . '/blog'),
			'content/media'  => (\pulsecore\get_configs()->dir_content . '/media'),
			'content/pages'  => (\pulsecore\get_configs()->dir_content . '/pages'),
			
			'pulsecore/storage'       => (\pulsecore\get_configs()->dir_storage),
			'pulsecore/storage/cache' => (\pulsecore\get_configs()->dir_storage . '/cache'),
			'pulsecore/storage/log'   => (\pulsecore\get_configs()->dir_storage . '/log'),
			
			'pulsecore/storage/config.json' => (\pulsecore\get_configs()->dir_storage . '/config.json'),
						
			'config.php' => (PULSE_BASE_DIR . '/config.php'),
			'.htaccess'  => (PULSE_BASE_DIR . '/.htaccess')
		);
		
		\clearstatcache();
		
		foreach ($dirs as $key => $value) {
			$tmp = \fileperms($value);
			$tmp = \sprintf('%o', $tmp);
			$tmp = \substr( $tmp, -4);
			
			$dirs[$key] = $tmp;
		}
		
		$view_model->dirs = $dirs;
		
		# render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/debug_info.phtml' );
		$view->render( $view_model );
	}
	
	/**
	 * post request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		# file permissions
		$dirs = array(
			'root directory' => (PULSE_BASE_DIR),
			
			'content'        => (\pulsecore\get_configs()->dir_content),
			'content/blocks' => (\pulsecore\get_configs()->dir_content . '/blocks'),
			'content/blog'   => (\pulsecore\get_configs()->dir_content . '/blog'),
			'content/media'  => (\pulsecore\get_configs()->dir_content . '/media'),
			'content/pages'  => (\pulsecore\get_configs()->dir_content . '/pages'),
			
			'pulsecore/storage'       => (\pulsecore\get_configs()->dir_storage),
			'pulsecore/storage/cache' => (\pulsecore\get_configs()->dir_storage . '/cache'),
			'pulsecore/storage/log'   => (\pulsecore\get_configs()->dir_storage . '/log'),
			
			'pulsecore/storage/config.json' => (\pulsecore\get_configs()->dir_storage . '/config.json'),
						
			'config.php' => (PULSE_BASE_DIR . '/config.php'),
			'.htaccess'  => (PULSE_BASE_DIR . '/.htaccess')
		);
		
		\clearstatcache();
		
		foreach ($dirs as $key => $value) {
			$tmp = \fileperms($value);
			$tmp = \sprintf('%o', $tmp);
			$tmp = \substr( $tmp, -4);
			
			$dirs[$key] = $tmp;
		}
		
		$view_model->dirs = $dirs;
		
		# build the zip
		$tmp_file = \tempnam( \sys_get_temp_dir(), 'dbg');
		$zip = new \ZipArchive();
		$zip->open( $tmp_file );
		
		$zip->addFromString( 'permissions.json', \json_encode($view_model->dirs) );
		
		$zip->addFile( (PULSE_BASE_DIR . '/config.php'), 'config.php' );
		$zip->addFile( (PULSE_BASE_DIR . '/.htaccess'),  '.htaccess'  );
		
		$zip->addFile( (\pulsecore\get_configs()->dir_storage . '/config.json'), 'config.json' );
		
		$phpinfo = '';
		\ob_start();
		\phpinfo();
		$phpinfo = \ob_get_contents();
		\ob_end_clean();
		
		$zip->addFromString( 'phpinfo.html', $phpinfo );
		
		$log_files = \glob(\pulsecore\get_configs()->dir_storage . '/log/error_log*' );
		
		foreach ($log_files as $value) {
			$zip->addFile( $value, ('log/' . \basename($value)) );
		}
		
		$zip->close();
		
		# stream zip
		\header('Content-Type: application/zip');
		\header('Content-Length: ' . \filesize($tmp_file));
		\header('Content-Disposition: attachment; filename="debug_info.zip"');
		\readfile($tmp_file);
		\unlink($tmp_file); 
		exit;
	}
}
