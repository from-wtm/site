<?php
namespace pulsecore\page\admin;

# random string for security token. Token is used to validate calls and changes for EACH one
\define( 'PULSE_RANDOM', 'GUZSjMU8qzcPsDZ12XvisNVgmWCO4jEsYcHqOWuu' );

# where the xml file is
\define( 'PULSE_SHOP_FILENAME', (PULSE_BASE_DIR . '/inc/plugins/unishop/shop.xml') );

/**
 * unishop management for the I/O
 */
class UnishopEditor extends Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get (array $request_params, array $request_cookie) {
		
		$mtime = $this->last_changed();
		
		$result = (object)array(
			'status'  => 'OK',
			'now'     => $mtime,
			'content' => \file_get_contents( PULSE_SHOP_FILENAME ),
			
			'token'   => $this->token( $mtime )
		);
		
		$result = \json_encode( $result );
		
		\header('Content-type: application/json');
		echo $result;
		exit;
	}
	
	/**
	 * post request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_post (array $request_params, array $request_cookie) {
		
		$param_content = isset($request_params['content']) ? $request_params['content'] : '';
		$param_token   = isset($request_params['token'])   ? $request_params['token']   : '';
		
		$param_content = \trim( $param_content );
		$param_token   = \trim( $param_token );
		
		if (\strlen($param_content) > 0) {
			
			# verify the token
			$mtime = $this->last_changed();
			
			$next_token = $this->token($mtime);
			
			if ($next_token == $param_token) {
				
				$now = \date('YmdHis');
				
				# backup
				\copy(
					PULSE_SHOP_FILENAME,
					( \pulsecore\get_configs()->dir_storage . "/shop_{$now}.xml")
				);
				
				# save
				\file_put_contents( PULSE_SHOP_FILENAME, $request_params['content']);
			}
		}
		
		# make sure this settles first
		\sleep( 1 );
		
		return $this->handle_get($request_params, $request_cookie);
	}
	
	/**
	 * last time the shop.xml file changed
	 * @return string
	 */
	protected function last_changed () {
		
		$last_changed = \filemtime( PULSE_SHOP_FILENAME );
		$last_changed = \date('Y-m-d H:i:s', $last_changed);
		
		return $last_changed;
	}
	
	/**
	 * generate the token
	 * @param string $mtime
	 * @return string
	 */
	protected function token (string $mtime) {
		
		$result = \sha1( ($mtime . PULSE_RANDOM) );
		
		return $result;
	}
}
