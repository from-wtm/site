<?php
namespace pulsecore\page\admin;

/**
 * re-order a gallery
 */
class GalleryOrder extends Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		if (!empty($request_params['gallery'])) {
			
			$gallery = $request_params['gallery'];
			
			$gallery = \str_replace('media/', '', $gallery);
			$gallery = \str_replace('media',  '', $gallery);
			$gallery = \rtrim( $gallery, '/' );
			$gallery = \ltrim( $gallery, '/' );
			
			$gallery_file = \pulsecore\get_configs()->dir_content . "/media/{$gallery}/gallery.txt";
			
			$datum_gallery = new \pulsecore\store\gallery\Item();
			$datum_gallery->load( $gallery_file );
			$datum_gallery->import(); # make sure all images are included
			$datum_gallery->order_by( 'date' );
			
			$datum_gallery->save( $gallery_file );
			
			# redirect
			\header( "Location: index.php?f=media" . ((\strlen($gallery) > 0) ? '/' : '') . $gallery );
			exit;
		}
	}
}
