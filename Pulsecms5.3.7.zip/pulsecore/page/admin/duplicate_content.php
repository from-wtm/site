<?php
namespace pulsecore\page\admin;

/**
 * duplicate content page
 */
class DuplicateContent extends Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		\pulsecore\pre_condition(         isset($request_params['item_file']) );
		\pulsecore\pre_condition(    \is_string($request_params['item_file']) );
		\pulsecore\pre_condition( \strlen(\trim($request_params['item_file'])) > 0 );
		
		# extract
		$item_file = $request_params['item_file'];
		
		$item_type = \explode('/', $item_file);
		
		\pulsecore\invariant(     isset($item_type) );
		\pulsecore\invariant( \is_array($item_type) );
		\pulsecore\invariant(   \sizeof($item_type) > 0 );
		
		$item_type = \trim($item_type[0]);
		
		\pulsecore\invariant(      isset($item_type) );
		\pulsecore\invariant( \is_string($item_type) );
		\pulsecore\invariant(    \strlen($item_type) > 0 );
		
		$now = \date('Y_m_d_H_i_s');
		
		$filename = \pulsecore\get_configs()->dir_content . '/' . $item_file . '.txt';
		
		$new_filename = \pulsecore\get_configs()->dir_content . '/' . $item_file . '_' . $now . '.txt';
		
		switch ($item_type) {
			
			case 'blocks':
				$data = new \pulsecore\store\block\Item();
				$data->load( $filename );
				break;
				
			case 'pages':
				$data = new \pulsecore\store\page\Item();
				$data->load( $filename );
				break;
				
			default:
				\pulsecore\invariant( false );
		}
		
		# copy file
		$status = \copy( $filename, $new_filename );
		
		\pulsecore\invariant( $status === true, 'duplication failed' );
		
		# status message
		\pulsecore\session\status_add( $GLOBALS['lang_status_ok'] );
		
		$result = '<script type="text/javascript">window.location="index.php?p=open&f=' . $item_file . '_' . $now . '&e=txt";</script>';
		
		return $result;
	}
}
