<?php
namespace pulsecore\page\admin;

/**
 * generate stats page for the admin
 */
class ViewStats extends Base {
	
	/**
	 * process the stats files
	 * \return stdClass
	 */
	protected function generate_stats() {
		
		$result = new \stdClass();
		
		$result->data = array();
		
		$result->daily = new \stdClass();
		$result->daily->bounce_rate = 0;
		$result->daily->visitors    = 0;
		$result->daily->page_views  = 0;
		
		$result->daily->ips  = array();
		
		$result->weekly = new \stdClass();
		$result->weekly->visitors = array();
		
		$result->browsers  = array();
		$result->countries = array();
		$result->devices   = array();
		$result->pages     = array();
		$result->referrers = array();
		$result->systems   = array();
		
		$stat_files = \glob( \pulsecore\get_configs()->dir_content . "/stats/*.txt");
		
		$last_week = new \DateTime();
		$last_week->sub( new \DateInterval('P7D') );
		$last_week = $last_week->format( 'Y-m-d' );
		
		foreach ($stat_files as $filename) {
			
			$datum_stat = new \pulsecore\store\stat\Item();
			$datum_stat->load( $filename );
			
			$file = \basename($filename,".txt");
			
			$when = \DateTime::createFromFormat('m.d.y', $file );
			$when = $when->format( 'Y-m-d' );
			
			$result->data[$when] = $datum_stat;
			
			foreach ($datum_stat->lines as $lll) {
				
				# daily
				if ($when == \date('Y-m-d')) {
					
					$result->daily->page_views  += 1; # count all lines
					
					$result->daily->ips[ $lll->ip ] = (isset($result->daily->ips[ $lll->ip ]) ? ($result->daily->ips[ $lll->ip ] + 1) : 1);
				}
				
				# weekly
				if (!isset($result->weekly->ips[ $when ])) {
					$result->weekly->ips[ $when ] = array();
				}
				$result->weekly->ips[ $when ][ $lll->ip ] = (isset($result->weekly->ips[ $when ][ $lll->ip ]) ? ($result->weekly->ips[ $when ][ $lll->ip ] + 1) : 1);
				
				# aggregate
				$result->browsers[  $lll->browser ] = (isset($result->browsers[ $lll->browser ])) ? ($result->browsers[ $lll->browser ] + 1) : 1;
				$result->countries[ $lll->country ] = (isset($result->country[  $lll->country ])) ? ($result->country[  $lll->country ] + 1) : 1;
				$result->devices[   $lll->device  ] = (isset($result->devices[  $lll->device  ])) ? ($result->devices[  $lll->device  ] + 1) : 1;
				$result->systems[   $lll->system  ] = (isset($result->systems[  $lll->system  ])) ? ($result->systems[  $lll->system  ] + 1) : 1;
				
				# pages
				$url = $lll->uri;
				
				if ((\strlen($url) !== 0) and !(\preg_match("/tracker.php/i", $url)) ) {
					
					$url = ((\stripos($url, 'javascript:') === false) ? $url : '#javascript-injection-attempt');
					
					$result->pages[ $url ] = isset($result->pages[ $url ]) ? ($result->pages[ $url ] + 1) : 1;
				}
				
				# referrers
				$url = $lll->referrer;
				
				if (    !(\preg_match("/google/i",    $url))
				    and !(\preg_match("/localhost/i", $url))
				    and !(\preg_match("/yahoo/i",     $url))
				    and !(\preg_match("/bing/i",      $url))
				    and !(\preg_match("/yandex/i",    $url))
				    and !(\preg_match("/yandex/i",    $url))
				    and (\strlen($url) !== 0)
				    and ($url != 'none')
				   ) {
				
					$url = ((\stripos($url, 'javascript:') === false) ? $url : '#');
					
					$url = \htmlspecialchars($url, \ENT_QUOTES, 'UTF-8');
					
					$url = \str_replace("http://",  "", $url);
					$url = \str_replace("https://", "", $url);
					$url = \str_replace("www.",     "", $url);
					
					$result->referrers[ $url ] = isset($result->referrers[ $url ]) ? ($result->referrers[ $url ] + 1) : 1;
				}
			}
			
			# weekly
			foreach ($result->weekly->ips as $day => $ips) {
				$result->weekly->visitors[ $day ] = \array_sum( $ips );
			}
		}
		
		# daily
		$result->daily->visitors = \sizeof( $result->daily->ips);
		
		$less_than_two_clicks = 0;
		foreach ($result->daily->ips as $ip => $counter) {
			$less_than_two_clicks += (($counter < 2) ? 1 : 0);
		}
		
		$result->daily->bounce_rate = (($result->daily->visitors == 0) ? 0 : round((floatval($less_than_two_clicks-1)/floatval($result->daily->visitors)) * 100.0 , 0))  .'%';
		
		# weekly
		
		# sort
		\arsort( $result->browsers );
		\arsort( $result->countries );
		\arsort( $result->devices );
		\arsort( $result->pages );
		\arsort( $result->referrers );
		\arsort( $result->systems );
		
		return $result;
	}
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/js/admin/view-stats.js' );
		
		$view_model = new \pulsecore\ViewModel();
		
		$view_model->stats = $this->generate_stats();
		
		#render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/view-stats.phtml' );
		$view->render( $view_model );
	}
}
