<?php
namespace pulsecore\page\admin;

/**
 * manage navigation bar
 */
class ManageNavigation extends Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		# render model
		$view_model = new \pulsecore\ViewModel();
		
		# build navigation list
		$navigation = \pulsecore\get_configs()->navigation;
		
		# load stored version - if present
		if (isset(\pulsecore\wedge\config\get_json_configs()->json->navigation)) {
			$navigation = \pulsecore\wedge\config\get_json_configs()->json->navigation;
		}
		
		$view_model->navigation = $navigation;
		
		# pages not in the navigation list  ie new pages
		$page_list = \pulsecore\generate_non_navigation_pages( \pulsecore\wedge\config\get_json_configs()->json->path, \pulsecore\wedge\config\get_json_configs()->json->navigation);
		
		# merge the lists NB the all menu
		if (!isset($view_model->navigation->all)) {
			$view_model->navigation->all = new \stdClass();
		}
		
		$view_model->navigation->all = (object)\array_merge(
			$page_list,
			((array)$view_model->navigation->all)
		);
		
		$view_model->navigation_packed = \json_encode($view_model->navigation);
		
		# error trapping
		if (!\is_string($view_model->navigation_packed)) {
			
			$view_model->navigation_packed = '{all: {}}';
			
			\error_log( 'pulsecore/page/admin/manage_navigation.php: Unable to build navigation list START' );
			\error_log( 'JSON error code: ' . \json_last_error() );
			\error_log( 'page list: '  . print_r($page_list, true) );
			\error_log( 'navigation: ' . print_r($navigation, true) );
			\error_log( 'combined: '   . print_r($view_model->navigation, true) );
			\error_log( 'pulsecore/page/admin/manage_navigation.php: Unable to build navigation list END' );
		}
		
		# breadcrumbs
		$GLOBALS['breadcrumb_custom_settings'] = (object)array(
			'entries' => array()
		);
		$GLOBALS['breadcrumb_custom_settings']->entries['Manage Navigation'] = PULSE_ADMIN_URL . '/index.php?p=manage_navigation&method=get';
		
		# render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/manage_navigation_list.phtml' );
		
		# vue
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/vendor/node_modules/vue/dist/vue.js',                   array(),      'vue' );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/vendor/node_modules/sortablejs/Sortable.min.js',        array('vue'), 'sortable' );
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/vendor/node_modules/vuedraggable/dist/vuedraggable.js', array('vue',  'sortable') );
		
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/js/admin/manage_navigation_list.js', array('vue') );
		
		$view->render( $view_model );
	}
	
	/**
	 * put request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_put( array $request_params, array $request_cookie ) {
		
		\pulsecore\pre_condition(     isset($request_params['active']) );
		\pulsecore\pre_condition( \is_array($request_params['active']) );
		\pulsecore\pre_condition(   \sizeof($request_params['active']) > 0);
		
		\pulsecore\pre_condition(     isset($request_params['nav_list']) );
		\pulsecore\pre_condition( \is_array($request_params['nav_list']) );
		\pulsecore\pre_condition(   \sizeof($request_params['nav_list']) > 0);
		
		\pulsecore\pre_condition(     isset($request_params['nuke']) );
		\pulsecore\pre_condition( \is_array($request_params['nuke']) );
		\pulsecore\pre_condition(   \sizeof($request_params['nuke']) > 0);
		
		# CSRF
		$this->csrf_check( $request_params );
		
		# process data if present
		if (\sizeof($request_params['nav_list']) > 0) {
			
			# cleanup
			$navigation = array();
			
			foreach ($request_params['nav_list'] as $menu_key => $menu_value) {
				
				$menu_name = \pulsecore\filter\navigation( $menu_key );
				
				/*
				if (\is_string($menu_value)) {
					
					if (\stripos($menu_value, '//') !== false) {
						$link = \pulsecore\filter\url( $menu_value );
						
					} else {
						$link = \pulsecore\filter\item_url( $menu_value );
						
						$link = \str_replace( \pulsecore\wedge\config\get_json_configs()->json->path, '', $link ); # strip off base path
						
						$link = \ltrim($link, '/');
						$link = '/' . $link;
					}
					
					$active = (($request_params['active'][$menu_key]) and ($request_params['active'][$menu_key] == '1'));
					$nuke   = (($request_params['nuke'  ][$menu_key]) and ($request_params['nuke'  ][$menu_key] == '1'));
					
					if (!$nuke) {
						$navigation[$menu_name] = (object)array( 'url' => $link, 'active' => $active);
					}
				}
				*/
				
				# menus
				if (\is_array($menu_value)) {
					
					$navigation[$menu_name] = array();
					
					foreach( $menu_value as $item_key => $item_value) {
						
						# basic menu item
						if (\is_string($item_value)) {
							
							if (\stripos($item_value, '//') !== false) {
								$link = \pulsecore\filter\url( $item_value );
								
							} else {
								$link = \pulsecore\filter\item_url( $item_value );
								
								$link = \ltrim($link, '/');
								$link = '/' . $link;
							}
							
							$active = (isset($request_params['active'][$menu_key][$item_key]) and ($request_params['active'][$menu_key][$item_key] == '1'));
							$nuke   = (isset($request_params['nuke'  ][$menu_key][$item_key]) and ($request_params['nuke'  ][$menu_key][$item_key] == '1'));
							
							if (!$nuke) {
								$navigation[$menu_name][$item_key] = (object)array( 'url' => $link, 'active' => $active);
							}
						}
						
						# sub menu
						if (\is_array($item_value)) {
								
								foreach ($item_value as $sub_menu_name => $sub_menu_value) {
									
									if (\stripos($sub_menu_value, '//') !== false) {
										$link = \pulsecore\filter\url( $sub_menu_value );
										
									} else {
										$link = \pulsecore\filter\item_url( $sub_menu_value );
										
										$link = \ltrim($link, '/');
										$link = '/' . $link;
									}
									
									$active = (isset($request_params['active'][$menu_key][$item_key][$sub_menu_name]) and ($request_params['active'][$menu_key][$item_key][$sub_menu_name] == '1'));
									$nuke   = (isset($request_params['nuke'  ][$menu_key][$item_key][$sub_menu_name]) and ($request_params['nuke'  ][$menu_key][$item_key][$sub_menu_name] == '1'));
									
									if (!$nuke) {
										$navigation[$menu_name][$item_key][$sub_menu_name] = (object)array( 'url' => $link, 'active' => $active);
									}
								}
						}
					}
					
					# corner case - remove empty sub-menus
					if (\sizeof($navigation[$menu_name]) == 0) {
						unset($navigation[$menu_name]);
					}
				}
			}
			
			# store
			$data = \pulsecore\wedge\config\get_json_configs()->json;
			
			$data->navigation = $navigation;
		
			\pulsecore\wedge\config\save_config( $data );
			
			# status message
			\pulsecore\session\status_add( $GLOBALS['lang_status_ok'] );
			\session_write_close();
			
			# re-render
			$path = PULSE_ADMIN_URL;
			\header("Location: {$path}/index.php?p=settings");
			exit;
		}
	}
}
