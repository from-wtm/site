<?php
namespace pulsecore\page\admin;

require_once (PULSE_BASE_DIR . '/pulsecore/logic/blog_import.php');

class BlogImportFromRss extends Base {
	
	/*
	 * GET request shows the custom post types available
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		$view_model->url = '';
		
		#breadcrumbs
		$GLOBALS['breadcrumb_custom_settings'] = (object)array(
			'entries' => array()
		);
		$GLOBALS['breadcrumb_custom_settings']->entries[ $GLOBALS['lang_nav_blog']    ] = PULSE_ADMIN_URL . "/index.php?f=blog";
		$GLOBALS['breadcrumb_custom_settings']->entries[ $GLOBALS['lang_blog_import'] ] = PULSE_ADMIN_URL . "/index.php?p=blog_import_from_rss&method=get";
		
		#message
		if (isset($request_params['message'])) {
			$view_model->message = \trim($request_params['message']);
		}
		
		#render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/blog_import_from_rss.phtml' );
		$view->render( $view_model );
	}
	 
	/*
	 * POST request adds a new custom post type
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		# CSRF
		$this->csrf_check( $request_params );
		
		$fields = $this->extract_fields( $request_params );
		
		#show the form?
		if (\sizeof($fields) == 0) {
			
			$view_model = new \pulsecore\ViewModel();
			
			#breadcrumbs
			$GLOBALS['breadcrumb_custom_settings'] = (object)array(
				'entries' => array()
			);
			$GLOBALS['breadcrumb_custom_settings']->entries[ $GLOBALS['lang_nav_blog']    ] = PULSE_ADMIN_URL . "/index.php?f=blog";
			$GLOBALS['breadcrumb_custom_settings']->entries[ $GLOBALS['lang_blog_import'] ] = PULSE_ADMIN_URL . "/index.php?p=blog_import_from_rss&method=get";
			
			#render
			$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/blog_import_from_rss.phtml' );
			$view->render( $view_model );
		
		} else {
			
			\pulsecore\pre_condition(      isset($fields['page_max']) );
			\pulsecore\pre_condition( \is_string($fields['page_max']) );
			\pulsecore\pre_condition(    \strlen($fields['page_max']) >= 0);
			
			\pulsecore\pre_condition(      isset($fields['page_var']) );
			\pulsecore\pre_condition( \is_string($fields['page_var']) );
			\pulsecore\pre_condition(    \strlen($fields['page_var']) >= 0);
			
			\pulsecore\pre_condition(      isset($fields['url']) );
			\pulsecore\pre_condition( \is_string($fields['url']) );
			\pulsecore\pre_condition(    \strlen($fields['url']) > 0);
			
			$page_max = $fields['page_max'];
			$page_var = $fields['page_var'];
			$url      = $fields['url'];
			
			$page_max = \trim($page_max);
			$page_var = \trim($page_var);
			$url      = \trim($url);
			
			$status = \pulsecore\logic\blog_import\import( $page_max, $page_var, $url );
			
			# status message
			\pulsecore\session\status_add( $GLOBALS['lang_status_ok'] );
			
			#re-render
			$this->handle_get(
				array('message' => "{$status->counter} blog posts imported successfully"),
				$request_cookie
			);
		}
	}
}
