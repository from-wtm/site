<?php
namespace pulsecore\page\admin;

/**
 * manage user group list
 */
class ManageUserGroupList extends Base {
	
	/**
	 * delete request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_delete (array $request_params, array $request_cookie) {
		
		\pulsecore\pre_condition(      isset($request_params['group_name']) );
		\pulsecore\pre_condition( \is_string($request_params['group_name']) );
		\pulsecore\pre_condition(    \strlen($request_params['group_name']) > 0);
		
		# params
		$param_group_name = \trim($request_params['group_name']);
		
		# CSRF
		$this->csrf_check( $request_params );
		
		$user_group_list = $this->io_load_user_group_list();
		
		# remove group
		if (isset($user_group_list->{$param_group_name})) {
			unset( $user_group_list->{$param_group_name} );
		}
		
		# store
		$this->io_save_user_group_list( $user_group_list );
		
		# re-render
		$path = PULSE_ADMIN_URL;
		\header("Location: {$path}/index.php?p=manage_user_group_list");
		exit;
	}
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get (array $request_params, array $request_cookie) {
		
		# render model
		$view_model = new \pulsecore\ViewModel();
		
		$user_group_list = $this->io_load_user_group_list();
		
		$view_model->user_group_list = $user_group_list;
		
		$view_model->block_list = \pulsecore\store\block\Base::list_blocks_only( \pulsecore\get_configs()->dir_content . '/blocks' );
		$view_model->page_list  = \pulsecore\store\page\Base::list_pages_only(   \pulsecore\get_configs()->dir_content . '/pages' );
		
		# breadcrumbs
		$GLOBALS['breadcrumb_custom_settings'] = (object)array(
			'entries' => array()
		);
		$GLOBALS['breadcrumb_custom_settings']->entries['Manage User Groups'] = PULSE_ADMIN_URL . "/index.php?p=manage_user_group_list&method=get";
		
		# render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/manage_user_group_list.phtml' );
		
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/js/admin/manage_user_group_list.js' );
		
		$view->render( $view_model );
	}
	
	/**
	 * post request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_post (array $request_params, array $request_cookie) {
		
		\pulsecore\pre_condition(      isset($request_params['group_name']) );
		\pulsecore\pre_condition( \is_string($request_params['group_name']) );
		\pulsecore\pre_condition(    \strlen($request_params['group_name']) > 0);
		
		\pulsecore\pre_condition(     isset($request_params['permissions']) );
		\pulsecore\pre_condition( \is_array($request_params['permissions']) );
		
		# params
		$param_permissions = $request_params['permissions'];
		
		# params - filter
		$param_group_name = \trim($request_params['group_name']);
		
		# CSRF
		$this->csrf_check( $request_params );
		
		$user_group_list = $this->io_load_user_group_list();
		
		$user_group_list->{$param_group_name} = (object)array(
			'group_name'  => $param_group_name,
			'permissions' => $param_permissions
		);
		
		# store
		$this->io_save_user_group_list( $user_group_list );
		
		# re-render
		$path = PULSE_ADMIN_URL;
		\header("Location: {$path}/index.php?p=manage_user_group_list");
		exit;
	}
	
	/**
	 * load the user group list from the configs and create if not present
	 * \return object
	 */
	protected function io_load_user_group_list () {
		
		$user_group_list = new \stdClass();
		
		# load stored version - if present
		if (isset(\pulsecore\wedge\config\get_json_configs()->json->user_group_list)) {
			$user_group_list = \pulsecore\wedge\config\get_json_configs()->json->user_group_list;
		}
		
		return $user_group_list;
	}
	
	/**
	 * save the user group list to the config
	 * \param $user_group_list stdClass
	 * \return void
	 */
	protected function io_save_user_group_list (\stdClass $user_group_list) {
		
		\error_log( print_r($user_group_list, true) );
		
		$data = \pulsecore\wedge\config\get_json_configs()->json;
		
		$data->user_group_list = $user_group_list;
		
		error_log( print_r($data, true) );
		
		\pulsecore\wedge\config\save_config( $data );
	}
}
