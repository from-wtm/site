<?php
namespace pulsecore\page\admin;

/**
 * manage tag descriptions
 */
class ManageTags extends Base {
	
	/**
	 * delete request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_delete (array $request_params, array $request_cookie) {
		
		\pulsecore\pre_condition(      isset($request_params['name']) );
		\pulsecore\pre_condition( \is_string($request_params['name']) );
		\pulsecore\pre_condition(    \strlen($request_params['name']) > 0);
		
		# params
		$param_name = \trim($request_params['name']);
		
		# CSRF
		$this->csrf_check( $request_params );
		
		$tags = new \stdClass();
		
		# load stored version - if present
		if (isset(\pulsecore\wedge\config\get_json_configs()->json->tags)) {
			$tags = \pulsecore\wedge\config\get_json_configs()->json->tags;
		}
		
		if (isset($tags->{$param_name})) {
			unset( $tags->{$param_name} );
		}
		
		# store
		$data = \pulsecore\wedge\config\get_json_configs()->json;
		
		$data->tags = $tags;
	
		\pulsecore\wedge\config\save_config( $data );
		
		# re-render
		# handle_get($request_params);
		\header("Location: " . PULSE_ADMIN_URL . "/index.php?p=manage_tags");
		exit;
	}
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get (array $request_params, array $request_cookie) {
		
		# render model
		$view_model = new \pulsecore\ViewModel();
		
		$tags = new \stdClass();
		
		# load stored version - if present
		if (isset(\pulsecore\wedge\config\get_json_configs()->json->tags)) {
			$tags = \pulsecore\wedge\config\get_json_configs()->json->tags;
		}
		
		$view_model->tags = $tags;
		
		# breadcrumbs
		$GLOBALS['breadcrumb_custom_settings'] = (object)array(
			'entries' => array()
		);
		$GLOBALS['breadcrumb_custom_settings']->entries['Manage Tags'] = PULSE_ADMIN_URL . "/index.php?p=manage_tags&method=get";
		
		# render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/manage_tags_list.phtml' );
		
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/js/admin/manage_tags.js' );
		
		$view->render( $view_model );
	}
	
	/**
	 * post request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_post (array $request_params, array $request_cookie) {
		
		\pulsecore\pre_condition(      isset($request_params['description']) );
		\pulsecore\pre_condition( \is_string($request_params['description']) );
		\pulsecore\pre_condition(    \strlen($request_params['description']) > 0);
		
		\pulsecore\pre_condition(      isset($request_params['name']) );
		\pulsecore\pre_condition( \is_string($request_params['name']) );
		\pulsecore\pre_condition(    \strlen($request_params['name']) > 0);
		
		# params
		$param_description = \trim($request_params['description']);
		$param_name        = \trim($request_params['name']);
		
		# CSRF
		$this->csrf_check( $request_params );
		
		$tags = new \stdClass();
		
		# load stored version - if present
		if (isset(\pulsecore\wedge\config\get_json_configs()->json->tags)) {
			$tags = \pulsecore\wedge\config\get_json_configs()->json->tags;
		}
		
		$tags->{$param_name} = (object)array(
			'description' => $param_description,
			'name'        => $param_name
		);
		
		# store
		$data = \pulsecore\wedge\config\get_json_configs()->json;
		
		$data->tags = $tags;
	
		\pulsecore\wedge\config\save_config( $data );
		
		# re-render
		# handle_get($request_params);
		\header("Location: " . PULSE_ADMIN_URL . "/index.php?p=manage_tags");
		exit;
	}
}
