<?php
namespace pulsecore\page\admin;

class CreateFolder extends Base {
	
	/*
	 * GET request shows the custom post types available
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		# parameters
		$view_model->new_name     = isset($request_params['new_name']) ? $request_params['new_name'] : '';
		$view_model->param_folder = isset($request_params['folder'])   ? $request_params['folder']   : '';
		
		# parameters - filter
		$view_model->new_name     = \pulsecore\filter\item_url( $view_model->new_name );
		$view_model->param_folder = \pulsecore\filter\item_url( $view_model->param_folder );
		
		# breadcrumbs
		$GLOBALS['breadcrumb_custom_settings'] = (object)array(
			'entries' => array()
		);
		
		$parts  = \explode( '/', $view_model->param_folder );
		$packed = array();
		foreach ($parts as $value) {
			
			if (\strlen($value) > 0) {
				$packed[] = $value;
				
				$zzz = \implode( '/', $packed );
				
				$GLOBALS['breadcrumb_custom_settings']->entries[ $value ] = PULSE_ADMIN_URL . "/index.php?f={$zzz}";
			}
		}
		
		$GLOBALS['breadcrumb_custom_settings']->entries[ $GLOBALS['lang_blog_import'] ] = PULSE_ADMIN_URL . "/index.php?p=create_folder&method=get&folder={$view_model->param_folder}";
		
		# message
		if (isset($request_params['message'])) {
			$view_model->message = \trim($request_params['message']);
		}
		
		#render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/create_folder.phtml' );
		$view->render( $view_model );
	}
	 
	/*
	 * POST request adds a new custom post type
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		# CSRF
		$this->csrf_check( $request_params );
		
		$fields = $this->extract_fields( $request_params );
		
		try {
			
			\pulsecore\pre_condition(      isset($fields['folder']) );
			\pulsecore\pre_condition( \is_string($fields['folder']) );
			\pulsecore\pre_condition(    \strlen($fields['folder']) > 0, $GLOBALS['lang_create_folder_error_no_base'] );
			
			\pulsecore\pre_condition(      isset($fields['new_name']) );
			\pulsecore\pre_condition( \is_string($fields['new_name']) );
			\pulsecore\pre_condition(    \strlen($fields['new_name']) > 0, $GLOBALS['lang_create_folder_error_no_folder'] );
			
			# parameters
			$new_name     = $fields['new_name'];
			$param_folder = $fields['folder'];
			
			# parameters - filter
			$new_name     = \pulsecore\filter\item_url( $new_name );
			$param_folder = \pulsecore\filter\item_url( $param_folder );
			
			# create
			$directory = \pulsecore\get_configs()->dir_content . '/' . $param_folder . '/' . $new_name;
			
			\pulsecore\invariant( !\file_exists($directory), $GLOBALS['lang_create_folder_error_exists'] );
			
			$status = \mkdir( $directory, 0775 );
			
			\pulsecore\invariant( $status === true, $GLOBALS['lang_create_folder_error'] );
			
			# status message
			\pulsecore\session\status_add( $GLOBALS['lang_status_ok'] );
			
			# redirect
			\header( "Location: index.php?f={$param_folder}" ); 
			exit;
			
		} catch (\LogicException $eee) {
			
			\pulsecore\log_exception( $eee );
			
			$packed = array_merge( $request_params, array('message' => "error: " . $eee->getMessage()) );
			
			$this->handle_get( $packed, $request_cookie );
		}
	}
}
