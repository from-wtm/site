<?php
namespace pulsecore\page\admin;

/**
 * change the avatar iahe
 */
class Avatar extends Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		#render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/avatar.phtml' );
		$view->render( $view_model );
	}
	
	/**
	 * post request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		# data in session
		\pulsecore\pre_condition(     isset($_SESSION['dropzone_allowed_file_types']) );
		\pulsecore\pre_condition( \is_array($_SESSION['dropzone_allowed_file_types']) );
		\pulsecore\pre_condition(   \sizeof($_SESSION['dropzone_allowed_file_types']) > 0 );
		
		\pulsecore\pre_condition(         isset($_SESSION['dropzone_media_folder']) );
		\pulsecore\pre_condition(    \is_string($_SESSION['dropzone_media_folder']) );
		\pulsecore\pre_condition( \strlen(\trim($_SESSION['dropzone_media_folder'])) > 0 );
		
		# extract
		$allowed_file_types = $_SESSION['dropzone_allowed_file_types'];
		$media_folder       = $_SESSION['dropzone_media_folder'];
		
		$csrf_token = $request_params['csrf_token'];
		
		# filter
		$media_folder = \ltrim( $media_folder, '/' );
		
		$csrf_token = \pulsecore\filter\hex( $csrf_token );
		
		if (!\pulsecore\session\csrf\verify($csrf_token)) {
			echo "Unable to verify CSRF token";
			exit;
		}
		
		if (!empty($_FILES)) {
			
			$uploaded_file = $_FILES['file']['tmp_name'];
			
			$destination = 'avatar.jpg'; #\pulsecore\filter\file_name( $_FILES['file']['name'] );
			
			$file_info = \pathinfo( $destination );
			
			\pulsecore\invariant( \in_array($file_info['extension'], $allowed_file_types), "unsupported file extension: {$file_info['extension']}" );
			
			$folder = \pulsecore\get_configs()->dir_content . DIRECTORY_SEPARATOR . $media_folder;
			 
			$destination = $folder . DIRECTORY_SEPARATOR . $destination;
			
			$status = \move_uploaded_file($uploaded_file, $destination);
			
			\pulsecore\invariant( $status === true );
			
			echo "OK";
			exit;
		}
	}
}
