<?php
namespace pulsecore\page\admin;

/**
 * base class for admin pages
 */
class Base extends \pulsecore\page\Base {
	
	/*
	 * extract fields from a request
	 */
	protected function extract_fields( array $request_params ) {
		
		$fields = array();
		
		if (isset($request_params['field']) and \is_array($request_params['field'])) {
		
			foreach ($request_params['field'] as $key => $value) {
				
				# composite value
				if (isset($value['name']) and \is_string($value['name']) and isset($value['type']) and \is_string($value['type'])) {
					
					$name = \trim($value['name']);
					$type = \trim($value['type']);
					
					if (\strlen($name) > 0) {
						$fields[$name] = (object)array('name' => $name, 'type' => $type);
					}
				} else {
					# non composite value
					$fields[$key] = $value;
				}
			}
		}
		
		return $fields;
	}
}
