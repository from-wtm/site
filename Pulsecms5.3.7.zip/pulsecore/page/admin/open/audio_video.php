<?php
namespace pulsecore\page\admin\open;

class AudioVideo extends Base {
	
	/*
	 * GET request shows the custom post types available
	 * @param array $request_params array of request parameters
	 * @param array $request_cookie array of cookie parameters
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		# parameters
		$view_model->param_get_ext =  isset($request_params['e']) ? $request_params['e'] : '';
		$view_model->param_get_f   =  isset($request_params['f']) ? $request_params['f'] : '';
		
		# parameters - filter
		$view_model->param_get_ext = \pulsecore\filter\file_extension( $view_model->param_get_ext );
		$view_model->param_get_f   = \pulsecore\filter\item_url(       $view_model->param_get_f );
		
		$view_model->fname = explode('/', $view_model->param_get_f);
		
		# message
		if (isset($request_params['message'])) {
			$view_model->message = \trim($request_params['message']);
		}
		
		# media piles for move
		$view_model->media_pile_directory = \dirname( $view_model->param_get_f );
		
		$view_model->media_piles = new \pulsecore\store\gallery\Pile( \pulsecore\get_configs()->dir_content ."/media" );
		$view_model->media_piles = \pulsecore\store\gallery\Pile::flatten( $view_model->media_piles );
		
		# file info
		$file_path = \pulsecore\get_configs()->dir_content . "/{$view_model->param_get_f}.{$view_model->param_get_ext}";
		
		$view_model->file_info = \pathinfo( $file_path );
		
		$view_model->file_size = \pulsecore\format_bytes( \filesize($file_path) );
		
		#render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/open/audio_video.phtml' );
		$view->render( $view_model );
	}
	 
	/*
	 * POST request adds a new custom post type
	 * @param array $request_params array of request parameters
	 * @param array $request_cookie array of cookie parameters
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		# CSRF
		$this->csrf_check( $request_params );
		
		try {
			
			
			# handle block moves
			$this->operation_block_move( $request_params, $request_cookie );
			
		} catch (\LogicException $eee) {
			
			\pulsecore\log_exception( $eee );
			
			$packed = array_merge( $request_params, array('message' => "error: " . $eee->getMessage()) );
			
			$this->handle_get( $packed, $request_cookie );
		}
	}
}
