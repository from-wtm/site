<?php
namespace pulsecore\page\admin\open;

class Image extends Base {
	
	/*
	 * GET request shows the custom post types available
	 * @param array $request_params array of request parameters
	 * @param array $request_cookie array of cookie parameters
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		# parameters
		$view_model->param_get_ext =  isset($request_params['e']) ? $request_params['e'] : '';
		$view_model->param_get_f   =  isset($request_params['f']) ? $request_params['f'] : '';
		
		# parameters - filter
		$view_model->param_get_ext = \pulsecore\filter\file_extension( $view_model->param_get_ext );
		$view_model->param_get_f   = \pulsecore\filter\item_url(       $view_model->param_get_f );
		
		###
		$view_model->filepath   = \pulsecore\get_configs()->dir_content . '/' . $view_model->param_get_f;
		$fname                  = explode('/', $view_model->param_get_f);
		$view_model->fname      = $fname;
		$view_model->last_level = end($fname);
		
		$view_model->pics_files    = ['.jpg','.jpeg','.gif','.svg','.png'];
		$view_model->browser_files = ['.zip','.pdf'];
		
		$view_model->dimen = (getimagesize($view_model->filepath . '.' . $view_model->param_get_ext));
		$view_model->dim   = ($view_model->param_get_ext == '.svg') ? 'vector' : ($view_model->dimen[0].' x '.$view_model->dimen[1]);
		$view_model->size  = round(filesize($view_model->filepath . '.' . $view_model->param_get_ext)/1000,2);
		
		$view_model->now_now = \date('YmdHis');
		
		$view_model->path = \pulsecore\wedge\config\get_json_configs()->json->path;
		
		$view_model->flag_has_content = \file_exists($view_model->filepath . '.' . $view_model->param_get_ext);
		
		
		# image data
		$view_model->media_pile_directory = $view_model->param_get_f;
		$view_model->media_pile_directory = \pulsecore\filter\item_url( $view_model->media_pile_directory );
		$view_model->media_pile_directory = \dirname( $view_model->media_pile_directory );
		
		$view_model->media_piles = new \pulsecore\store\gallery\Pile( \pulsecore\get_configs()->dir_content ."/media" );
		
		$view_model->media_piles = \pulsecore\store\gallery\Pile::flatten($view_model->media_piles);
		
		
		# page resources
		\pulsecore\get_context()->theme->css->add(
			PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/croppie/croppie.css",
			array(
			)
		);
		\pulsecore\get_context()->theme->js_body->add(
			PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/croppie/croppie.min.js",
			array(
			)
		);
		\pulsecore\get_context()->theme->js_body->add(
			PULSE_BASE_URL . "/pulsecore/asset/js/admin/open_media.js",
			array(
				PULSE_BASE_URL . "/pulsecore/asset/vendor/node_modules/croppie/croppie.min.js",
			)
		);
		
		#render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/open/image.phtml' );
		$view->render( $view_model );
	}
	 
	/*
	 * POST request adds a new custom post type
	 * @param array $request_params array of request parameters
	 * @param array $request_cookie array of cookie parameters
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		# CSRF
		$this->csrf_check( $request_params );
		
		try {
			
			# handle block moves
			$this->operation_block_move( $request_params, $request_cookie );
			
			#####################################################################
			#####################################################################
			#####################################################################
			#####################################################################
			
			# parameters
			$param_get_ext =  isset($request_params['e']) ? $request_params['e'] : '';
			$param_get_f   =  isset($request_params['f']) ? $request_params['f'] : '';
			
			# parameters - filter
			$param_get_ext = \pulsecore\filter\file_extension( $param_get_ext );
			$param_get_f   = \pulsecore\filter\item_url(       $param_get_f );
		
			$fname = explode('/', $param_get_f);
			
			include (PULSE_ADMIN_DIR . '/inc/captions.php');
				
			#####################################################################
			#####################################################################
			#####################################################################
			#####################################################################
			
		} catch (\LogicException $eee) {
			
			\pulsecore\log_exception( $eee );
			
			$packed = array_merge( $request_params, array('message' => "error: " . $eee->getMessage()) );
			
			$this->handle_get( $packed, $request_cookie );
		}
		
		\header("Location: index.php?p=open&f={$param_get_f}&e={$param_get_ext}");
		exit;
	}
}
