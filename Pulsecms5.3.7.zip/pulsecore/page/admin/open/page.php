<?php
namespace pulsecore\page\admin\open;

class Page extends Base {
	
	/*
	 * GET request shows the custom post types available
	 * @param array $request_params array of request parameters
	 * @param array $request_cookie array of cookie parameters
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		# parameters
		$view_model->param_get_ext =  isset($request_params['e']) ? $request_params['e'] : '';
		$view_model->param_get_f   =  isset($request_params['f']) ? $request_params['f'] : '';
		
		# parameters - filter
		$view_model->param_get_ext = \pulsecore\filter\file_extension( $view_model->param_get_ext );
		$view_model->param_get_f   = \pulsecore\filter\item_url(       $view_model->param_get_f );
		
		$view_model->draft_mode = (\stripos($view_model->param_get_f, 'draft') !== false) ? 'yes' : 'no';
		
		$view_model->fname = explode('/', $view_model->param_get_f);
		
		$view_model->force_textblock = isset($request_params['force_textblock']);
		
		$view_model->flag_has_content = (!empty($view_model->param_get_f) and \file_exists(\pulsecore\get_configs()->dir_content . "/{$view_model->param_get_f}.txt"));
		
		$view_model->datum_item = new \pulsecore\store\page\Item();
		$view_model->datum_item->load( \pulsecore\get_configs()->dir_content . "/{$view_model->param_get_f}.txt" );
		
		# message
		if (isset($request_params['message'])) {
			$view_model->message = \trim($request_params['message']);
		}
		
		/*
		# page piles for move
		$view_model->page_pile_directory = \dirname( $view_model->param_get_f );
		
		$view_model->page_piles = new \pulsecore\store\page\Pile( \pulsecore\get_configs()->dir_content . '/pages' );
		
		$view_model->page_piles = \pulsecore\store\page\Pile::flatten($view_model->page_piles);
		*/
		
		# file info
		$file_path = \pulsecore\get_configs()->dir_content . "/{$view_model->param_get_f}.{$view_model->param_get_ext}";
		
		$view_model->file_info = \pathinfo( $file_path );
		
		$view_model->file_size = \pulsecore\format_bytes( \filesize($file_path) );
		
		#render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/open/page.phtml' );
		$view->render( $view_model );
	}
	 
	/*
	 * POST request adds a new custom post type
	 * @param array $request_params array of request parameters
	 * @param array $request_cookie array of cookie parameters
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		# CSRF
		$this->csrf_check( $request_params );
		
		try {
			
			# handle block moves
			$this->operation_block_move( $request_params, $request_cookie );
			
			#####################################################################
			#####################################################################
			#####################################################################
			#####################################################################
			
			# parameters
			$param_get_ext =  isset($request_params['e']) ? $request_params['e'] : '';
			$param_get_f   =  isset($request_params['f']) ? $request_params['f'] : '';
			
			# parameters - filter
			$param_get_ext = \pulsecore\filter\file_extension( $param_get_ext );
			$param_get_f   = \pulsecore\filter\item_url(       $param_get_f );
		
			$fname = explode('/', $param_get_f);
			
			# POST params
			$param_filename  = isset($request_params['filename'])  ? $request_params['filename']  : '';
			$param_textblock = isset($request_params['textblock']) ? $request_params['textblock'] : '';
			
			$param_meta_access_user_group = isset($request_params['meta_access_user_group']) ? $request_params['meta_access_user_group'] : [];
			
			# POST params - filter
			$param_filename  = \pulsecore\filter\item_url( $param_filename );
			$param_textblock = \trim( $param_textblock );
			
			# detect draft mode
			$is_draft_mode = (\stripos($param_get_f, 'draft') !== false);
			
			# save edits to txt file
			if (    !empty($param_textblock)
				and !empty($param_filename)
				and \file_exists(\pulsecore\get_configs()->dir_content . '/' . $param_filename)
				and isset($request_params['savetext'])) {
				
				$content = $param_textblock;
				
				# parameters
				$page_filename = $param_filename;
				
				$path_info = \pathinfo( $page_filename );
				
				$page_filename = \str_replace( ('.' . $path_info['extension']), '', $page_filename );
				$page_filename = \pulsecore\filter\item_url( $page_filename ) . '.' . $path_info['extension'];
				
				$page_filename_f = \ltrim($page_filename, '/');
				$page_filename_f = \str_replace( ('.' . $path_info['extension']), '', $page_filename_f );
				
				# expand instances of {{show_var:path}}
				$content = \str_replace( \pulsecore\wedge\config\get_json_configs()->json->path, '{{show_var:path}}', $content );
				
				$page_item = new \pulsecore\store\page\Item();
				$page_item->description   = $request_params["head2"];
				$page_item->html          = $param_textblock;
				$page_item->id            = \basename( $page_filename, '.txt');
				$page_item->location      = \pulsecore\store\Base::location_from_filename( (\pulsecore\get_configs()->dir_content . '/' . $page_filename), \pulsecore\get_configs()->dir_content);
				$page_item->meta_custom_description = $request_params["meta_custom_description"];
				$page_item->meta_indexed            = \pulsecore\filter\yes_no($request_params["meta_indexed"]);
				$page_item->meta_language           = $request_params["meta_language"];
				$page_item->meta_no_follow          = \pulsecore\filter\yes_no($request_params["meta_no_follow"]);
				$page_item->meta_searchable         = \pulsecore\filter\yes_no($request_params["meta_searchable"]);
				$page_item->page_template = $request_params["page_template"];
				$page_item->title         = $request_params["head1"];
				
				$page_item->inline_css = $request_params["inline_css"];
				$page_item->inline_js  = $request_params["inline_js"];
				
				$content = $page_item->pickle();
				
				# update group permissions
				if (\sizeof($param_meta_access_user_group) > 0) {
					
					$user_group_list = \pulsecore\wedge\config\get_json_configs()->json->user_group_list;
					
					foreach ($param_meta_access_user_group as $selected_group_key => $selected_group_value) {
						if ($selected_group_value == '-') {
							unset($user_group_list->{$selected_group_key}->permissions->page->{$page_filename_f});
						} else {
							$user_group_list->{$selected_group_key}->permissions->page->{$page_filename_f} = 'rw';
						}
					}
					
					\pulsecore\wedge\config\get_json_configs()->json->user_group_list = $user_group_list;
					\pulsecore\wedge\config\save_config( \pulsecore\wedge\config\get_json_configs()->json );
				}
				
				# ensure that only content filenames can be written to!
				$fp = $page_filename;
				$fp = \str_replace('../content/', '', $fp);
				$fp = \pulsecore\filter\page( $fp );
				$fp = \pulsecore\get_configs()->dir_content . '/' . $fp;
				$fp = \str_replace( $path_info['extension'], ('.' . $path_info['extension']), $fp);
				
				\file_put_contents( $fp, $content );
				
				# status message
				\pulsecore\session\status_add( $GLOBALS['lang_status_ok'] );
				
				# corner case - draft mode
				if (($request_params['meta_draft_mode'] == 'yes') and !$is_draft_mode) {
					$new_fp = \dirname($fp) . '/draft-' . \basename($fp);
					
					# move
					\rename( $fp, $new_fp);
					
					# bounce
					\header("Location: index.php?p=open&f=" . \dirname($page_filename_f) . '/draft-' . \basename($page_filename_f) . "&e={$path_info['extension']}");
					exit;
				}
				
				# corner case - un-draft from draft mode
				if (($request_params['meta_draft_mode'] == 'no') and $is_draft_mode) {
					
					$new_basename = \basename($fp);
					$new_basename = \str_replace( 'draft-', '', $new_basename );
					
					$new_fp = \dirname($fp) . '/' . $new_basename;
					
					# move
					\rename( $fp, $new_fp);
					
					# bounce
					$new_basename = \str_replace( ('.' . $path_info['extension']), '', $new_basename );
					
					\header("Location: index.php?p=open&f=" . \dirname($page_filename_f) . "/{$new_basename}&e={$path_info['extension']}");
					exit;
				}
			}
			
			#####################################################################
			#####################################################################
			#####################################################################
			#####################################################################
			
			
		} catch (\LogicException $eee) {
			
			\pulsecore\log_exception( $eee );
			
			$packed = array_merge( $request_params, array('message' => "error: " . $eee->getMessage()) );
			
			$this->handle_get( $packed, $request_cookie );
		}
		
		\header("Location: index.php?p=open&f={$param_get_f}&e={$param_get_ext}");
		exit;
	}
}
