<?php
namespace pulsecore\page\admin;

/**
 * manage dropzone uploads for ADMIN template uploads
 */
class TemplateUploadHandler extends Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		#render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/template_upload_handler.phtml' );
		$view->render( $view_model );
	}
	
	/**
	 * post request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		# data in session
		\pulsecore\pre_condition(     isset($_SESSION['dropzone_allowed_file_types']) );
		\pulsecore\pre_condition( \is_array($_SESSION['dropzone_allowed_file_types']) );
		\pulsecore\pre_condition(   \sizeof($_SESSION['dropzone_allowed_file_types']) > 0 );
		
		\pulsecore\pre_condition(         isset($_SESSION['dropzone_media_folder']) );
		\pulsecore\pre_condition(    \is_string($_SESSION['dropzone_media_folder']) );
		\pulsecore\pre_condition( \strlen(\trim($_SESSION['dropzone_media_folder'])) > 0 );
		
		# extract
		$allowed_file_types = $_SESSION['dropzone_allowed_file_types'];
		$media_folder       = $_SESSION['dropzone_media_folder'];
		
		$csrf_token = $request_params['csrf_token'];
		
		# filter
		$media_folder = \ltrim( $media_folder, '/' );
		
		$csrf_token = \pulsecore\filter\hex( $csrf_token );
		
		if (!\pulsecore\session\csrf\verify($csrf_token)) {
			echo "Unable to verify CSRF token";
			exit;
		}
		
		if (!empty($_FILES)) {
			
			$uploaded_file = $_FILES['file']['tmp_name'];
			
			$destination = \pulsecore\filter\file_name( $_FILES['file']['name'] );
			
			$file_info = \pathinfo( $destination );
			
			\pulsecore\invariant( \in_array($file_info['extension'], $allowed_file_types), "unsupported file extension: {$file_info['extension']}" );
			
			$folder = \pulsecore\get_configs()->dir_content . DIRECTORY_SEPARATOR . $media_folder;
			 
			$destination = $folder . DIRECTORY_SEPARATOR . $destination;
			
			$status = \move_uploaded_file($uploaded_file, $destination);
			
			\pulsecore\invariant( $status === true );
			
			# theme name
			$theme_name = \basename($destination, '.zip');
			
			# ensure that the target directory exists
			$extraction_destination     = $folder . DIRECTORY_SEPARATOR . $theme_name;
			$extraction_destination_tmp = $folder . DIRECTORY_SEPARATOR . $theme_name . '_tmp';
			
			\pulsecore\invariant( \is_file($extraction_destination_tmp) === false );
			
			if (!\is_dir($extraction_destination_tmp)) {
				
				$status = \mkdir( $extraction_destination_tmp );
				
				\pulsecore\invariant( $status === true );
			}
			
			# unzip the zip file
			$za = new \ZipArchive();
			
			$status = $za->open( $destination );
			
			\pulsecore\invariant( $status === true, "Unable to open zip file. Error code: {$status}" );
			
			$status = $za->extractTo( $extraction_destination_tmp );
			
			\pulsecore\invariant( $status === true, "Unable to extract files in zip file" );
			
			$za->close();
			
			# move sub directory with theme name into place
			if (\file_exists($extraction_destination_tmp . DIRECTORY_SEPARATOR . $theme_name)) {
				# theme in a directory named with theme name in zip
				\rename( ($extraction_destination_tmp . DIRECTORY_SEPARATOR . $theme_name), $extraction_destination );
				
				# move page files into content/pages
				if (\file_exists($extraction_destination . DIRECTORY_SEPARATOR . 'pulsecms')) {
					
					$pages = \glob( $extraction_destination . DIRECTORY_SEPARATOR . 'pulsecms' . DIRECTORY_SEPARATOR . '*.txt' );
					
					var_dump($pages);
					
					$dir_pages = \pulsecore\get_configs()->dir_content . DIRECTORY_SEPARATOR . 'pages';
					
					foreach ($pages as $value) {
						\rename( $value, $dir_pages . DIRECTORY_SEPARATOR . \basename($value) );
					}
				}
				
			} else {
				# theme files in zip root
				\rename( $extraction_destination_tmp, $extraction_destination );
			}
			
			# cleanup - remove uploaded zip
			\unlink( $destination );
			
			# cleanup - remove old tmp directory
			if (\file_exists($extraction_destination_tmp)) {
				\rmdir( $extraction_destination_tmp );
			}
			
			echo "OK";
			exit;
		}
	}
}
