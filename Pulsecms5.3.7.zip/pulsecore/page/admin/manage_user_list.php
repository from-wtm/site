<?php
namespace pulsecore\page\admin;

/**
 * manage user list
 */
class ManageUserList extends Base {
	
	/**
	 * delete request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_delete (array $request_params, array $request_cookie) {
		
		\pulsecore\pre_condition(      isset($request_params['username']) );
		\pulsecore\pre_condition( \is_string($request_params['username']) );
		\pulsecore\pre_condition(    \strlen($request_params['username']) > 0);
		
		# params
		$param_username = \trim($request_params['username']);
		
		# CSRF
		$this->csrf_check( $request_params );
		
		$user_list = new \stdClass();
		
		# load stored version - if present
		if (isset(\pulsecore\wedge\config\get_json_configs()->json->user_list)) {
			$user_list = \pulsecore\wedge\config\get_json_configs()->json->user_list;
		}
		
		if (isset($user_list->{$param_username})) {
			unset( $user_list->{$param_username} );
		}
		
		# store
		$data = \pulsecore\wedge\config\get_json_configs()->json;
		
		$data->user_list = $user_list;
	
		\pulsecore\wedge\config\save_config( $data );
		
		# re-render
		# handle_get($request_params);
		$path = PULSE_ADMIN_URL;
		\header("Location: {$path}/index.php?p=manage_user_list");
		exit;
	}
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get (array $request_params, array $request_cookie) {
		
		# render model
		$view_model = new \pulsecore\ViewModel();
		
		$user_list = new \stdClass();
		
		# load stored version - if present
		if (isset(\pulsecore\wedge\config\get_json_configs()->json->user_list)) {
			$user_list = \pulsecore\wedge\config\get_json_configs()->json->user_list;
		}
		
		$view_model->user_list = $user_list;
		
		# get the list of active ACL roles
		$acl_role = \array_merge( array(), ((array)\pulsecore\get_configs()->acl_role) );
		unset( $acl_role['guest'] );
		
		if (\pulsecore\wedge\config\get_json_configs()->json->editor_user_enable !== true) {
			unset( $acl_role['editor'] );
		}
		
		$view_model->acl_role = $acl_role;
		
		# user groups
		$view_model->user_group_list =
			isset(\pulsecore\wedge\config\get_json_configs()->json->user_group_list)
			? \pulsecore\wedge\config\get_json_configs()->json->user_group_list
			: ((object)array());
		
		/*
		# only allow new users if there are user groups in place
		if (\sizeof( ((array)$view_model->user_group_list) ) == 0) {
			
			\header("Location: " . PULSE_ADMIN_URL . "/index.php?p=manage_user_group_list");
			exit;
		}
		*/
		
		# breadcrumbs
		$GLOBALS['breadcrumb_custom_settings'] = (object)array(
			'entries' => array()
		);
		$GLOBALS['breadcrumb_custom_settings']->entries['Manage Users'] = PULSE_ADMIN_URL . "/index.php?p=manage_user_list&method=get";
		
		# render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/manage_user_list.phtml' );
		
		\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/js/admin/manage_user_list.js' );
		
		$view->render( $view_model );
	}
	
	/**
	 * post request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_post (array $request_params, array $request_cookie) {
		
		try {
			
			# set default empty user_group_list
			$request_params = \array_merge( array('user_group_list' => array()), $request_params );
			
			# validate input
			\pulsecore\pre_condition(      isset($request_params['acl_role']) );
			\pulsecore\pre_condition( \is_string($request_params['acl_role']) );
			\pulsecore\pre_condition(    \strlen($request_params['acl_role']) > 0);
			
			\pulsecore\pre_condition(      isset($request_params['otp_activate']) );
			\pulsecore\pre_condition( \is_string($request_params['otp_activate']) );
			\pulsecore\pre_condition(    \strlen($request_params['otp_activate']) > 0);
			
			\pulsecore\pre_condition(      isset($request_params['password']) );
			\pulsecore\pre_condition( \is_string($request_params['password']) );
			\pulsecore\pre_condition(    \strlen($request_params['password']) > 0);
			
			\pulsecore\pre_condition(      isset($request_params['username']) );
			\pulsecore\pre_condition( \is_string($request_params['username']) );
			\pulsecore\pre_condition(    \strlen($request_params['username']) > 0);
			
			\pulsecore\pre_condition(     isset($request_params['user_group_list']) );
			\pulsecore\pre_condition( \is_array($request_params['user_group_list']) );
			\pulsecore\pre_condition(    sizeof($request_params['user_group_list']) > 0, $GLOBALS['lang_settings_user_list_error_no_group'] );
			
			# extract params
			$param_acl_role     = \trim($request_params['acl_role']);
			$param_otp_activate = \trim($request_params['otp_activate']);
			$param_password     = \trim($request_params['password']);
			$param_username     = \trim($request_params['username']);
			
			$param_user_group_list = $request_params['user_group_list'];
			
			# CSRF
			$this->csrf_check( $request_params );
			
			$user_list = new \stdClass();
			
			# load stored version - if present
			if (isset(\pulsecore\wedge\config\get_json_configs()->json->user_list)) {
				$user_list = \pulsecore\wedge\config\get_json_configs()->json->user_list;
			}
			
			$user_list->{$param_username} = (object)array(
				'acl_role'     => $param_acl_role,
				'otp_activate' => $param_otp_activate,
				'password'     => \password_hash($param_password, \PASSWORD_DEFAULT),
				'username'     => $param_username,
				
				'user_group_list' => $param_user_group_list
			);
			
			# store
			$data = \pulsecore\wedge\config\get_json_configs()->json;
			
			$data->user_list = $user_list;
			
			\pulsecore\wedge\config\save_config( $data );
			
		} catch (\LogicException $eee) {
			
			\pulsecore\session\status_add( $eee->getMessage(), 'error' );
			
			\pulsecore\log_exception( $eee );
		}
		
		# re-render
		# handle_get($request_params);
		$path = PULSE_ADMIN_URL;
		\header("Location: {$path}/index.php?p=manage_user_list");
		exit;
	}
}
