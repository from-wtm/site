<?php
namespace pulsecore\page\admin;

/**
 * show log files
 */
class LogViewer extends Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get (array $request_params, array $request_cookie) {
		
		# render model
		$view_model = new \pulsecore\ViewModel();
		
		# breadcrumbs
		$GLOBALS['breadcrumb_custom_settings'] = (object)array(
			'entries' => array()
		);
		$GLOBALS['breadcrumb_custom_settings']->entries['Log Viewer'] = PULSE_ADMIN_URL . "/index.php?p=log_viewer&method=get";
		
		# log files
		$logs = \glob( \pulsecore\get_configs()->dir_storage . '/log/*.log' );
		
		foreach ($logs as $key => $value) {
			$logs[$key] = \basename($value, 'log');
			$logs[$key] = \trim($logs[$key], '.' );
		}
		
		ksort( $logs);
		
		$view_model->logs = $logs;
		
		# param
		$view_model->param_select = isset($request_params['select']) ? $request_params['select'] : '';
		
		$view_model->param_select = \pulsecore\filter\variable_name( $view_model->param_select );
		
		if (\strlen($view_model->param_select) > 0) {
			$view_model->content = \file_get_contents( \pulsecore\get_configs()->dir_storage . '/log/' . $view_model->param_select . '.log' );
		}
		
		# render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/log_viewer.phtml' );
		
		$view->render( $view_model );
	}
	
}
