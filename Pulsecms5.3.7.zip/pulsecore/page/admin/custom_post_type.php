<?php
namespace pulsecore\page\admin;

require_once (PULSE_BASE_DIR . '/pulsecore/custom_post_type.php');

require_once (PULSE_BASE_DIR . '/pulsecore/wedge/custom_post_type_storage.php');

class CustomPostType extends Base {
	
	/*
	 * DELETE request removes a custom post type
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 */
	protected function handle_delete( array $request_params, array $request_cookie ) {
		
		\pulsecore\pre_condition(      isset($request_params['post_type_name']) );
		\pulsecore\pre_condition( \is_string($request_params['post_type_name']) );
		\pulsecore\pre_condition(    \strlen($request_params['post_type_name']) > 0);
		
		\pulsecore\pre_condition(      isset($request_params['post_name']) );
		\pulsecore\pre_condition( \is_string($request_params['post_name']) );
		\pulsecore\pre_condition(    \strlen($request_params['post_name']) > 0);
		
		# CSRF
		$this->csrf_check( $request_params );
			
		$post_type_name = $request_params['post_type_name'];
		$post_name      = $request_params['post_name'     ];
		
		$post_type_name = \pulsecore\filter\custom_post_type_name( $post_type_name );
		$post_name      = \pulsecore\filter\custom_post_type_name( $post_name      );
		
		$fields = $this->extract_fields( $request_params );
		
		#show the form?
		if (\sizeof($fields) == 0) {
			
			$view_model = new \pulsecore\ViewModel();
			
			$view_model->post_type_name = $post_type_name;
			$view_model->post_name      = $post_name;
			
			#breadcrumbs
			$GLOBALS['breadcrumb_custom_settings'] = (object)array(
				'entries' => array()
			);
			$GLOBALS['breadcrumb_custom_settings']->entries['Custom Post Types'] = PULSE_ADMIN_URL . "/index.php?p=custom_post_type_definitions&method=get";
			$GLOBALS['breadcrumb_custom_settings']->entries[$post_type_name]     = PULSE_ADMIN_URL . "/index.php?p=custom_post_types&post_type_name={$post_type_name}&method=get";
			
			#render
			$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/custom_post_types_delete.phtml' );
			$view->render( $view_model );
		
		} else {
			#delete operation
			$filename = (\pulsecore\get_configs()->dir_content . "/{$post_type_name}/{$post_name}.txt");
			
			\pulsecore\invariant( \is_file($filename) );
			
			\unlink($filename);
			
			#re-render
			\header( "Location: index.php?p=custom_post_types&post_type_name={$post_type_name}&method=get" );
			exit;
		}
	}
	
	/*
	 * GET request shows the custom post types available
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		\pulsecore\pre_condition(      isset($request_params['post_type_name']) );
		\pulsecore\pre_condition( \is_string($request_params['post_type_name']) );
		\pulsecore\pre_condition(    \strlen($request_params['post_type_name']) > 0);
		
		$post_type_name = $request_params['post_type_name'];
		
		$post_type_name = \pulsecore\filter\custom_post_type_name( $post_type_name );
		
		$view_model = new \pulsecore\ViewModel();
		
		$view_model->post_type_name = $post_type_name;
		$view_model->list           = \pulsecore\wedge\custom_post_type\storage\list_entries(
			$post_type_name,
			(\pulsecore\get_configs()->dir_content . '/' . $post_type_name)
		);
		
		#breadcrumbs
		$GLOBALS['breadcrumb_custom_settings'] = (object)array(
			'entries' => array()
		);
		$GLOBALS['breadcrumb_custom_settings']->entries['Custom Post Types'] = PULSE_ADMIN_URL . "/index.php?p=custom_post_type_definitions&method=get";
		$GLOBALS['breadcrumb_custom_settings']->entries[$post_type_name]     = PULSE_ADMIN_URL . "/index.php?p=custom_post_types&post_type_name={$post_type_name}&method=get";
		
		#render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/custom_post_types_list.phtml' );
		$view->render( $view_model );
	}
	 
	/*
	 * POST request adds a new custom post type
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		\pulsecore\pre_condition(      isset($request_params['post_type_name']) );
		\pulsecore\pre_condition( \is_string($request_params['post_type_name']) );
		\pulsecore\pre_condition(    \strlen($request_params['post_type_name']) > 0);
		
		# CSRF
		$this->csrf_check( $request_params );
		
		$post_type_name = $request_params['post_type_name'];
		
		$post_type_name = \pulsecore\filter\custom_post_type_name( $post_type_name );
		
		$fields = $this->extract_fields( $request_params );
		
		#show the form?
		if (\sizeof($fields) == 0) {
			
			$view_model = new \pulsecore\ViewModel();
			
			$view_model->post_type_name = $post_type_name;
			$view_model->store          = \pulsecore\wedge\custom_post_type\storage\make_store( $post_type_name );
			
			#breadcrumbs
			$GLOBALS['breadcrumb_custom_settings'] = (object)array(
				'entries' => array()
			);
			$GLOBALS['breadcrumb_custom_settings']->entries['Custom Post Types'] = PULSE_ADMIN_URL . "/index.php?p=custom_post_type_definitions&method=get";
			$GLOBALS['breadcrumb_custom_settings']->entries[$post_type_name]     = PULSE_ADMIN_URL . "/index.php?p=custom_post_types&post_type_name={$post_type_name}&method=get";
			
			#render
			$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/custom_post_types_add.phtml' );
			$view->render( $view_model );
		
		} else {
			
			\pulsecore\pre_condition(      isset($request_params['post_name']) );
			\pulsecore\pre_condition( \is_string($request_params['post_name']) );
			\pulsecore\pre_condition(    \strlen($request_params['post_name']) > 0);
			
			\pulsecore\pre_condition(      isset($request_params['post_type_name']) );
			\pulsecore\pre_condition( \is_string($request_params['post_type_name']) );
			\pulsecore\pre_condition(    \strlen($request_params['post_type_name']) > 0);
			
			$post_name = \pulsecore\filter\custom_post_type_name($request_params['post_name']);
			
			$datum = \pulsecore\wedge\custom_post_type\storage\make_store($post_type_name, $post_name );
			
			foreach ($fields as $key => $value) {
				$datum->{$key} = $value;
			}
			
			$datum = \pulsecore\wedge\custom_post_type\storage\inject( 'custom post type entry', $datum );
			
			\pulsecore\wedge\custom_post_type\storage\save_entry_file(
				(\pulsecore\get_configs()->dir_content . "/{$post_type_name}/{$post_name}.txt"),
				$datum
			);
			
			#re-render
			\header( "Location: index.php?p=custom_post_types&post_type_name={$post_type_name}&method=get" );
			exit;
		}
	}
	 
	/*
	 * PUT request updates an existing custom post type
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 */
	protected function handle_put( array $request_params, array $request_cookie ) {
		
		\pulsecore\pre_condition(      isset($request_params['post_type_name']) );
		\pulsecore\pre_condition( \is_string($request_params['post_type_name']) );
		\pulsecore\pre_condition(    \strlen($request_params['post_type_name']) > 0);
		
		\pulsecore\pre_condition(      isset($request_params['post_name']) );
		\pulsecore\pre_condition( \is_string($request_params['post_name']) );
		\pulsecore\pre_condition(    \strlen($request_params['post_name']) > 0);
		
		# CSRF
		$this->csrf_check( $request_params );
		
		$post_type_name = $request_params['post_type_name'];
		$post_name      = $request_params['post_name'     ];
		
		$post_type_name = \pulsecore\filter\custom_post_type_name( $post_type_name );
		$post_name      = \pulsecore\filter\custom_post_type_name( $post_name      );
		
		$fields = $this->extract_fields( $request_params );
		
		#show the form?
		if (\sizeof($fields) == 0) {
			
			$view_model = new \pulsecore\ViewModel();
			
			$view_model->post_type_name = $post_type_name;
			$view_model->post_name      = $post_name;
			
			$view_model->store          = \pulsecore\wedge\custom_post_type\storage\load_entry_file(
				$post_type_name,
				(\pulsecore\get_configs()->dir_content . "/{$post_type_name}/{$post_name}.txt")
			);
			
			#breadcrumbs
			$GLOBALS['breadcrumb_custom_settings'] = (object)array(
				'entries' => array()
			);
			$GLOBALS['breadcrumb_custom_settings']->entries['Custom Post Types'] = PULSE_ADMIN_URL . "/index.php?p=custom_post_type_definitions&method=get";
			$GLOBALS['breadcrumb_custom_settings']->entries[$post_type_name]     = PULSE_ADMIN_URL . "/index.php?p=custom_post_types&post_type_name={$post_type_name}&method=get";
			
			
			#render
			$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/custom_post_types_edit.phtml' );
			$view->render( $view_model );
		
		} else  {
			
			$filename = (\pulsecore\get_configs()->dir_content . "/{$post_type_name}/{$post_name}.txt"); 
		
			$datum = \pulsecore\wedge\custom_post_type\storage\load_entry_file($post_type_name, $filename, $post_name );
			
			foreach ($fields as $key => $value) {
				$datum[1]->{$key} = $value;
			}
			
			$datum = \pulsecore\wedge\custom_post_type\storage\inject( $datum[0], $datum[1] );
			
			\pulsecore\wedge\custom_post_type\storage\save_entry_file(
				$filename,
				$datum
			);
			
			#re-render
			\header( "Location: index.php?p=custom_post_types&post_type_name={$post_type_name}&method=get" );
			exit;
		}
	}
	
}
