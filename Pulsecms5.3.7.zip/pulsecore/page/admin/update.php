<?php
namespace pulsecore\page\admin;

/**
 * update a pulse install
 */
class Update extends Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		$view_model = new \pulsecore\ViewModel();
		
		# render
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/update.phtml' );
		$view->render( $view_model );
	}
	
	/**
	 * post request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		
		# tweak script timeout
		\set_time_limit( 3*60 );
		
		# params
		$csrf_token = isset($request_params['csrf_token']) ? $request_params['csrf_token'] : '';
		
		$csrf_token = \pulsecore\filter\hex( $csrf_token );
		
		if (!\pulsecore\session\csrf\verify($csrf_token)) {
			#echo "Unable to verify CSRF token";
			#exit;
		}
		
		# upload the zip file
		if ( (isset($_FILES['zipfile']) and !(empty($_FILES['zipfile'])) and !(empty($_FILES['zipfile']['name'])))
				) {
			
			# move upload into place
			$update_file = \pulsecore\get_configs()->dir_storage . "/pulsecms.zip";
			
			$status = \move_uploaded_file($_FILES['zipfile']["tmp_name"], $update_file);
			
			\pulsecore\invariant( $status, "Unable to move PulseCMS update zip file into place");
			
			\chmod( $update_file, 0777);
			
			# get a list of the changed files
			list($collected, $update_file_list) = $this->update_file_list( $update_file );
			
			# show the file list
			$view_model = new \pulsecore\ViewModel();
			$view_model->collected = $collected;
		
			# render
			$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/admin/update.phtml' );
			$view->render( $view_model );
			return;
		}
		
		if (isset($request_params['run_update'])) {
			
			$this->site_update();
		}
	}
	
	/**
	 * run the actual update once the user confirms
	 */
	protected function site_update () {
		
		# where the upload file can be found
		$update_file = \pulsecore\get_configs()->dir_storage . "/pulsecms.zip";
		
		# base dir for install
		$base_dir = \realpath(PULSE_BASE_DIR);
		
		# backup current pulse install
		$backup_file = \pulsecore\get_configs()->dir_storage . "/backup_" . \date('YmdHis') . ".zip";
		$zip_backup = new \ZipArchive();
		$status = $zip_backup->open( $backup_file, \ZipArchive::CREATE );
		
		\pulsecore\invariant( $status, "Unable to open backup zip file");
		
		$dirs  = array( $base_dir ); 
		
		while (\sizeof($dirs) > 0) {
			
			$ddd = \array_pop($dirs);
			
			$files = \glob( $ddd . '/*' );
			
			foreach ($files as $vvv) {
				
				if (\is_dir($vvv)) {
					\array_push($dirs, $vvv);
				} else {
					$fff = \str_replace( ($base_dir .'/'), '', $vvv);
					
					if (\stripos($fff, '.zip') === false) { # no zip files
						$zip_backup->addFile( $vvv, $fff );
					}
				}
			}
		}
		$zip_backup->close();
		
		# get the list of files to update
		list($collected_list, $update_file_list) = $this->update_file_list( $update_file );
		
		# unpack update
		$zip_update = new \ZipArchive();
		$status = $zip_update->open( $update_file );
		
		\pulsecore\invariant( $status, "Unable to open update zip file");
		
		$zip_update->extractTo( $base_dir, $update_file_list );
		
		$zip_update->close();
		
		# status message
		\pulsecore\session\status_add( $GLOBALS['lang_status_ok'] );
		\header( 'Location: ' . PULSE_ADMIN_URL . '/index.php?p=update' );
		exit;
	}
	
	/**
	 * get a list of the files to update
	 *
	 * @param string $zip_filename
	 * @return array
	 */
	protected function update_file_list (string $zip_filename) : array {
		
		$clean_list = [];
		$collected  = [];
		
		# unpack update
		$zip_update = new \ZipArchive();
		$status = $zip_update->open( $zip_filename );
		
		\pulsecore\invariant( $status, "Unable to open update zip file");
		
		for ($k = 0; $k < $zip_update->numFiles; $k++) {
			
			$filename = $zip_update->getNameIndex( $k );
			
			$in_content  = ((\stripos($filename, 'content/')  !== false));
			$in_template = ((\stripos($filename, 'template/') !== false) and (\stripos($filename, 'pulsecore/template/') === false));
			
			$in_storage  = ((\stripos($filename, 'pulsecore/storage/') !== false));
			
			# echo $filename, ' ', \stripos($filename, 'template/'), ' ', \stripos($filename, 'pulsecore/template/'), ' ', $in_template, ' zzz ', (\stripos($filename, 'pulsecore/template/') === false), PHP_EOL;
			
			if (!$in_content and !$in_storage and !$in_template) {
				
				$collected[] = (object)array(
					'important' => ($in_content or (stripos($filename, '.htaccess') !== false)),
					'filename'  => $filename
				);
				
				$clean_list[] = $filename;
			}
		}
		
		$zip_update->close();
		
		return [$collected, $clean_list];
	}
}
