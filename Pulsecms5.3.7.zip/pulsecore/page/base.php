<?php
namespace pulsecore\page;

/**
 * base class for pages
 */
class Base {
	
	/**
	 * constructor
	 */
	function __construct () {
	}
	
	/**
	 * CSRF tester
	 */
	protected function csrf_check( array $request_params ) {
		
		# CSRF
		if (!isset($request_params['csrf_token']) or !\pulsecore\session\csrf\verify_expire($request_params['csrf_token']) ) {
			\error_log( 'CSRF token mis-match: ' . $_SERVER['REQUEST_URI'] );
			exit;
		}
	}
	
	/**
	 * delete request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_delete( array $request_params, array $request_cookie ) {
		\pulsecore\invariant(false, 'request method not supported');
	}
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		\pulsecore\invariant(false, 'request method not supported');
	}
	
	/**
	 * post request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_post( array $request_params, array $request_cookie ) {
		\pulsecore\invariant(false, 'request method not supported');
	}
	
	/**
	 * put request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_put( array $request_params, array $request_cookie ) {
		\pulsecore\invariant(false, 'request method not supported');
	}
	
	/**
	 * generate html
	 * \param $param_get    array of get parameters
	 * \param $param_post   array of post parameters
	 * \param $param_cookie array of cookie parameters
	 * \param $request_method string the request method
	 * \return string
	 */
	public function process( array $param_get, array $param_post, array $param_cookie, $request_method ) {
		
		\pulsecore\pre_condition(      isset($request_method) );
		\pulsecore\pre_condition( \is_string($request_method) );
		\pulsecore\pre_condition(    \strlen($request_method) > 0);
		
		$request_params = \array_merge( $param_get, $param_post );
		
		$method = $request_method;
		
		#NB override if method is set in the request_params
		if (isset($request_params['method']) and \is_string($request_params['method']) and (\strlen(\trim($request_params['method'])) > 0)) {
			$method = $request_params['method'];
		}
		
		$method = \strtolower( \trim($method) );
		
		\pulsecore\invariant(      isset($method) );
		\pulsecore\invariant( \is_string($method) );
		\pulsecore\invariant(    \strlen($method) > 0);
		
		switch ($method) {
			
			case 'delete':
				$this->handle_delete( $request_params, $param_cookie );
				break;
			
			case 'get':
				$this->handle_get( $request_params, $param_cookie );
				break;
			
			case 'post':
				$this->handle_post( $request_params, $param_cookie );
				break;
			
			case 'put':
				$this->handle_put( $request_params, $param_cookie );
				break;
				
			default:
				\pulsecore\invariant(false, 'unknown request method');
		}
	}
}
