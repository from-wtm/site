<?php
namespace pulsecore\page\rss;

require_once (PULSE_BASE_DIR . '/pulsecore/wedge/blog_storage.php');

/**
 * end point for generating the rss xml
 * \param $param_get    array The GET parameters
 * \param $param_post   array The POST parameters
 * \param $param_cookie array The COOKIE data
 * \return string The processed html/text
 */
function process_page( array $param_get, array $param_post, array $param_cookie) {
	
	$view_model = new \pulsecore\ViewModel();
	
	$json_configs = \pulsecore\wedge\config\get_json_configs()->json;
	
	#basics
	$view_model->blog_description = $json_configs->blog_description;
	$view_model->blog_title       = $json_configs->blog_title;
	$view_model->blog_url         = $json_configs->blog_url;
	$view_model->rss_lang         = $json_configs->rss_lang;
	
	$view_model->path     = $json_configs->path;
	$view_model->protocol = isset($_SERVER['HTTPS']) ? 'https' : 'http';
	
	$blog_items = \pulsecore\store\blog\Base::list_blogs_only( \pulsecore\get_configs()->dir_content . "/blog" );
	
	$blog_entries = array();
	
	foreach ($blog_items as $blog) {
		
		$detected_date = \pulsecore\store\blog\Item::parse_date( $blog->date );
		$detected_date = $detected_date->format( \pulsecore\store\blog\Item::DATE_FORMAT_STORAGE );
		
		$date_explode = \explode('-', $detected_date );
		
		$item = new \stdClass();
		
		$item->month        = \intval(\ltrim($date_explode[0], '0'));
		$item->day          = \intval(\ltrim($date_explode[1], '0'));
		$item->year         = \intval(\ltrim($date_explode[2], '0'));
		
		$item->date_mk      = \mktime(0, 0, 0, $item->month, $item->day, $item->year);
		$item->date         = \date('r', $item->date_mk);
		$item->title        = $blog->title;
		$item->url_title    = $blog->relative_url;
		$item->content_blog = $blog->html;
		
		#expand internal tags
		$item->content_blog = \pulsecore\tag_runner\expand($item->content_blog);
		
		$blog_entries[ "{$item->year}{$item->month}{$item->day}_{$blog->id}" ] = $item;
	}
	
	\ksort( $blog_entries );
	
	$view_model->blog_entries = $blog_entries;
	
	#render
	\header('Content-type: text/xml');
	$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/rss.phtml' );
	$view->render( $view_model );
}
