<?php
namespace pulsecore\page\rss;

/**
 * blog rss
 */
class Blog extends \pulsecore\page\Base {
	
	/**
	 * get request
	 * \param $request_params array of request parameters
	 * \param $request_cookie array of cookie parameters
	 * \return string
	 */
	protected function handle_get( array $request_params, array $request_cookie ) {
		
		\pulsecore\pre_condition(      isset($request_params['d']) );
		\pulsecore\pre_condition( \is_string($request_params['d']) );
		\pulsecore\pre_condition(    \strlen($request_params['d']) > 0);
		
		$param_blog_name = $request_params['d'];
		$param_blog_name = \pulsecore\filter\blog_item_id( $param_blog_name );
		
		# build
		$view_model = new \pulsecore\ViewModel();
		
		$view_model->param_blog_name = $param_blog_name;
		
		$json_configs = \pulsecore\wedge\config\get_json_configs()->json;
		
		#basics
		$view_model->blog_description = $json_configs->blog_description;
		$view_model->blog_title       = $json_configs->blog_title;
		$view_model->blog_url         = $json_configs->blog_url;
		$view_model->rss_lang         = $json_configs->rss_lang;
		
		$view_model->path     = $json_configs->path;
		$view_model->protocol = isset($_SERVER['HTTPS']) ? 'https' : 'http';
		
		$roll = new \pulsecore\store\blog\Roll( \pulsecore\get_configs()->dir_content . "/blog/{$view_model->param_blog_name}" );
		
		$blog_entries = array();
		
		foreach ($roll->items(1, $roll->size()) as $blog) {
			
			$ddd = \pulsecore\store\blog\Item::parse_date($blog->date);
			$ddd = $ddd->format('Ymd');
			
			$blog_entries[ "{$ddd}_{$blog->id}" ] = $blog;
		}
		
		\ksort( $blog_entries );
		
		$view_model->blog_entries = $blog_entries;
		
		#render
		\header('Content-type: text/xml');
		$view = new \pulsecore\View( \pulsecore\get_configs()->dir_template . '/rss_blog.phtml' );
		$view->render( $view_model );
	}
}
