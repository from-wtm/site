<?php
namespace pulsecore\install;

/**
 * update the config file NB this expects a stock config file and updates it in place
 * \param $filename string The path to the config file to update
 * \param $params array of useful settings eg auto detected path
 * \return void
 */
function config_update( $filename, array $params ) {
	
	\pulsecore\pre_condition(      isset($filename) );
	\pulsecore\pre_condition( \is_string($filename) );
	\pulsecore\pre_condition(    \strlen($filename) > 0);
	
	\pulsecore\pre_condition(      isset($params['autodetected_path']) );
	\pulsecore\pre_condition( \is_string($params['autodetected_path']) );
	\pulsecore\pre_condition(    \strlen($params['autodetected_path']) >= 0);
	
	$content = \file_get_contents( $filename );
	
	$now = \date('YmdHis');
	
	# backup
	\file_put_contents( $filename . "_{$now}.bkup.php" , $content );
	
	# fix $path
	$content = \preg_replace( '/\$path(\s*)=(.+);(.+)/', '\$path$1=\'' . $params['autodetected_path'] . '\';$3', $content );
	
	# replace
	\file_put_contents( $filename, $content );
	
}

/**
 * update the .htaccess file NB this expects an existing .htaccess file and updates it in place
 * \param $filename string The path to the config file to update
 * \param $params array of useful settings eg auto detected path
 * \return void
 */
function config_update_htaccess( $filename, array $params ) {
	
	\pulsecore\pre_condition(      isset($filename) );
	\pulsecore\pre_condition( \is_string($filename) );
	\pulsecore\pre_condition(    \strlen($filename) > 0);
	
	\pulsecore\pre_condition(      isset($params['autodetected_path']) );
	\pulsecore\pre_condition( \is_string($params['autodetected_path']) );
	\pulsecore\pre_condition(    \strlen($params['autodetected_path']) >= 0);
	
	# params
	$autodetected_path = $params['autodetected_path'];
	$autodetected_path = \trim($autodetected_path);
	$autodetected_path = (\strlen($autodetected_path) == 0) ? '/' : $autodetected_path;
	
	# process
	$content = \file_get_contents( $filename );
	
	$now = \date('YmdHis');
	
	# backup
	\file_put_contents( $filename . "_{$now}.bkup.php" , $content );
	
	# fix $path
	$content = \preg_replace( '/RewriteBase(\s*)(.+)/', ('RewriteBase$1' . $autodetected_path), $content );
	
	# replace
	\file_put_contents( $filename, $content );
	
}

/**
 * update the config file NB this expects a stock config file and updates it in place
 * \param $filename string The path to the config file to update
 * \param $params array of useful settings eg auto detected path
 * \return void
 */
function config_update_json( $filename, array $params ) {
	
	\pulsecore\pre_condition(      isset($filename) );
	\pulsecore\pre_condition( \is_string($filename) );
	\pulsecore\pre_condition(    \strlen($filename) > 0);
	
	\pulsecore\pre_condition(      isset($params['autodetected_path']) );
	\pulsecore\pre_condition( \is_string($params['autodetected_path']) );
	\pulsecore\pre_condition(    \strlen($params['autodetected_path']) >= 0);
	
	# backup
	$now = \date('YmdHis');
	
	if (\file_exists($filename)) {
		
		$status = \copy( $filename, ($filename . "_{$now}.bkup") );
		
		\pulsecore\invariant( $status === true, 'Unable to backup configuration file prior to update');
	}
	
	# fix some settings
	$json = \pulsecore\wedge\config\load_config( $filename );
	
	# fix $path
	$json->path = $params['autodetected_path'];
	
	# pages not in the navigation list  ie new pages
	$json->navigation = \is_array($json->navigation) ? ((object)$json->navigation) : $json->navigation;
	
	$page_list = \pulsecore\generate_non_navigation_pages(
		$json->path,
		$json->navigation
	);
	$json->navigation = array('all' => $page_list);
	
	# replace
	\pulsecore\wedge\config\save_config( $json );
	
}