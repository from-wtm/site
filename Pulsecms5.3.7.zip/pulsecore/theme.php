<?php
namespace pulsecore\theme;

# ===========================================================================>
/**
 * themes
 * @return array
 */
function get_themes () : array {
	
	static $result = false;
	
	if ($result === false) {
		
		$list = \glob( \pulsecore\get_configs()->theme->base_dir . '/*' );
		
		$result = array('default');
		
		foreach ($list as $value) {
			
			$filename = \basename($value);
			
			if (!\in_array($filename, \pulsecore\get_configs()->theme->default_theme_content)) {
				
				$result[] = $filename;
			}
		}
	}
	
	return $result;
}
#############################################################################>
/**
 * load a theme file
 * @param string $theme The theme
 * @return string
 */
function load_theme (string $theme) : string {
	
	\pulsecore\pre_condition(      isset($theme) );
	\pulsecore\pre_condition( \is_string($theme) );
	\pulsecore\pre_condition(    \strlen($theme) > 0);
	
	$target = \pulsecore\get_configs()->theme->base_dir;
	
	# corner case - default theme
	if (\strcmp($theme, 'default') == 0) {
		$target .= "/layout.php";
		
	} else {
		
		$target .= "/{$theme}/layout.php";
	}
	
	#safety
	\pulsecore\invariant( \file_exists($target) );
	
	return $target;
}
# ===========================================================================>
