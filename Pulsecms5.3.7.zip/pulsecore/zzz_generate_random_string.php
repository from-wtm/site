<?php

require_once (PULSE_BASE_DIR . '/pulsecore/vendor/autoload.php');

/**
 * generate a random string 
 */
 
require_once (PULSE_BASE_DIR . '/pulsecore/bootstrap.php');

# load configs
require_once (PULSE_BASE_DIR . '/pulsecore/wedge/config.php');
\pulsecore\wedge\config\wedge_config();

$bytes = '';

for ($k = 0; $k < 16; $k++) {
	
	$bytes .= \chr( \mt_rand(0, 255) ); 
}

$bytes = \Base32\Base32::encode( $bytes );

echo ("random string:       " . \trim($bytes, '=') );
