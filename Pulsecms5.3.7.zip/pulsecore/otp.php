<?php
namespace pulsecore;

/**
 * basic OTP interface
 * @param string $acl_role
 * @return object
 */
function otp_get (string $acl_role) {
	
	\pulsecore\pre_condition(      isset($acl_role) );
	\pulsecore\pre_condition( \is_string($acl_role) );
	\pulsecore\pre_condition(    \strlen($acl_role) > 0);
	
	static $storage = array();
	
	$totp = false;
	
	if ($totp === false) {
		#new totp
		$totp = new \OTPHP\TOTP();
		$totp->setLabel( \pulsecore\get_configs()->otp->label    )
			->setDigits(   \pulsecore\get_configs()->otp->digits   )
			->setDigest(   \pulsecore\get_configs()->otp->digest   )
			->setInterval( \pulsecore\get_configs()->otp->interval )
			->setSecret(   \pulsecore\wedge\config\get_json_configs()->json->otp_shared_secret );
			
		#editors
		if ($acl_role == \pulsecore\get_configs()->acl_role->editor) {
			$totp->setSecret( \pulsecore\wedge\config\get_json_configs()->json->editor_user_otp_shared_secret );
		}
			
		$storage[$acl_role] = $totp;
		
	} else {
		#existing totp
		$totp = $storage[$acl_role];
	}
	
	return $totp;
}

/**
 * verify OTP password
 * @param string $otp_password
 * @param string $acl_role
 * @return bool
 */
function otp_verify_password (string $otp_password, string $acl_role) : bool {
	
	$totp = otp_get( $acl_role );
	
	$result = $totp->verify( $otp_password );
	
	return $result;
}
