<?php
namespace pulsecore\cache;

/**
 * manage a cache pools in common
 */
class Manager {
	
	/*
	 * some common timeout values
	 */
	const HOUR_1 =  3600; #    60*60
	const DAY_1  = 84600; # 24*60*60
	
	/*
	 * cache pools
	 */
	protected static $pools = array();
	
	/*
	 * create a cache manager
	 */
	public function __construct() {
	}
	
	/*
	 * get a pool for a given timeout
	 * \param $timeout integer
	 * \return object of Pool
	 */
	public function pool (int $timeout) : Pool {
		
		\pulsecore\pre_condition( \intval($timeout) > 0);
		
		if (!isset(Manager::$pools[$timeout])) {
			
			Manager::$pools[$timeout] = new Pool( $timeout );
		}
		
		return Manager::$pools[$timeout];
	}
}
