<?php
namespace pulsecore;

/**
 * dispatch a request 
 * @return array NB changes for GET array
 */
function dispatch (array $request_params, array $request_cookie) : array {
	
	$result = array();
	
	if (isset($request_params['p'])) {
		
		$page = $request_params['p'];
		
		$page = \pulsecore\filter\page( $page );
		
		# route blog prefix #RewriteRule ^blog-draft-([^-]*)+? ?d=draft-$1&p=blog [L,QSA]
		$blog_prefix = (\pulsecore\wedge\config\get_json_configs()->json->url_prefix . '-draft-');
		
		if (\stripos($page, $blog_prefix) === 0) {
			
			$result['p'] = 'blog';
			
			$result['d'] = \str_replace( $blog_prefix, '', $page);
			$result['d'] = \explode( '-', $result['d'] );
			$result['d'] = 'draft-' . $result['d'][0];
			
			return $result; #stop processing
		}
		
		# route blog prefix #RewriteRule ^blog-([^-]*)+? ?d=$1&p=blog [L,QSA]
		$blog_prefix = (\pulsecore\wedge\config\get_json_configs()->json->url_prefix . '-');
		
		if (\stripos($page, $blog_prefix) === 0) {
			
			$result['p'] = 'blog';
			
			$result['d'] = \str_replace( $blog_prefix, '', $page);
			$result['d'] = \explode( '-', $result['d'] );
			$result['d'] = $result['d'][0];
		}
		
		# route blog prefix #RewriteRule ^blog-page-([^-]*)$ ?page=$1&p=blog [L,QSA]
		$blog_prefix = (\pulsecore\wedge\config\get_json_configs()->json->url_prefix . '-page');
		
		if (\stripos($page, $blog_prefix) === 0) {
			
			$result['p'] = 'blog';
			
			$result['d'] = \str_replace( $blog_prefix, '', $page);
			$result['d'] = \explode( '-', $result['d'] );
			$result['d'] = $result['d'][0];
		}
		
		# route blog rss
		$matches = array();
		
		if (\preg_match('/^([\p{L}\p{N}_]+)\/rss$/', $page, $matches) === 1) {
			
			$result['p'] = 'rss_blog';
			
			$result['d'] = $matches[1];
		}
		
		# route for meta web blog API
		if (\stripos($page, 'web-blog-api') === 0) {
			$page = new \pulsecore\page\WebBlogApi( \pulsecore\get_configs()->web_blog_api->log_flag );
			
			echo $page->process(
				array(),
				$request_params,
				$request_cookie,
				(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'get')
			);
			exit;
		}
		
		# general routes
		$routes = array(
			new \pulsecore\route\BlogItem()
		);
		
		foreach ($routes as $rrr) {
			
			list($status, $route_params) = $rrr->match($page, $request_params, $request_cookie);
			
			if ($status === true) {
				return $rrr->dispatch($page, $route_params, $request_params, $request_cookie);
			}
		}
	}
	
	return $result;
}
