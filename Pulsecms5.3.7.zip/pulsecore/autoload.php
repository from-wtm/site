<?php
namespace pulsecore;

/**
 * autoload PHP classes
 * \param $classname string classname to load
 */
function autoloader( $classname) {
	
	# import the class map
	static $classmap = false;
	
	if ($classmap === false) {
		$classmap = require_once (PULSE_BASE_DIR . '/pulsecore/autoload_classmap.php');
	}
	
	# autoload the class name
	if (isset($classmap[$classname])) {
		require_once ($classmap[$classname]);
	} else {
		throw new \LogicException( "Cannot autoload {$classname}" );
	}
}

# register the autoloader
\spl_autoload_register( '\pulsecore\autoloader' );

/**
 * bootstrap the extra code for pulse cms - autoload vendor library
 */
require_once (PULSE_BASE_DIR . '/pulsecore/vendor/autoload.php');
