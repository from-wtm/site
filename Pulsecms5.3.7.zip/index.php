<?php

\error_reporting(\E_STRICT|\E_ALL);

require_once (__DIR__ . '/symlink_safe.php');

require_once (PULSE_BASE_DIR . "/config.php");
require_once (PULSE_BASE_DIR . "/{$admin}/inc/lang/english.php");

if (!empty($language) and \file_exists(PULSE_BASE_DIR . "/{$admin}/inc/lang/{$language}.php")) {
	require_once( PULSE_BASE_DIR . "/{$admin}/inc/lang/{$language}.php");
}

# \error_log( 'Load config + translation' ); # debug message

# ===========================================================================>
/**
 * wedge in the updated blog storage logic from pulsecore
 */
# start the session
\pulsecore\session\start();

# route requests as needed = NB get var changed here
$delta_get_vars = \pulsecore\dispatch( \array_merge($_GET, $_POST), $_COOKIE );
$_GET = \array_merge( $_GET, $delta_get_vars );

# special case - rss blog page
if (isset($_GET['p']) and ($_GET['p'] == 'rss_blog')) {
	$pulsecore_page = new \pulsecore\page\rss\Blog();
	$pulsecore_page->process( $_GET, $_POST, $_COOKIE, (isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'get') );
	exit;
}

# ===========================================================================>

$page = (isset($_GET['p']) && !empty($_GET['p'])) ? $_GET['p'] : \pulsecore\wedge\config\get_json_configs()->json->home_page;
$page = htmlspecialchars($page, ENT_QUOTES, 'UTF-8');

#==> begin wedge <==
#filter/clean incoming page parameter
$page = \pulsecore\filter\page( $page );

# check for cache entry - no caching for logged in users - no caching form posts
if (    !(\pulsecore\acl_role\is_administrator() or \pulsecore\acl_role\is_editor())
	   and (\pulsecore\wedge\config\get_json_configs()->json->cache_html_enable === true)
	   and (\sizeof($_POST) == 0)
	 ) {
	$cache_manager = new \pulsecore\cache\Manager();
	$cache_pool    = $cache_manager->pool( \pulsecore\cache\Manager::DAY_1 );
	
	$cache_item_name = "page-name-{$page}-" . \print_r($_GET, true);
	
	if ($cache_pool->is_valid($cache_item_name)) {
		echo $cache_pool->get($cache_item_name);
		exit;
	}
}

# meta tags
if (\pulsecore\wedge\config\get_json_configs()->json->theme_meta_author_show) {
	\pulsecore\get_context()->theme->meta->add( 'author', 'PulseCMS' );
}

# fitvids
\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/vendor/node_modules/vanilla-fitvids/jquery.fitvids.js', array(), 'fitvids' );
\pulsecore\get_context()->theme->js_body->add_inline(
	'fitvid-body',
<<<EOD
	jQuery(document).ready(
		function() {
			window.setTimeout(
				function() {
					jQuery("video").parent().fitVids();
					jQuery('iframe[src*="youtube"]').parent().fitVids();
				},
			);
		}
	);
EOD
	,
	array('fitvids')
);

# inline edit includes js/css
if (\pulsecore\acl_role\is_administrator() or \pulsecore\acl_role\is_editor() ) {
	
	$base_url = \pulsecore\wedge\config\get_json_configs()->json->path;
	
	# font awesome
	\pulsecore\get_context()->theme->css->add( PULSE_BASE_URL . '/pulsecore/asset/vendor/fontawesome/css/all.min.css', array() );
	
	# vue
	\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/vendor/node_modules/vue/dist/vue.min.js', array(), 'vue' );
	\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/vendor/node_modules/vue-resource/dist/vue-resource.min.js', array( 'vue' ) );
	
	# Redactor II
	\pulsecore\get_context()->theme->css->add( PULSE_ADMIN_URL . '/redactor/redactor.min.css',            array(), 'redactor' );
	\pulsecore\get_context()->theme->css->add( PULSE_ADMIN_URL . '/redactor/plugins/clips.min.css',       array('redactor') );
	\pulsecore\get_context()->theme->css->add( PULSE_ADMIN_URL . '/redactor/plugins/filemanager.min.css', array('redactor') );
	\pulsecore\get_context()->theme->css->add( PULSE_ADMIN_URL . '/redactor/plugins/inlinestyle.min.css', array('redactor') );
	#\pulsecore\get_context()->theme->css->add( PULSE_ADMIN_URL . '/codemirror/codemirror.css',            array('redactor') );
	
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/redactor.min.js', array(), 'redactor' );
	
	# Redactor Plugins - source.js is the old HTML viewer - replaced in favour to codemirror
	# \pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/source.js', array( PULSE_ADMIN_URL . '/redactor/redactor.min.js' ) );
	
	# \pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/codemirror/codemirror.min.js', array( 'redactor' ) );
	# \pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/codemirror/xml/xml.js',        array( 'redactor' ) );
	
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/alignment.min.js',     array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/clips.min.js',         array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/filemanager.min.js',   array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/fontcolor.min.js',     array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/fontfamily.min.js',    array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/fontsize.min.js',      array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/fullscreen.min.js',    array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/imagemanager.min.js',  array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/inlinestyle.min.js',   array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/properties.min.js',    array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/table.min.js',         array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/textdirection.min.js', array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/video.min.js',         array( 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/widget.min.js',        array( 'redactor' ) );
	
	
	# \pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/codemirror.js',    array( 'redactor' ) );
	# \pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/plugins/snippets.js',      array( 'redactor' ) );
	
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/mail.js',      array( 'redactor' ) );
	
	$lang_code = \pulsecore\language_to_iso( $language );
	
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/lang/{$lang_code}.js", array( 'redactor' ) );
	
	\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . "/redactor/lang.pulse.js", array( 'redactor' ) );
	
	$sweetalert_active  = \pulsecore\wedge\config\get_json_configs()->json->sweetalert->active;
	$sweetalert_timeout = \pulsecore\wedge\config\get_json_configs()->json->sweetalert->timeout;
	
	$sweetalert_active  = \intval( $sweetalert_active );
	$sweetalert_timeout = \intval( $sweetalert_timeout );
	
	$js_redactor_inline_lang =<<<EOD
	window.pulsecore = window.pulsecore || {};
	pulsecore.alert = {
		active:  {$sweetalert_active},
		timeout: {$sweetalert_timeout}
	};
	window.pulsecore.lang       = "{$language}";
	window.pulsecore.lang_short = "{$lang_code}";
EOD;
	
	\pulsecore\get_context()->theme->js_body->add_inline( 'redactor-inline-lang', $js_redactor_inline_lang );
	
	\pulsecore\get_context()->theme->js_body->add_inline( 'translations',         \pulsecore\get_context()->theme->translations->render() );
	
	#Redactor Initialisation on #wysiwyg -->
	#\pulsecore\get_context()->theme->js_body->add( PULSE_ADMIN_URL . '/redactor/redactor_init.js', array() );
}

# inject page level css/js from settings
if (\strlen(\pulsecore\wedge\config\get_json_configs()->json->inline->css) > 0) {
	\pulsecore\get_context()->theme->css->add_inline(     'page_css', \pulsecore\wedge\config\get_json_configs()->json->inline->css );
}
if (\strlen(\pulsecore\wedge\config\get_json_configs()->json->inline->js) > 0) {
	\pulsecore\get_context()->theme->js_body->add_inline( 'page_js',  \pulsecore\wedge\config\get_json_configs()->json->inline->js  );
}
#==> end wedge   <==

if (preg_match("/\//", $page)){ 
    if(file_exists("content/pages/".$page."home.txt")){
        $page = $page."home";
    } 
}

if (!file_exists("content/pages/".$page.".txt")) {
    $page = '404';
    header('HTTP/1.1 404 Not Found');
}

# set the CORS header
\header( 'Access-Control-Allow-Origin: *' ); # CORS

# disable parsedown for inline edit mode 
if (!\pulsecore\acl_role\is_administrator() and !\pulsecore\acl_role\is_editor()) {
	require_once (PULSE_BASE_DIR . '/inc/plugins/parsedown.php');
	$parsedown = new \Parsedown();
}

# parse the page storage
$page_datum = new \pulsecore\store\page\Item();
$page_datum->load( "content/pages/{$page}.txt" );

$page_title   = $page_datum->title;
$page_desc    = $page_datum->description;
$content      = $page_datum->html;
$new_template = $page_datum->page_template;

# access control for user groups and logged in members
if (\pulsecore\acl_role\user_group_test_resource_controlled("pages/{$page}")) {
	
	$allow_access = false;
	
	# admins and editors always have access
	$allow_access = ($allow_access or \pulsecore\acl_role\is_administrator() or \pulsecore\acl_role\is_editor());
	
	# check logged in user permissions
	if ((!$allow_access) and \pulsecore\acl_role\test_logged_in()) {
		$allow_access = ($allow_access or \pulsecore\acl_role\user_group_test_user_allowed("pages/{$page}", 'r', $_SESSION['user_group_list']));
	}
	
	# skip page if no access allowed
	if (!$allow_access) {
		\pulsecore\session\status_add( $GLOBALS['lang_settings_user_group_list_access_denied'] );
		
		\header( "Location: {$GLOBALS['path']}/" );
		exit;
	}
}

# inline edit
if (\pulsecore\acl_role\can_edit_resource( \pulsecore\wedge\config\get_json_configs()->json->navigation_options->logged_in_menu )) {
	
	# widget - inline edit
	\pulsecore\get_context()->theme->css->add( PULSE_BASE_URL . '/pulsecore/asset/js/widget/inline-edit/inline-edit.css', array() );
	
	\pulsecore\get_context()->theme->js_body->add_inline( 'page_js', "window.pulsecore = window.pulsecore || {}; window.pulsecore.base_url = \"" . PULSE_BASE_URL . "\"; window.pulsecore.admin_url = \"" . PULSE_ADMIN_URL . "\";window.pulsecore.inline_edit = {app: {}, component: {}};" );
	\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/js/widget/inline-edit/message-bus.js', array( 'vue', 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/js/widget/inline-edit/content.js',     array( 'vue', 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/js/widget/inline-edit/global-save.js', array( 'vue', 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/js/widget/inline-edit/modal.js',       array( 'vue', 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/js/widget/inline-edit/toolbar.js',     array( 'vue', 'redactor' ) );
	\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/js/widget/inline-edit/inline-edit.js', array( 'vue', 'redactor' ), 'inline-edit' );
	
	$view_helper_inline_edit = new \pulsecore\view\helper\InlineEdit();
	$content = $view_helper_inline_edit->render( array($page, 'page', $content) );
}

# meta
if (\strlen($page_datum->meta_custom_description) > 0) {
	#\pulsecore\get_context()->theme->meta->add( 'custom_meta', $page_datum->meta_custom_description );
	\pulsecore\get_context()->theme->meta->add( 'description', $page_datum->meta_custom_description );
} else {
	\pulsecore\get_context()->theme->meta->add( 'description', $page_datum->description );
}

$meta_robots   = array();
$meta_robots[] = ($page_datum->meta_indexed   == 'yes') ? 'index'   : 'noindex';
$meta_robots[] = ($page_datum->meta_no_follow == 'yes') ? 'nofollow': 'follow';

$meta_robots = \implode(',', $meta_robots ); 

\pulsecore\get_context()->theme->meta->add( 'robots', $meta_robots );

# inject page data into context storage
\pulsecore\get_context()->state->page = new \stdClass();
\pulsecore\get_context()->state->page->page_title     = (isset($page_title) ? $page_title : '');
\pulsecore\get_context()->state->page->page_desc      = (isset($page_desc ) ? $page_desc  : '');
\pulsecore\get_context()->state->page->page_body      = (isset($content   ) ? $content    : '');
\pulsecore\get_context()->state->page->path           = (isset($path      ) ? $path       : '/');
\pulsecore\get_context()->state->page->location       = $page_datum->get_location();
\pulsecore\get_context()->state->page->created_on     = $page_datum->created_on;
\pulsecore\get_context()->state->page->modified_on    = $page_datum->modified_on;
\pulsecore\get_context()->state->page->page_info_url  = \pulsecore\page_info_url($_SERVER['REQUEST_URI'], \pulsecore\wedge\config\get_json_configs()->json->url_prefix);
\pulsecore\get_context()->state->page->page_info_blog = \pulsecore\page_info_blog( \pulsecore\get_context()->state->page->page_info_url, \pulsecore\wedge\config\get_json_configs()->json->url_prefix );

# page inline css/js
if (\strlen($page_datum->inline_css) > 0) {
	\pulsecore\get_context()->theme->css->add_inline(     'per_page_css', $page_datum->inline_css );
}
if (\strlen($page_datum->inline_js) > 0) {
	\pulsecore\get_context()->theme->js_body->add_inline( 'per_page_js',  $page_datum->inline_js );
}

# page language setting
if (\strlen($page_datum->meta_language) > 0) {
	\pulsecore\get_context()->theme->language->set($page_datum->meta_language);
}

# expand page content to get the list of css/js resources to load
$content = \pulsecore\tag_runner\expand( $content );

/*
if (preg_match_all("/".'(\\{)'.'(\\{)'.'.*?'.'(\\})'.'(\\})'."/", $content, $m)) {
    
			foreach ($m[0] as $get_embed1) {
				
				# reset the tag variables
				$tag_var1 = '';
				$tag_var2 = '';
				$tag_var3 = '';
				
        $get_embed = $get_embed1;
        $get_embed = str_replace("{", "" ,$get_embed); 
        $get_embed = str_replace("}", "" ,$get_embed);  
                  
        if (substr_count($get_embed, ':') >=1 ) {                        
            $exp = explode(':', $get_embed); 
            $vars = array_slice($exp, 1); 
            $tag_var1 = (!empty($vars[0])) ? $vars[0] : '';
            $tag_var2 = (!empty($vars[1])) ? $vars[1] : '';
            $tag_var3 = (!empty($vars[2])) ? $vars[2] : '';
            $tag_var4 = (!empty($vars[3])) ? $vars[3] : '';
            $tag_var5 = (!empty($vars[4])) ? $vars[4] : '';
            $tag_var6 = (!empty($vars[5])) ? $vars[5] : '';
            $tag_var7 = (!empty($vars[6])) ? $vars[6] : '';
            $get_embed = $exp[0];
        }
        
        #replace a block with its content
        \ob_start(); 
        if ($get_embed == 'template') {
        	$new_template = $tag_var1;
        	$new          = '';
        } else {
        	#filter
        	$get_embed = \pulsecore\filter\item_url( $get_embed );
        	
        	include (PULSE_BASE_DIR . "/inc/tags/{$get_embed}.php");
        	$new = \ob_get_contents();
        }
        $content = \str_replace($get_embed1, $new, $content);
        \ob_end_clean();
    }
}
*/

\ob_start();
if (!empty($new_template) and \file_exists("template/{$new_template}/layout.php")) { 
    #include ("template/{$new_template}/layout.php");
    include (\pulsecore\theme\load_theme($new_template));
    
} else if (!empty($new_template) and ($new_template == 'default') and \file_exists("template//layout.php")) { 
    #include ("template/layout.php");
    include (\pulsecore\theme\load_theme('default'));

} else { 
    #include("template/layout.php");
    $default_theme_selected = (isset(\pulsecore\wedge\config\get_json_configs()->json->theme_selected) ? \pulsecore\wedge\config\get_json_configs()->json->theme_selected : 'default');
    include(\pulsecore\theme\load_theme($default_theme_selected));
}
$content = \ob_get_contents();
\ob_end_clean();

# expand the layout tags
$content = \pulsecore\tag_runner\expand( $content );

# inject google analytics into the html
if (\strlen(\trim(\pulsecore\wedge\config\get_json_configs()->json->google_analytics)) > 0) {
	$content = \str_replace('<!-- GOOGLE ANALYTICS -->', \pulsecore\wedge\config\get_json_configs()->json->google_analytics, $content);
}

# inject OGP content into the html
/*
include_once (PULSE_BASE_DIR . '/inc/plugins/ogp.php');
\ob_start();
ogp_render();
$capture_ogp = \ob_get_contents();
\ob_end_clean();
if (\strlen(\trim($capture_ogp)) > 0) {
	$content = \str_replace('<!-- OGP PLACEHOLDER -->', $capture_ogp, $content);
}
*/
$content = \str_replace(
	'<!-- OGP PLACEHOLDER -->',
	\pulsecore\tags\SocialExposure::execute_tag( array(), array() ),
	$content
);

# save in cache
if (    !(\pulsecore\acl_role\is_administrator() or \pulsecore\acl_role\is_editor())
	   and (\pulsecore\wedge\config\get_json_configs()->json->cache_html_enable === true)
	   and (\sizeof($_POST) == 0)
	  ) {
	$cache_pool->set($cache_item_name, $content, array('page') );
}

# write content to stdout
# \error_log( "write html" ); # debug message
# \error_log( print_r(headers_list(), true) );
# \error_log( $content ); # debug message

echo $content;
exit;
