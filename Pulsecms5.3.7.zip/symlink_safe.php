<?php

/**
 * this shows the symlinked directory for the PHP script in the URL So different for admin directory
 * NB __DIR__ value after symlink resolved
 */
define( 'PULSE_SYMLINK_SAFE_SCRIPT_DIR', \dirname($_SERVER['SCRIPT_FILENAME']) );

/**
 * Top level base dir - where the index.php and .htaccess are
 *
define(
	'PULSE_BASE_DIR',
	( ( (\stripos(PULSE_SYMLINK_SAFE_SCRIPT_DIR, '/admin/inc') !== false)
		  ? \dirname( \dirname(PULSE_SYMLINK_SAFE_SCRIPT_DIR) )
		  : ( (\stripos(PULSE_SYMLINK_SAFE_SCRIPT_DIR, '/admin') !== false)
		      ? \dirname( PULSE_SYMLINK_SAFE_SCRIPT_DIR )
		      : PULSE_SYMLINK_SAFE_SCRIPT_DIR
		     )
		)
	)
);
*/

/**
 * detect the symlinked directory for the PHP script
 * works off fact that the top level directory has symlink_safe.php in it
 * side effect is to set the PULSE_BASE_DIR define constant
 * \param $current_directory string
 * \return void
 */
function detect_symlink_safe_directories ($current_directory) {
	
	if (\file_exists("{$current_directory}/symlink_safe.php")) {
		\define( 'PULSE_BASE_DIR', $current_directory );
		
	} else {
		# test the parent directory next
		detect_symlink_safe_directories( \dirname($current_directory) );
	}
}

# autodectect
detect_symlink_safe_directories( PULSE_SYMLINK_SAFE_SCRIPT_DIR );
