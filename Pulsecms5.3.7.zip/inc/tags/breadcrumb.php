<?php

/**
 * display breadcrumbs
 * \param $tag_runner_context array Extra content to provide to tags
 */
function tag_breadcrumb( array $tag_runner_context = array() ) {
	
	$tag = new \pulsecore\tags\Breadcrumb();
	
	echo $tag->generate_html(
		array(
		),
		$tag_runner_context,
		((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
	);
	
}

# call
tag_breadcrumb();
