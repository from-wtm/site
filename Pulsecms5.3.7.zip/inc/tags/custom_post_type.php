<?php

/**
 * custom post type block
 */
echo \pulsecore\tags\CustomPostType::execute_tag(
	array(
		'url_base_path'        => $GLOBALS['path'],
		'custom_post_location' => $GLOBALS['tag_var1'],
		'arg2'                 => (isset($GLOBALS['tag_var2']) ? $GLOBALS['tag_var2'] : ''),
		'arg3'                 => (isset($GLOBALS['tag_var3']) ? $GLOBALS['tag_var3'] : '')
	),
	(isset($tag_runner_context) ? $tag_runner_context : array()),
	((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
);
