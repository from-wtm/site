<?php

/**
 * allow mailchimp loading using the old tag parser
 */
require_once (__DIR__ . '/../../pulsecore/tags/mailchimp.php');
