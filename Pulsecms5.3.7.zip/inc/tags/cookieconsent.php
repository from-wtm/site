<?php
/**
 * cookie consent popup
 */

echo \pulsecore\tags\CookieConsent::execute_tag(
	array(
		'pbackground' => $GLOBALS['tag_var1'],
		'bbackground' => $GLOBALS['tag_var2'],
		'theme'       => $GLOBALS['tag_var3'],
		'position'    => $GLOBALS['tag_var4'],
		'href'        => $GLOBALS['tag_var5']
	),
	(isset($tag_runner_context) ? $tag_runner_context : array()),
	((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
);
