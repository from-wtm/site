<?php


# recapcha
if (       isset(\pulsecore\wedge\config\get_json_configs()->json->recapcha_site_key)
	  and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->recapcha_site_key) > 0)
	  and    isset(\pulsecore\wedge\config\get_json_configs()->json->recapcha_secret_key)
	  and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->recapcha_secret_key) > 0)) {
	
	 \pulsecore\get_context()->theme->js->add('https://www.google.com/recaptcha/api.js');
}

#create if needed
$errors = (isset($errors) and \is_array($errors)) ? $errors : array();

#initialisation
$success = false;
$text    = '';

if (     isset($_POST['submit']) and empty($_POST['human'])
	  and (isset($_SESSION['form_email_allowed_token']) and ($_SESSION['form_email_allowed_token'] == true))) {
	
	$flag_recapcha_ok = true;
	
	# recapcha verification step
	if (     isset(\pulsecore\wedge\config\get_json_configs()->json->recapcha_site_key)
	  and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->recapcha_site_key) > 0)
	  and    isset(\pulsecore\wedge\config\get_json_configs()->json->recapcha_secret_key)
	  and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->recapcha_secret_key) > 0)) {
		
		$curl_post_data = array(
			'secret'   => \pulsecore\wedge\config\get_json_configs()->json->recapcha_secret_key,
			'response' => $_POST['g-recaptcha-response'],
			'remoteip' => $_SERVER['REMOTE_ADDR']
		);
		
		$curl_handle = \curl_init( 'https://www.google.com/recaptcha/api/siteverify' );
		
		\curl_setopt($curl_handle, CURLOPT_POST, 1);
		\curl_setopt($curl_handle, CURLOPT_SAFE_UPLOAD, false); # required as of PHP 5.6.0
		\curl_setopt($curl_handle, CURLOPT_POSTFIELDS, $curl_post_data);
		\curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, true );
		
		# dangerous - makes request insecure
		# workaround for "Curl error: SSL certificate problem: unable to get local issuer certificate"
		#\curl_setopt($curl_handle, \CURLOPT_SSL_VERIFYPEER, false); 
		
		$status = \curl_exec($curl_handle);
		
		$curl_error = \curl_error($curl_handle);
		
		\curl_close($curl_handle);
		
		\pulsecore\invariant(($status !== false), "Curl error detected: {$curl_error}" );
		
		$unpacked = \json_decode( $status );
		
		if ($unpacked->success !== true) {
			
			$flag_recapcha_ok = false;
			
			$errors[] = 'reCAPCHA failed';
		}
	}
	
	if ($flag_recapcha_ok === true) {
		# clear email token
		$_SESSION['form_email_allowed_token'] = false;
		
		$merge_tester = \array_merge(
			((array)\pulsecore\wedge\config\get_json_configs()->json->mail_inputs),
			((array)\pulsecore\wedge\config\get_json_configs()->json->mail_textarea)
		);
		
		foreach ($merge_tester as $field => $type) {
			$raw_field = $field;
			$field = \str_replace(" ", "_", $field);
			
			if (!isset($_POST[$field]) or empty($_POST[$field]) or (\strlen(\trim($_POST[$field])) < 1) ) {
				$field = \str_replace("_", " ", $field);
				$errors[] = $GLOBALS['lang_form_error1'] . $field;
			}	
			if (\strlen($_POST[$field]) > 1000) {
				$field = \str_replace("_", " ", $field);
				$errors[] = $GLOBALS['lang_form_error2a']. $field . $GLOBALS['lang_form_error2b'];
			}
			if (($raw_field == \pulsecore\wedge\config\get_json_configs()->json->lang_form_email) and (filter_var($_POST[$field], \FILTER_VALIDATE_EMAIL) == false)) {
				$errors[] = $GLOBALS['lang_form_error1'] . $raw_field;
			}
		}
		
		#deduplicate
		$errors = \array_unique($errors);
		
		if (empty($errors)) {
			foreach ($merge_tester as $field => $type) {
				$field1    = \str_replace(" ", "_", $field);
				$submitted = \trim($_POST[$field1]);
				
				if ($field == \pulsecore\wedge\config\get_json_configs()->json->lang_form_name) {
					$sender_name = $submitted;
	
				} else if ($field == \pulsecore\wedge\config\get_json_configs()->json->lang_form_email) {
					$sender_email = $submitted;
	
				} else {
					$text .= $field .': '. $submitted."\n\n"; 
				}
			}
			
			$mail = new \PHPMailer\PHPMailer\PHPMailer();
		
			if (    (\strlen(\pulsecore\wedge\config\get_json_configs()->json->smtp_host    ) > 0)
					and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->smtp_username) > 0)
					and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->smtp_password) > 0)
					and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->smtp_port    ) > 0)
				) {
					// If your host requires smtp authentication, uncomment and fill out the lines below. 
					$mail->isSMTP();                                                                      // Do nothing here
					$mail->Host       = \pulsecore\wedge\config\get_json_configs()->json->smtp_host;      // Specify main server
					$mail->SMTPAuth   = true;                                                             // Do nothing here
					$mail->Username   = \pulsecore\wedge\config\get_json_configs()->json->smtp_username;  // SMTP username
					$mail->Password   = \pulsecore\wedge\config\get_json_configs()->json->smtp_password;  // SMTP password
					$mail->Port       = \pulsecore\wedge\config\get_json_configs()->json->smtp_port;      // SMTP port 	
					$mail->SMTPSecure = 'tls';                                                            // Enable encryption, 'ssl' also accepted
			}
			
			$mail->From     = $sender_email;
			$mail->FromName = $sender_name;
			foreach (\pulsecore\wedge\config\get_json_configs()->json->email_contact as $email_address) {
				$mail->addAddress($email_address);
			}
			$mail->Subject  = (isset(\pulsecore\wedge\config\get_json_configs()->json->config_contact_form_subject_line) ? \pulsecore\wedge\config\get_json_configs()->json->config_contact_form_subject_line : $GLOBALS['lang_form_subject_line']);
			$mail->Body     = $text;
							
			if ($mail->send()) {
				echo "\n<p class='green'>{$GLOBALS['lang_form_email_sent']}</p>\n";
				
				if (\pulsecore\wedge\config\get_json_configs()->json->config_contact_form_auto_thank) {
					echo "\n<p class='green'>{$GLOBALS['lang_auto_thank_contact']}</p>\n";
				}
				
				$success = true;
				unset($mail,$merge_tester);
				
				# handle optional redirect
				if (($success === true) and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->contact_form_redirect) > 0)) {
					\header( 'Location: ' . \pulsecore\wedge\config\get_json_configs()->json->contact_form_redirect );
					exit;
				}
			}
		}
	}
}

if (!empty($errors) or (isset($success) and ($success == false))) {
	if (!empty($errors)) {
		echo "\n";
		foreach($errors as $error){
			echo "<p>{$error}</p>\n";
		}
	}
	
	# set email token to allow email to be sent
	$_SESSION['form_email_allowed_token'] = true;
	
	$form_inputs = array();
	
	$form_inputs[] = (object)array(
		'key'   => 'Name',
		'label' => \pulsecore\wedge\config\get_json_configs()->json->lang_form_name,
		'id'    => \str_replace(' ', '_', \pulsecore\wedge\config\get_json_configs()->json->lang_form_name),
		'type'  => \pulsecore\wedge\config\get_json_configs()->json->mail_inputs->Name,
	);
	
	$form_inputs[] = (object)array(
		'key'   => 'Email',
		'label' => \pulsecore\wedge\config\get_json_configs()->json->lang_form_email,
		'id'    => \str_replace(' ', '_', \pulsecore\wedge\config\get_json_configs()->json->lang_form_email),
		'type'  => \pulsecore\wedge\config\get_json_configs()->json->mail_inputs->Email
	);
	
	$form_inputs[] = (object)array(
		'key'   => 'Phone',
		'label' => \pulsecore\wedge\config\get_json_configs()->json->lang_form_phone,
		'id'    => \str_replace(' ', '_', \pulsecore\wedge\config\get_json_configs()->json->lang_form_phone),
		'type'  => \pulsecore\wedge\config\get_json_configs()->json->mail_inputs->Phone
	);
	
	$form_inputs[] = (object)array(
		'key'   => 'Comment',
		'label' => \pulsecore\wedge\config\get_json_configs()->json->lang_form_comment,
		'id'    => \str_replace(' ', '_', \pulsecore\wedge\config\get_json_configs()->json->lang_form_comment),
		'type'  => 'textarea'
	);
	
	if (\pulsecore\wedge\config\get_json_configs()->json->gdpr->enable_in_form) {
		$form_inputs[] = (object)array(
			'key'      => 'GDPR',
			'label'    => \pulsecore\wedge\config\get_json_configs()->json->lang_form_gdpr,
			'id'       => \str_replace(' ', '_', \pulsecore\wedge\config\get_json_configs()->json->lang_form_gdpr),
			'type'     => 'checkbox',
			'required' => true
		);
	}
	
?>


<form id="contact" method="post" action="">
	
	<?php foreach ($form_inputs as $value) { ?>
		<?php if ($value->key !== 'Comment') { ?>
			<label><?php echo \htmlentities($value->label); ?></label>
			<input id="<?php echo \htmlentities($value->key); ?>" name="<?php echo \htmlentities($value->key); ?>" type="<?php echo \htmlentities($value->type); ?>" value="<?php echo \htmlentities(isset($_POST[$value->key]) ? $_POST[$value->key] : null); ?>" <?php echo ((isset($value->required) and $value->required) ? 'required' : '' ); ?> />
			<br />
		<?php } else { ?>
			
			<label><?php echo \htmlentities($value->label); ?></label>
			<textarea name="<?php echo \htmlentities($value->key); ?>" id="<?php echo \htmlentities($value->key); ?>" rows="<?php echo \htmlentities(\pulsecore\wedge\config\get_json_configs()->json->mail_textarea->{$value->key}); ?>" ><?php echo \htmlentities(\trim(isset($_POST[$value->key]) ? $_POST[$value->key] : null)); ?></textarea>
			<br />
		<?php } ?>
	<?php } ?>
	
	<input id="human" name="human" type="text"  value="<?php echo (isset($_POST['human']) ? $_POST['human'] : null);?>" /> 
	<button name="submit" type="submit"><?php echo $GLOBALS['lang_form_sent_button']; ?></button>
	
	<?php if (       isset(\pulsecore\wedge\config\get_json_configs()->json->recapcha_site_key)
	  and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->recapcha_site_key) > 0)
	  and    isset(\pulsecore\wedge\config\get_json_configs()->json->recapcha_secret_key)
	  and (\strlen(\pulsecore\wedge\config\get_json_configs()->json->recapcha_secret_key) > 0)) { ?>
	
		<div class="g-recaptcha" data-sitekey="<?php echo \pulsecore\wedge\config\get_json_configs()->json->recapcha_site_key; ?>"></div>
	<?php } ?>
	
</form>

<?php } ?>
<link rel="stylesheet" href="<?php echo \pulsecore\wedge\config\get_json_configs()->json->path; ?>/inc/tags/css/form.css" />
