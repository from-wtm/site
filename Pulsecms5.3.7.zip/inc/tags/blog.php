<?php

# css
\pulsecore\get_context()->theme->css->add( \pulsecore\wedge\config\get_json_configs()->json->path . '/inc/tags/css/blog.css', array() );

# prefix
if (!empty($tag_var1)) { $blog_prefix = $url_prefix; } else { $blog_prefix = 'blog'; }

# layout
if (empty($tag_var2)) {
	$tag_var2 = \pulsecore\get_configs()->default_content->blog->layout;
}

# 
if (isset($_GET['d'   ]) and \is_string($_GET['d'   ])) { $get_id   = $_GET['d']; }
if (isset($_GET['page']) and \is_string($_GET['page'])) { $cur_page = $_GET['page']; }

# no blog ITEM id so must be full blog
if (empty($get_id)) {
	# handle blog layout
	$tag_blog = new \pulsecore\tags\Blog();
	
	echo $tag_blog->generate_html(
		array(
			'layout' => $tag_var2
		),
		array(
			'blog_name'    => (isset($_GET['blog_name']    ) ? $_GET['blog_name']     : ''),
			'filter_tag'   => (isset($_GET['blog_tag_name']) ? $_GET['blog_tag_name'] : ''),
			'flag_reverse' => \pulsecore\wedge\config\get_json_configs()->json->blog_flag_reverse,
			'hide_draft'   => true
		),
		((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0))
			? \trim($GLOBALS['tag_composite_content'])
			: '' #\pulsecore\get_configs()->default_content->blog->layout
		)
	);
	
} else if (isset($get_id) and \is_string($get_id) and (\strlen($get_id) > 0)) {
	# show one post
	$get_id = \pulsecore\filter\blog_item_id($get_id);
	
	$blog_filename = \pulsecore\get_configs()->dir_content . '/blog/' . $get_id . '.txt';
	
	\pulsecore\invariant( \file_exists($blog_filename) );
	
	$blog_datum = new \pulsecore\store\blog\Item();
	$blog_datum->load( $blog_filename );
	
	# meta
	if (\strlen($blog_datum->meta_custom_description) > 0) {
		
		\pulsecore\get_context()->theme->meta->add( 'custom_meta', $blog_datum->meta_custom_description );
	}
	
	# set page description meta tags
	$GLOBALS['page_desc'] = $blog_datum->description;
	\pulsecore\get_context()->theme->meta->add( 'description', $blog_datum->description );
	
	$meta_robots   = array();
	$meta_robots[] = ($blog_datum->meta_indexed   == 'yes') ? 'index'   : 'noindex';
	$meta_robots[] = ($blog_datum->meta_no_follow == 'yes') ? 'nofollow': 'follow';
	
	$meta_robots = \implode(',', $meta_robots ); 
	
	\pulsecore\get_context()->theme->meta->add( 'robots', $meta_robots );
	
	# date
	if (\stripos($blog_datum->date, '-') == 2) {
		$date = \DateTime::createFromFormat( 'm-d-Y', $blog_datum->date );
	} else {
		# ISO format
		$date = new \DateTime( $blog_datum->date );
	}
	$date = \strftime( \pulsecore\convert_date_format_to_strftime($GLOBALS['date_format']), $date->getTimestamp() );
	
	$title = $blog_datum->title;
	
	if (\strlen($blog_datum->url) == 0) {
		$url_title = 'blog-' . $get_id . '-' . \pulsecore\filter\blog_title_in_url($title);
	} else {
		$url_title = 'blog-' . $get_id . '-' . \pulsecore\filter\blog_title_in_url($blog_datum->url);
	}

	$content_blog = \str_replace("##more##", "", $blog_datum->html);
	$page_title   = $title;
	
	#==> begin wedge <==
	#set the blog description
	#$page_desc = ((isset($blog_datum->description) and (\strlen($blog_datum->description) > 0))? \htmlspecialchars( $blog_datum->description, ENT_QUOTES, 'UTF-8') : $page_title);
	#==> end wedge   <==
	
	$content_blog = \pulsecore\tag_runner\expand( $content_blog );
	
	$base_url = \pulsecore\wedge\config\get_json_configs()->json->path;
	$back_url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : ($base_url . '/blog');
	
?>
	<div class='blog-wrap blog-entry blog-entry-details'>
		
		<h2 class='blog-title blog-entry-title'><?php echo $title; ?></h2>
		<p class='blog-date blog-entry-date'><?php echo $date; ?></p>
		
		<?php echo (isset($parsedown) ? $parsedown->text($content_blog) : $content_blog); ?>
		
		<?php 
			$helper_tag = new \pulsecore\tags\BlogItemTag();
			echo $helper_tag->generate_html( array('blog_item' => $blog_datum) );
			if ($GLOBALS['disqus_comments'] == true) {
				include(__DIR__ . '/../../inc/plugins/disqus.php');
			} 
		?>
		
		<div id='blog'>
			<span class='blog-read-more blog-back'>
				<a class='button' href="<?php echo $back_url; ?>"><?php echo $GLOBALS['lang_blog_back_button']; ?></a>
			</span>
		</div>
		
	</div>
	
<?php }
