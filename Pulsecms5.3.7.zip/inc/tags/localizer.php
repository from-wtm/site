<?php
$block = $GLOBALS["tag_var1"];

// fill session with locale
include_once(__DIR__ . "/localizer_init.php");

if ($_SESSION["locale"] && strlen($_SESSION["locale"]) == 2){
    if (file_exists (__DIR__ . "/../../content/blocks/" . $block . "-" . $_SESSION["locale"] . ".txt" )) {
        $block = $block . "-" . $_SESSION["locale"];
    }
}

/**
 * run the block tag
 */
echo \pulsecore\tags\Block::execute_tag(
    array(
        "block_name" => $block
    ),
    (isset($tag_runner_context) ? $tag_runner_context : array()),
	((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
);

?>