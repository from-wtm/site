<?php
/**
 * display a variable from the bootstrap get_context()
 * this avoids using PHP in page/block/etc text. Being able to run any PHP
 * is potentially a security risk
 */
echo \pulsecore\tags\ShowVar::execute_tag(
	array(
		'var_name' => $GLOBALS['tag_var1']
	),
	(isset($tag_runner_context) ? $tag_runner_context : array()),
	((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
);
