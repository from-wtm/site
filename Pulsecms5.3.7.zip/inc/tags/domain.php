<?php
/**
 * show domain variable Using {{show_var:"domain"}} would also work
 * \param $tag_runner_context array Extra content to provide to tags
 */

# call
echo \pulsecore\tags\Domain::execute_tag(
	array(
		'prepend' => $GLOBALS['tag_var1']
	),
	(isset($tag_runner_context) ? $tag_runner_context : array()),
	((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
);
