<?php

/**
 * run the page list tag
 */
echo \pulsecore\tags\PageList::execute_tag(
	[
		'location' => (empty($GLOBALS['tag_var1']) ? null : $GLOBALS['tag_var1'])
	],
	(isset($tag_runner_context) ? $tag_runner_context : []),
	((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
);
