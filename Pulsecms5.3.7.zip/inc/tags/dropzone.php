<?php
/**
 * media/file upload drag-n-drop
 * \param $tag_runner_context array Extra content to provide to tags
 */
function tag_dropzone( array $tag_runner_context = array() ) {
	
	$tag = new \pulsecore\tags\Dropzone();
	
	$result = $tag->generate_html(
		array(
			'media_folder'       => ((isset($GLOBALS['tag_var1']) and (\strlen($GLOBALS['tag_var1']) > 0)) ? \trim($GLOBALS['tag_var1']) : '' ),
			'allowed_file_types' => ((isset($GLOBALS['tag_var2']) and (\strlen($GLOBALS['tag_var2']) > 0)) ? \trim($GLOBALS['tag_var2']) : \implode(',', \pulsecore\get_configs()->media_files->image_types) ),
			'upload_handler'     => ((isset($GLOBALS['tag_var3']) and (\strlen($GLOBALS['tag_var3']) > 0)) ? \trim($GLOBALS['tag_var3']) : (\pulsecore\wedge\config\get_json_configs()->json->path . '/dropzone_upload_handler.php') ),
		),
		$tag_runner_context,
		((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
	);
	
	return $result;
}

# call
echo tag_dropzone( (isset($tag_runner_context) ? $tag_runner_context : array()) );
