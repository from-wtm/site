<?php
/**
 * display a list of the blog items for a blog
 * \param $tag_runner_context array Extra content to provide to tags
 */
function tag_blog_list( array $tag_runner_context = array() ) {
	
	$tag = new \pulsecore\tags\BlogList();
	
	$result = $tag->generate_html(
		array(
			'location'  => (empty($GLOBALS['tag_var1']) ? null : $GLOBALS['tag_var1']),
			'display'   => (empty($GLOBALS['tag_var2']) ? null : $GLOBALS['tag_var2']),
			'page_size' => (empty($GLOBALS['tag_var3']) ? null : $GLOBALS['tag_var3'])
		),
		$tag_runner_context,
		((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
	);
	
	return $result;
}

# call
echo tag_blog_list( (isset($tag_runner_context) ? $tag_runner_context : array()) );
