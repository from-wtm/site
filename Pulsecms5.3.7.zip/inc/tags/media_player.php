<?php

# call
echo \pulsecore\tags\MediaPlayer::execute_tag(
	array(
		'base_url'         => $GLOBALS['path'],
		
		'source'           => $GLOBALS['tag_var1'],
		'source_mime_type' => $GLOBALS['tag_var2'],
		'type'             => $GLOBALS['tag_var3'],
		
		'element_width'    => (isset($GLOBALS['tag_var4']) ? $GLOBALS['tag_var4'] : null),
		'element_height'   => (isset($GLOBALS['tag_var5']) ? $GLOBALS['tag_var5'] : null)
	),
	(isset($tag_runner_context) ? $tag_runner_context : array()),
	((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
);
