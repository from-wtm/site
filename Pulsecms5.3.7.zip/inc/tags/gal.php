<?php

/**
 * run the gal tag
 */
echo \pulsecore\tags\Gal::execute_tag(
	array(
		'gallery_directory' => $GLOBALS['tag_var1'],
		'number_of_images'  => ((isset($GLOBALS['tag_var2']) and \is_string($GLOBALS['tag_var2']) and (\strlen($GLOBALS['tag_var2']) > 0)) ? $GLOBALS['tag_var2'] : 'all'),
		'popup_all_images'  => ((isset($GLOBALS['tag_var3']) and \is_string($GLOBALS['tag_var3']) and (\strlen($GLOBALS['tag_var3']) > 0)) ? $GLOBALS['tag_var3'] : 'no')
	),
	(isset($tag_runner_context) ? $tag_runner_context : array()),
	((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
);
