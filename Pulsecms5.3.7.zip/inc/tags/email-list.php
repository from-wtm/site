<?php

require_once (__DIR__ . '/../../pulsecore/tags/email-list.php');
