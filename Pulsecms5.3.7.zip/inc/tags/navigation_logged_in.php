<?php
/**
 * navigation block - logged in top level menu (admin/editor)
 * \param $tag_runner_context array Extra content to provide to tags
 * \return string
 */
function tag_navigation_logged_in( array $tag_runner_context = array() ) {
	
	$tag = new \pulsecore\tags\NavigationLoggedIn();
	
	$result = $tag->generate_html(
		array(
			'label'       => (isset($GLOBALS['tag_var1']) ? $GLOBALS['tag_var1'] : ''),
			'css_classes' => (isset($GLOBALS['tag_var2']) ? $GLOBALS['tag_var2'] : '')
		),
		$tag_runner_context,
		((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
	);
	
	return $result;
}

# call
echo tag_navigation_logged_in( (isset($tag_runner_context) ? $tag_runner_context : array()) );
