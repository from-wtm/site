<?php
/**
 * allow for password protection of individual *pages*
 * note that the password (in cleartext) and OTP shared secret are passed
 * as paramaters
 */
 
require_once (__DIR__ . '/../../pulsecore/tags/sb_login.php');

echo \pulsecore\tags\sb_login\generate_html( $GLOBALS['tag_var1'], $GLOBALS['tag_var2'], $GLOBALS['tag_var3'], $GLOBALS['tag_var4'] );
