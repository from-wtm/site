<?php
/**
 * end point block
 */
 
require_once (__DIR__ . '/../../pulsecore/tags/end_point.php');

echo \pulsecore\tags\end_point\generate_html( $GLOBALS['path'], $GLOBALS['tag_var1'] );
