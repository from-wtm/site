<?php
/**
 * Created by PhpStorm.
 * User: hishikawa
 * Date: 2016/10/17
 * Time: 21:40
 */
include_once('inc/plugins/ogp.php');

Ogp::add($tag_var1, $tag_var2);