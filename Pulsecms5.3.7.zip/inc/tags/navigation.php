<?php
/**
 * navigation block
 */
echo \pulsecore\tags\Navigation::execute_tag(
	array(
		'label'       => (empty($GLOBALS['tag_var1']) ? 'all' : $GLOBALS['tag_var1']),
		'css_classes' => (empty($GLOBALS['tag_var2']) ? ''    : $GLOBALS['tag_var2'])
	),
	(isset($tag_runner_context) ? $tag_runner_context : array()),
	((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
);
