<?php

/**
 * blog-show tag
 * \param $tag_runner_context array Extra content to provide to tags
 */
function tag_blog_show( array $tag_runner_context = array() ) {
	
	# input
	$blog_name   = (!empty($GLOBALS['tag_var1'])) ? $GLOBALS['tag_var1'  ] : 'blog';
	$blog_prefix = (!empty($GLOBALS['tag_var2'])) ? $GLOBALS['url_prefix'] : 'blog'; #this is odd
	$layout      = (!empty($GLOBALS['tag_var3'])) ? $GLOBALS['tag_var3'  ] : \pulsecore\get_configs()->default_content->blog->layout;
	
	$filter_tag = isset($_GET['blog_tag_name']) ? $_GET['blog_tag_name'] : '';
	
	$blog_id     = (isset($_GET['d']   ) and \is_numeric($_GET['d']   )) ? $_GET['d']    : '';
	$page_number = (isset($_GET['page']) and \is_numeric($_GET['page'])) ? $_GET['page'] : '1';
	
	# filter input
	$blog_name   = \pulsecore\filter\item_url( $blog_name );
	$blog_prefix = \pulsecore\filter\item_url( $blog_prefix );
	
	$layout      = \trim( $layout );
	
	$filter_tag = \pulsecore\filter\blog_title_in_url( $filter_tag );
	
	$blog_id     = \pulsecore\filter\f_int( $blog_id );
	$page_number = \pulsecore\filter\f_int( $page_number );
	
	# update the context
	$tag_runner_context = \array_merge(
		$tag_runner_context,
		array(
			'blog_name'    => $blog_name,
			'filter_tag'   => $filter_tag,
			'flag_reverse' => \pulsecore\wedge\config\get_json_configs()->json->blog_flag_reverse,
			'hide_draft'   => true,
			
			'result_per_page' => 100
		)
	);
	
	# css
	\pulsecore\get_context()->theme->css->add(
		"{$GLOBALS['path']}/inc/tags/css/blog.css",
		array()
	);
	
	# case valid $blog_id
	if (isset($blog_id) and \is_numeric($blog_id)) {
		
		echo tag_blog_show_item(
			$blog_id,
			array(
				'blog_name'   => $blog_name,
				'blog_prefix' => $blog_prefix,
				'layout'      => $layout
			),
			$tag_runner_context
		);
		
	} else {
		
		# list all the blog items
		$tag = new \pulsecore\tags\Blog();
		
		echo $tag->generate_html(
			[
				#'blog_name'    => $blog_name,
				#'blog_prefix'  => $blog_prefix,
				'layout'       => $layout
			],
			$tag_runner_context,
			(
				(isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0))
				? \trim($GLOBALS['tag_composite_content'])
				: '' #\pulsecore\get_configs()->default_content->blog->layout
			)
		);
	}
	
}

/**
 * show individual blog content
 * \param $blog_id string The blog item to show in a blog
 * \param $tag_vars array Tag parameters
 * \param $tag_runner_context array Extra content to provide to tags
 */
function tag_blog_show_item( $blog_id, array $tag_vars, array $tag_runner_context = array() ) {
	
	$blog_filename = \pulsecore\get_configs()->dir_content . '/blog/' . ((\strlen($tag_vars['blog_name']) > 0) ? "{$tag_vars['blog_name']}/" : '') . $blog_id . '.txt';
	
	\pulsecore\invariant( \file_exists($blog_filename) );
	
	$blog_datum = new \pulsecore\store\blog\Item();
	$blog_datum->load( $blog_filename );
	
	# meta
	if ($blog_datum->meta_custom_description != '') {
		\pulsecore\get_context()->theme->meta->add( 'custom_meta', $blog_datum->meta_custom_description );
	}
	$meta_robots   = array();
	$meta_robots[] = ($blog_datum->meta_indexed   == 'yes') ? 'index'   : 'noindex';
	$meta_robots[] = ($blog_datum->meta_no_follow == 'yes') ? 'nofollow': 'follow';
	
	$meta_robots = \implode(',', $meta_robots ); 
	
	\pulsecore\get_context()->theme->meta->add( 'robots', $meta_robots );
	
	# date
	if (\stripos($blog_datum->date, '-') == 2) {
		$date = \DateTime::createFromFormat( 'm-d-Y', $blog_datum->date );
	} else {
		# ISO format
		$date = new \DateTime( $blog_datum->date );
	}
	$date = \strftime( \pulsecore\convert_date_format_to_strftime($GLOBALS['date_format']), $date->getTimestamp() );
	
	$title = $blog_datum->title;
	
	if (\strlen($blog_datum->url) == 0) {
		$url_title = 'blog-' . $blog_id . '-' . \pulsecore\filter\blog_title_in_url($title);
	} else {
		$url_title = 'blog-' . $blog_id . '-' . \pulsecore\filter\blog_title_in_url($blog_datum->url);
	}

	$content_blog = \str_replace("##more##", "", $blog_datum->html);
	$page_title   = $title;
	
	#==> begin wedge <==
	#set the blog description
	#$page_desc = ((isset($blog_datum->description) and (\strlen($blog_datum->description) > 0))? \htmlspecialchars( $blog_datum->description, ENT_QUOTES, 'UTF-8') : $page_title);
	#==> end wedge   <==
	
	$content_blog = \pulsecore\tag_runner\expand( $content_blog );
	
	echo "<div class='blog-wrap blog-entry blog-entry-details'>";
	echo "<h2 class='blog-title blog-entry-title'>$title</h2>";
	echo "<p class='blog-date blog-entry-date'>$date</p>";
	echo (isset($GLOBALS['parsedown']) ? $GLOBALS['parsedown']->text($content_blog) : $content_blog);
	
	#==> begin wedge <==
	#echo \pulsecore\wedge\blog\storage\tags_to_html( $pulsecore_expanded, $path );
	#==> end wedge   <==

	$helper_tag = new \pulsecore\tags\BlogItemTag();
	echo $helper_tag->generate_html( array('blog_item' => $blog_datum) );
	if ($GLOBALS['disqus_comments'] == true){
		include('inc/plugins/disqus.php');
	}

	echo "<div id='blog'><span class='blog-read-more blog-back'>";
	echo "<a class='button' href='javascript:history.back();'>{$GLOBALS['lang_blog_back_button']}</a>";
	echo "</span></div>";
	
	echo "</div>";
}

# call
tag_blog_show( (isset($tag_runner_context) ? $tag_runner_context : array()) );
