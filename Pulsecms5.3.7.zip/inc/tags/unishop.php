<?php
/**
 * unishop cart
 * \param $tag_runner_context array Extra content to provide to tags
 */
function tag_unishop( array $tag_runner_context = array() ) {
	
	$tag = new \pulsecore\tags\Unishop();
	
	$result = $tag->generate_html(
		array(
			'business'        => ((isset($GLOBALS['tag_var1']) and (\strlen($GLOBALS['tag_var1']) > 0)) ? \trim($GLOBALS['tag_var1']) : 'paypal@domain.com' ),
			'currency_code'   => ((isset($GLOBALS['tag_var2']) and (\strlen($GLOBALS['tag_var2']) > 0)) ? \trim($GLOBALS['tag_var2']) : 'USD' ),
			'currency_symbol' => ((isset($GLOBALS['tag_var3']) and (\strlen($GLOBALS['tag_var3']) > 0)) ? \trim($GLOBALS['tag_var3']) : '$' ),
			'lc'              => ((isset($GLOBALS['tag_var4']) and (\strlen($GLOBALS['tag_var4']) > 0)) ? \trim($GLOBALS['tag_var4']) : 'US' ), # locale
			'no_shipping'     => ((isset($GLOBALS['tag_var5']) and (\strlen($GLOBALS['tag_var5']) > 0)) ? \trim($GLOBALS['tag_var5']) : '0'  ),
			'return_url'      => ((isset($GLOBALS['tag_var6']) and (\strlen($GLOBALS['tag_var6']) > 0)) ? \trim($GLOBALS['tag_var6']) : ''  ),
			'cancel_url'      => ((isset($GLOBALS['tag_var7']) and (\strlen($GLOBALS['tag_var7']) > 0)) ? \trim($GLOBALS['tag_var7']) : ''  )
		),
		$tag_runner_context,
		((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
	);
	
	return $result;
}

# call
echo tag_unishop( (isset($tag_runner_context) ? $tag_runner_context : array()) );
