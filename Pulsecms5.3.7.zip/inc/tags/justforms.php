<?php
$jf_id     = $GLOBALS['tag_var1'];
$jf_height = $GLOBALS['tag_var2'];
//$jf_theme  = $GLOBALS['tag_var3'];
?>

<!-- Just Forms: https://justforms.yuzoolthemes.com -->
<div id="c<?php echo $jf_id; ?>"><!-- option -->
	Fill out my <a href="https://justforms.yuzoolthemes.com/app/app/form?id=<?php echo $jf_id; ?>">online form</a>.<!-- option -->
</div>
<script type="text/javascript">
	(function(d, t) {
			var s = d.createElement(t), options = {
					'id': <?php echo $jf_id; ?>,<!-- option -->
					//'theme': <?php echo $jf_theme; ?>,<!-- option -->
					'container': 'c<?php echo $jf_id; ?>',<!-- option -->
					'height': '<?php echo $jf_height; ?>px',<!-- option -->
					'form': '//justforms.yuzoolthemes.com/app/app/embed'
			};
			s.type= 'text/javascript';
			s.src = 'https://justforms.yuzoolthemes.com/app/static_files/js/form.widget.js';
			s.onload = s.onreadystatechange = function() {
					var rs = this.readyState; if (rs) if (rs != 'complete') if (rs != 'loaded') return;
					try { (new EasyForms()).initialize(options).display() } catch (e) { }
			};
			var scr = d.getElementsByTagName(t)[0], par = scr.parentNode; par.insertBefore(s, scr);
	})(document, 'script');
</script>
<!-- End Just Forms -->
