<?php
/**
 * GDPR popup
 */

echo \pulsecore\tags\Gdpr::execute_tag(
	array(
		'extra_text' => $GLOBALS['tag_var1']
	),
	(isset($tag_runner_context) ? $tag_runner_context : array()),
	((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
);
