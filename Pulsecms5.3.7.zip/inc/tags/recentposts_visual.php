<?php

/**
 * run the tag
 */
echo \pulsecore\tags\RecentPostsVisual::execute_tag(
	array(
		'limit'      => (empty($GLOBALS['tag_var1']) ?    '5' : \pulsecore\filter\f_int(        $GLOBALS['tag_var1'])),
		'location'   => (empty($GLOBALS['tag_var2']) ? 'blog' : \pulsecore\filter\blog_item_url($GLOBALS['tag_var2'])),
		'no_date'    => (empty($GLOBALS['tag_var3']) ?     '' : $GLOBALS['tag_var3']),
		'limit_text' => (empty($GLOBALS['tag_var4']) ?   '50' : \pulsecore\filter\f_int(        $GLOBALS['tag_var4'])),
	),
	(isset($tag_runner_context) ? $tag_runner_context : array()),
	((isset($GLOBALS['tag_composite_content']) and \is_string($GLOBALS['tag_composite_content']) and (\strlen($GLOBALS['tag_composite_content']) > 0)) ? \trim($GLOBALS['tag_composite_content']) : '')
);
