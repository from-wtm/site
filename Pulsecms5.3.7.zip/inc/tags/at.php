<?php

# mailcrypt
\pulsecore\get_context()->theme->js_body->add( PULSE_BASE_URL . '/pulsecore/asset/vendor/mailcrypt.js', array(), 'mailcrypt' );


$inline_js = <<<EOD
	document.addEventListener(
		'DOMContentLoaded',
		function(evnt) {
			jQuery('a.mailcrypt').mailcrypt();
		}
	);
EOD;

\pulsecore\get_context()->theme->js_body->add_inline(
	'at_mailcrypt',
	$inline_js
);

echo '<span><span>∂</span></span>';
